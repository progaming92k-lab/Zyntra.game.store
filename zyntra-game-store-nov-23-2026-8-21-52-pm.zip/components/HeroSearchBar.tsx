'use client';

import React, { useState } from 'react';
import { Search } from 'lucide-react';

export default function HeroSearchBar() {
  const [focused, setFocused] = useState(false);

  return (
    <form action="/search" method="get" className="mt-7 flex max-w-lg flex-col gap-2.5 sm:flex-row">
      <div className="zyntra-search-wrap relative flex-1">
        <Search
          className={`pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 transition-colors duration-200 ${
            focused ? 'text-[#38BDF8] scale-110' : 'text-[#73788C]'
          }`}
          aria-hidden="true"
        />
        <input
          type="search"
          name="q"
          aria-label="Search games"
          placeholder="Search games, genres, or tags..."
          onFocus={() => setFocused(true)}
          onBlur={() => setFocused(false)}
          className="w-full rounded-lg border border-[#282B3B] bg-[#07070B]/90 py-2.5 pl-10 pr-4 text-sm text-[#F4F4F8] placeholder-[#6B7186] transition-colors focus:border-[#38BDF8] focus:outline-none"
        />
      </div>
      <button
        type="submit"
        className="zyntra-btn-shine rounded-lg bg-gradient-to-r from-[#8B5CF6] to-[#7C3AED] px-5 py-2.5 text-sm font-semibold text-white transition-all duration-200 hover:scale-[1.02] hover:shadow-[0_0_24px_rgba(139,92,246,0.5)] whitespace-nowrap"
      >
        Search
      </button>
    </form>
  );
}
