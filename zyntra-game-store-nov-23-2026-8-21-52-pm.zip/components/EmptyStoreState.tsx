import React from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { Gamepad2, Upload } from 'lucide-react';

interface EmptyStoreStateProps {
  title?: string;
  description?: string;
  showImportCta?: boolean;
}

export default function EmptyStoreState({
  title = 'The Zyntra Vault Awaits Its First Release',
  description = 'No games have been published to the storefront yet. Upload an HTML5 ZIP, Android APK, or PC build through Import Game and let automatic analysis craft the listing.',
  showImportCta = true,
}: EmptyStoreStateProps) {
  return (
    <section
      data-testid="empty-store-state"
      className="overflow-hidden rounded-2xl border border-[#242738] bg-[#101118]/86 backdrop-blur-md shadow-[0_16px_48px_rgba(0,0,0,0.45)]"
    >
      <div className="grid grid-cols-1 lg:grid-cols-12 items-stretch">
        <div className="relative min-h-[260px] lg:col-span-6 bg-[#090A0F]">
          <Image
            src="/images/zyntra-empty-vault.jpg"
            alt="Empty illuminated Zyntra Game Store showcase plinth"
            fill
            sizes="(max-width: 1024px) 100vw, 50vw"
            referrerPolicy="no-referrer"
            className="object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-transparent via-transparent to-[#101118]/90 hidden lg:block" />
          <div className="absolute inset-0 bg-gradient-to-t from-[#101118] via-transparent to-transparent lg:hidden" />
        </div>

        <div className="flex flex-col justify-center p-8 sm:p-10 lg:col-span-6">
          <div className="inline-flex h-11 w-11 items-center justify-center rounded-xl border border-[#8B5CF6]/40 bg-[#8B5CF6]/10 text-[#A855F7]">
            <Gamepad2 className="h-5 w-5" aria-hidden="true" />
          </div>

          <h2 className="mt-5 font-display text-2xl font-bold text-[#F4F4F8] sm:text-3xl">
            {title}
          </h2>
          <p className="mt-3 text-sm leading-relaxed text-[#9CA3B4] sm:text-base">
            {description}
          </p>

          <div className="mt-7 flex flex-wrap items-center gap-3">
            {showImportCta && (
              <Link
                href="/import"
                className="inline-flex items-center gap-2 rounded-lg bg-gradient-to-r from-[#7C3AED] to-[#0EA5E9] px-5 py-2.5 text-sm font-semibold text-white shadow-[0_0_22px_rgba(124,58,237,0.35)] transition-all duration-150 hover:brightness-110 whitespace-nowrap"
              >
                <Upload className="h-4 w-4" aria-hidden="true" />
                <span>Import First Game</span>
              </Link>
            )}
            <Link
              href="/categories"
              className="inline-flex items-center rounded-lg border border-[#282B3B] bg-[#161822] px-5 py-2.5 text-sm font-medium text-[#D1D5E2] transition-colors hover:border-[#38BDF8]/50 hover:text-white whitespace-nowrap"
            >
              Explore Categories
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}
