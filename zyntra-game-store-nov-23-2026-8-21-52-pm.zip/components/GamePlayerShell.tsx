'use client';

import React, { useEffect, useRef, useState } from 'react';
import Link from 'next/link';
import {
  AlertTriangle,
  ArrowDown,
  ArrowLeft,
  ArrowRight,
  ArrowUp,
  Gamepad2,
  Maximize2,
  Minimize2,
  RotateCcw,
} from 'lucide-react';
import DownloadButton from './DownloadButton';
import ShareButton from './ShareButton';
import ZyntraLoader from './ZyntraLoader';
import type { GameRecord } from '@/lib/types';

interface GamePlayerShellProps {
  game: GameRecord;
}

export default function GamePlayerShell({ game }: GamePlayerShellProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const [runKey, setRunKey] = useState(0);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [touchPadOpen, setTouchPadOpen] = useState(false);

  useEffect(() => {
    fetch(`/api/games/${encodeURIComponent(game.id)}/track-play`, {
      method: 'POST',
      keepalive: true,
    }).catch(() => {});
  }, [game.id]);

  useEffect(() => {
    function handleFsChange() {
      setIsFullscreen(Boolean(document.fullscreenElement));
    }
    document.addEventListener('fullscreenchange', handleFsChange);
    return () => document.removeEventListener('fullscreenchange', handleFsChange);
  }, []);

  useEffect(() => {
    if (!loading) return;
    const poll = setInterval(() => {
      try {
        const doc = iframeRef.current?.contentDocument;
        if (doc && (doc.readyState === 'interactive' || doc.readyState === 'complete') && doc.body?.children.length > 0) {
          setLoading(false);
        }
      } catch {
        // ignore cross-origin
      }
    }, 200);
    const timer = setTimeout(() => {
      setLoading(false);
    }, 8000);
    return () => {
      clearInterval(poll);
      clearTimeout(timer);
    };
  }, [loading, runKey]);

  async function toggleFullscreen() {
    try {
      if (!document.fullscreenElement && containerRef.current) {
        await containerRef.current.requestFullscreen();
      } else if (document.fullscreenElement) {
        await document.exitFullscreen();
      }
    } catch {
      // Fullscreen blocked by browser policy
    }
  }

  function handleRestart() {
    setLoadError(null);
    setLoading(true);
    setRunKey((k) => k + 1);
  }

  function dispatchGameKey(type: 'keydown' | 'keyup', key: string, code: string) {
    try {
      const win = iframeRef.current?.contentWindow;
      const doc = iframeRef.current?.contentDocument;
      if (!win || !doc) return;
      win.focus();
      const evt = new KeyboardEvent(type, { key, code, bubbles: true, cancelable: true });
      win.dispatchEvent(evt);
      doc.dispatchEvent(evt);
    } catch {
      // Cross-origin safeguard
    }
  }

  const playUrl = game.entryFile
    ? `/api/play/${encodeURIComponent(game.slug)}/${game.entryFile.replace(/^\/+/, '')}?r=${runKey}`
    : '';

  if (!game.isBrowserPlayable || !playUrl) {
    return (
      <div className="mx-auto max-w-2xl px-4 py-16 text-center">
        <div className="rounded-2xl border border-[#232634] bg-[#111218] p-8">
          <AlertTriangle className="mx-auto h-10 w-10 text-amber-400" aria-hidden="true" />
          <h1 className="mt-4 font-display text-2xl font-bold text-[#F4F4F8]">
            Browser Playback Not Available for {game.platform}
          </h1>
          <p className="mt-2 text-sm text-[#9CA3B4]">
            {game.title} is packaged as a native {game.platform} ({game.fileFormat}) release. Download the verified file to play on your device.
          </p>
          <div className="mx-auto mt-6 max-w-xs">
            <DownloadButton
              gameId={game.id}
              filename={game.originalFilename}
              fileFormat={game.fileFormat}
              fileSize={game.fileSize}
              variant="primary"
            />
          </div>
          <Link
            href={`/games/${game.slug}`}
            className="mt-6 inline-flex items-center gap-2 text-sm font-medium text-[#38BDF8] hover:underline"
          >
            <ArrowLeft className="h-4 w-4" aria-hidden="true" />
            <span>Return to Game Details</span>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8">
      {/* Player Header Bar */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-4">
        <div className="flex items-center gap-4">
          <Link
            href={`/games/${game.slug}`}
            className="inline-flex items-center gap-1.5 rounded-lg border border-[#232634] bg-[#111218] px-3 py-2 text-xs font-medium text-[#D1D5E2] hover:border-[#38BDF8]/60 hover:text-white whitespace-nowrap"
          >
            <ArrowLeft className="h-3.5 w-3.5" aria-hidden="true" />
            <span>Game Details</span>
          </Link>
          <div>
            <h1 className="font-display text-xl font-bold text-[#F4F4F8] sm:text-2xl">{game.title}</h1>
            <p className="text-xs text-[#8E94A8]">
              {game.category} · {game.platform} · v{game.version}
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => setTouchPadOpen((v) => !v)}
            className={`inline-flex items-center gap-1.5 rounded-lg border px-3.5 py-2 text-xs font-semibold transition-colors whitespace-nowrap ${
              touchPadOpen
                ? 'border-[#8B5CF6] bg-[#8B5CF6]/20 text-white'
                : 'border-[#232634] bg-[#111218] text-[#D1D5E2] hover:text-white'
            }`}
          >
            <Gamepad2 className="h-3.5 w-3.5" aria-hidden="true" />
            <span>Touch Controls</span>
          </button>

          <button
            type="button"
            onClick={handleRestart}
            className="inline-flex items-center gap-1.5 rounded-lg border border-[#232634] bg-[#111218] px-3.5 py-2 text-xs font-semibold text-[#D1D5E2] transition-colors hover:border-[#38BDF8]/60 hover:text-white whitespace-nowrap"
          >
            <RotateCcw className="h-3.5 w-3.5" aria-hidden="true" />
            <span>Restart Game</span>
          </button>

          <ShareButton
            variant="compact"
            label="Share"
            title={game.title}
            text={`Play ${game.title} directly in your browser on Zyntra Game Store!`}
          />

          <button
            type="button"
            onClick={toggleFullscreen}
            className="inline-flex items-center gap-1.5 rounded-lg bg-[#8B5CF6] px-4 py-2 text-xs font-semibold text-white transition-all hover:bg-[#7C3AED] whitespace-nowrap"
          >
            {isFullscreen ? (
              <>
                <Minimize2 className="h-3.5 w-3.5" aria-hidden="true" />
                <span>Exit Fullscreen</span>
              </>
            ) : (
              <>
                <Maximize2 className="h-3.5 w-3.5" aria-hidden="true" />
                <span>Fullscreen</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Playable Viewport */}
      <div
        ref={containerRef}
        className="relative overflow-hidden rounded-2xl border border-[#262938] bg-[#050508] shadow-[0_24px_70px_rgba(0,0,0,0.6)]"
      >
        <div className={`relative w-full ${isFullscreen ? 'h-screen' : 'aspect-video min-h-[420px] max-h-[78vh]'}`}>
          {loading && !loadError && (
            <div className="absolute inset-0 z-20 flex flex-col items-center justify-center bg-[#07070B]/95 p-6 text-center">
              <ZyntraLoader
                compact
                title={`Loading ${game.title}...`}
                subtitle="Preparing browser runtime and game assets"
              />
            </div>
          )}

          {loadError && (
            <div className="absolute inset-0 z-30 flex flex-col items-center justify-center bg-[#090A0F] p-6 text-center">
              <AlertTriangle className="h-10 w-10 text-rose-400" aria-hidden="true" />
              <h2 className="mt-3 font-display text-xl font-bold text-[#F4F4F8]">Unable to Load Game</h2>
              <p className="mt-2 max-w-md text-sm text-[#9CA3B4]">{loadError}</p>
              <button
                type="button"
                onClick={handleRestart}
                className="mt-5 rounded-lg bg-[#8B5CF6] px-4 py-2 text-sm font-semibold text-white hover:bg-[#7C3AED]"
              >
                Retry Launch
              </button>
            </div>
          )}

          <iframe
            key={runKey}
            ref={iframeRef}
            src={playUrl}
            title={`${game.title} browser player`}
            data-testid="game-player-iframe"
            allow="fullscreen; autoplay; gamepad"
            sandbox="allow-scripts allow-same-origin allow-pointer-lock allow-forms allow-modals"
            onLoad={() => {
              setLoading(false);
              try {
                iframeRef.current?.contentWindow?.focus();
              } catch {
                // ignore
              }
            }}
            onError={() => {
              setLoading(false);
              setLoadError('The game archive could not be initialized inside the browser frame.');
            }}
            className="h-full w-full border-0 bg-black"
          />
        </div>

        {/* Mobile Touch Controls Overlay */}
        {touchPadOpen && (
          <div className="flex items-center justify-between border-t border-[#1E202C] bg-[#0B0C11] px-6 py-4 select-none">
            <div className="grid grid-cols-3 gap-1.5 w-36">
              <div />
              <button
                type="button"
                aria-label="Up"
                onPointerDown={() => dispatchGameKey('keydown', 'ArrowUp', 'ArrowUp')}
                onPointerUp={() => dispatchGameKey('keyup', 'ArrowUp', 'ArrowUp')}
                onPointerLeave={() => dispatchGameKey('keyup', 'ArrowUp', 'ArrowUp')}
                className="flex h-11 items-center justify-center rounded-lg border border-[#2C3042] bg-[#161822] text-white active:bg-[#8B5CF6]"
              >
                <ArrowUp className="h-4 w-4" />
              </button>
              <div />
              <button
                type="button"
                aria-label="Left"
                onPointerDown={() => dispatchGameKey('keydown', 'ArrowLeft', 'ArrowLeft')}
                onPointerUp={() => dispatchGameKey('keyup', 'ArrowLeft', 'ArrowLeft')}
                onPointerLeave={() => dispatchGameKey('keyup', 'ArrowLeft', 'ArrowLeft')}
                className="flex h-11 items-center justify-center rounded-lg border border-[#2C3042] bg-[#161822] text-white active:bg-[#8B5CF6]"
              >
                <ArrowLeft className="h-4 w-4" />
              </button>
              <button
                type="button"
                aria-label="Down"
                onPointerDown={() => dispatchGameKey('keydown', 'ArrowDown', 'ArrowDown')}
                onPointerUp={() => dispatchGameKey('keyup', 'ArrowDown', 'ArrowDown')}
                onPointerLeave={() => dispatchGameKey('keyup', 'ArrowDown', 'ArrowDown')}
                className="flex h-11 items-center justify-center rounded-lg border border-[#2C3042] bg-[#161822] text-white active:bg-[#8B5CF6]"
              >
                <ArrowDown className="h-4 w-4" />
              </button>
              <button
                type="button"
                aria-label="Right"
                onPointerDown={() => dispatchGameKey('keydown', 'ArrowRight', 'ArrowRight')}
                onPointerUp={() => dispatchGameKey('keyup', 'ArrowRight', 'ArrowRight')}
                onPointerLeave={() => dispatchGameKey('keyup', 'ArrowRight', 'ArrowRight')}
                className="flex h-11 items-center justify-center rounded-lg border border-[#2C3042] bg-[#161822] text-white active:bg-[#8B5CF6]"
              >
                <ArrowRight className="h-4 w-4" />
              </button>
            </div>

            <div className="flex items-center gap-3">
              <button
                type="button"
                onPointerDown={() => dispatchGameKey('keydown', ' ', 'Space')}
                onPointerUp={() => dispatchGameKey('keyup', ' ', 'Space')}
                onPointerLeave={() => dispatchGameKey('keyup', ' ', 'Space')}
                className="flex h-14 w-14 items-center justify-center rounded-full border border-[#38BDF8]/60 bg-[#0EA5E9]/20 font-display text-sm font-bold text-white active:bg-[#0EA5E9]"
              >
                A
              </button>
              <button
                type="button"
                onPointerDown={() => dispatchGameKey('keydown', 'Enter', 'Enter')}
                onPointerUp={() => dispatchGameKey('keyup', 'Enter', 'Enter')}
                onPointerLeave={() => dispatchGameKey('keyup', 'Enter', 'Enter')}
                className="flex h-14 w-14 items-center justify-center rounded-full border border-[#8B5CF6]/60 bg-[#8B5CF6]/20 font-display text-sm font-bold text-white active:bg-[#8B5CF6]"
              >
                B
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Controls & Quick Info Footer */}
      <div className="mt-6 grid grid-cols-1 gap-5 md:grid-cols-2">
        <div className="rounded-xl border border-[#222432] bg-[#111218] p-5">
          <h2 className="font-display text-sm font-bold text-[#F4F4F8]">Controls</h2>
          <p className="mt-1.5 text-sm text-[#9CA3B4]">{game.controls}</p>
        </div>
        <div className="rounded-xl border border-[#222432] bg-[#111218] p-5">
          <h2 className="font-display text-sm font-bold text-[#F4F4F8]">Instructions</h2>
          <p className="mt-1.5 text-sm text-[#9CA3B4]">{game.instructions}</p>
        </div>
      </div>
    </div>
  );
}
