'use client';

import React, { useEffect, useSyncExternalStore } from 'react';
import { Volume2, VolumeX } from 'lucide-react';
import ShareButton from './ShareButton';
import { isSoundEnabled, playUiSound, setSoundEnabledPref } from '@/lib/sound';

const SOUND_CHANGE_EVENT = 'zyntra-sfx-change';

function subscribeSoundPref(callback: () => void) {
  window.addEventListener('storage', callback);
  window.addEventListener(SOUND_CHANGE_EVENT, callback);
  return () => {
    window.removeEventListener('storage', callback);
    window.removeEventListener(SOUND_CHANGE_EVENT, callback);
  };
}

function getSoundSnapshot() {
  return isSoundEnabled();
}

function getServerSoundSnapshot() {
  return true;
}

export default function SoundEngine() {
  const enabled = useSyncExternalStore(
    subscribeSoundPref,
    getSoundSnapshot,
    getServerSoundSnapshot
  );

  useEffect(() => {
    function handlePointerDown(e: PointerEvent) {
      if (!isSoundEnabled()) return;
      const target = e.target as HTMLElement | null;
      if (!target) return;

      const interactive = target.closest(
        'button, a, select, summary, [role="button"], label[for], input[type="checkbox"]'
      );
      if (!interactive) return;

      if (
        interactive.hasAttribute('disabled') ||
        interactive.getAttribute('aria-disabled') === 'true'
      ) {
        return;
      }

      const cls = interactive.className || '';
      const isPrimaryCta =
        typeof cls === 'string' &&
        (cls.includes('from-[#7C3AED]') ||
          cls.includes('bg-[#8B5CF6]') ||
          cls.includes('bg-[#0EA5E9]'));

      playUiSound(isPrimaryCta ? 'primary' : 'click');
    }

    document.addEventListener('pointerdown', handlePointerDown, { passive: true });
    return () => document.removeEventListener('pointerdown', handlePointerDown);
  }, []);

  function toggleSound() {
    const next = !enabled;
    setSoundEnabledPref(next);
    window.dispatchEvent(new Event(SOUND_CHANGE_EVENT));
    if (next) {
      playUiSound('primary');
    }
  }

  return (
    <div className="fixed bottom-4 right-4 z-40 flex items-center gap-2">
      <ShareButton variant="dock" label="Share" />
      <button
        type="button"
        onClick={toggleSound}
        data-testid="sfx-toggle"
        aria-pressed={enabled}
        aria-label={enabled ? 'Mute UI click sound effects' : 'Enable UI click sound effects'}
        title={enabled ? 'UI Sound Effects: On' : 'UI Sound Effects: Off'}
        className="inline-flex h-10 items-center gap-2 rounded-lg border border-[#282B3E] bg-[#111218]/90 px-3 text-xs font-medium text-[#D1D5E2] backdrop-blur-md shadow-[0_8px_24px_rgba(0,0,0,0.45)] transition-all duration-150 hover:border-[#38BDF8]/60 hover:text-white whitespace-nowrap"
      >
        {enabled ? (
          <>
            <Volume2 className="h-4 w-4 text-[#38BDF8]" aria-hidden="true" />
            <span>SFX On</span>
          </>
        ) : (
          <>
            <VolumeX className="h-4 w-4 text-[#73788C]" aria-hidden="true" />
            <span>SFX Off</span>
          </>
        )}
      </button>
    </div>
  );
}
