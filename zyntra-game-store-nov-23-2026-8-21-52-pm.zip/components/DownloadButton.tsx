'use client';

import React, { useState } from 'react';
import { AlertCircle, CheckCircle2, Download, Loader2 } from 'lucide-react';
import { formatBytes } from '@/lib/game-logic';

interface DownloadButtonProps {
  gameId: string;
  filename: string;
  fileFormat: string;
  fileSize: number;
  variant?: 'primary' | 'secondary';
}

export default function DownloadButton({
  gameId,
  filename,
  fileFormat,
  fileSize,
  variant = 'secondary',
}: DownloadButtonProps) {
  const [downloading, setDownloading] = useState(false);
  const [progress, setProgress] = useState<number | null>(null);
  const [done, setDone] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleDownload() {
    if (downloading) return;
    setDownloading(true);
    setProgress(0);
    setDone(false);
    setError(null);

    try {
      const response = await fetch(`/api/games/${encodeURIComponent(gameId)}/download`);
      if (!response.ok) {
        const payload = (await response.json().catch(() => ({}))) as { error?: string };
        throw new Error(payload.error || `Download failed (${response.status})`);
      }

      const contentLengthHeader = response.headers.get('Content-Length');
      const total = contentLengthHeader ? parseInt(contentLengthHeader, 10) : fileSize;

      if (!response.body) {
        const blob = await response.blob();
        triggerSave(blob, filename);
        setProgress(100);
        setDone(true);
        return;
      }

      const reader = response.body.getReader();
      const chunks: Uint8Array[] = [];
      let received = 0;

      while (true) {
        const { done: streamDone, value } = await reader.read();
        if (streamDone) break;
        if (value) {
          chunks.push(value);
          received += value.length;
          if (total > 0) {
            setProgress(Math.min(100, Math.round((received / total) * 100)));
          }
        }
      }

      const merged = new Uint8Array(received);
      let offset = 0;
      for (const chunk of chunks) {
        merged.set(chunk, offset);
        offset += chunk.length;
      }

      const blob = new Blob([merged], { type: 'application/octet-stream' });
      triggerSave(blob, filename);
      setProgress(100);
      setDone(true);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Download failed. Please try again.');
    } finally {
      setDownloading(false);
    }
  }

  function triggerSave(blob: Blob, name: string) {
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = name;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    setTimeout(() => URL.revokeObjectURL(url), 4000);
  }

  const baseClass =
    variant === 'primary'
      ? 'bg-[#0EA5E9] text-white hover:bg-[#0284C7] shadow-[0_0_24px_rgba(14,165,233,0.35)]'
      : 'border border-[#2A2D3D] bg-[#161822] text-[#F4F4F8] hover:border-[#38BDF8]/60 hover:bg-[#1C1F2B]';

  return (
    <div className="space-y-2">
      <button
        type="button"
        onClick={handleDownload}
        disabled={downloading}
        className={`inline-flex w-full items-center justify-center gap-2.5 rounded-lg px-5 py-3 text-sm font-semibold transition-all duration-150 disabled:opacity-70 whitespace-nowrap ${baseClass}`}
      >
        {downloading ? (
          <>
            <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
            <span className="font-mono tabular-nums">
              Downloading{progress !== null ? ` ${progress}%` : '...'}
            </span>
          </>
        ) : done ? (
          <>
            <CheckCircle2 className="h-4 w-4 text-emerald-400" aria-hidden="true" />
            <span>Downloaded ({fileFormat.toUpperCase()} · {formatBytes(fileSize)})</span>
          </>
        ) : (
          <>
            <Download className="h-4 w-4" aria-hidden="true" />
            <span>Download {fileFormat.toUpperCase()} ({formatBytes(fileSize)})</span>
          </>
        )}
      </button>

      {downloading && progress !== null && (
        <div className="h-1.5 w-full overflow-hidden rounded-full bg-[#1C1E2B]">
          <div
            className="h-full bg-gradient-to-r from-[#8B5CF6] to-[#38BDF8] transition-all duration-150"
            style={{ width: `${progress}%` }}
          />
        </div>
      )}

      {error && (
        <p role="alert" className="flex items-center gap-2 text-xs text-rose-400">
          <AlertCircle className="h-3.5 w-3.5 shrink-0" aria-hidden="true" />
          <span>{error}</span>
        </p>
      )}
    </div>
  );
}
