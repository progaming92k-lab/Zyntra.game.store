'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { motion } from 'motion/react';
import { AlertCircle, Eye, EyeOff, KeyRound, Loader2, LogIn, UserPlus } from 'lucide-react';
import { setClientAuthToken } from '@/lib/client-auth';
import { playUiSound } from '@/lib/sound';

interface OwnerLoginGateProps {
  title: string;
  subtitle: string;
  onAuthenticated: (label: string) => void;
}

type AuthTab = 'code' | 'login' | 'register';

export default function OwnerLoginGate({ title, subtitle, onAuthenticated }: OwnerLoginGateProps) {
  const [activeTab, setActiveTab] = useState<AuthTab>('code');
  const [accessCode, setAccessCode] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showSecret, setShowSecret] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  function switchTab(next: AuthTab) {
    setActiveTab(next);
    setError(null);
    setShowSecret(false);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (submitting) return;
    setError(null);
    setSubmitting(true);

    try {
      const endpoint = activeTab === 'register' ? '/api/auth/register' : '/api/auth/login';
      const payload =
        activeTab === 'code'
          ? { mode: 'code', accessCode }
          : { mode: 'account', username, password };

      const res = await fetch(endpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Requested-With': 'ZyntraStore',
        },
        body: JSON.stringify(payload),
      });

      const data = (await res.json().catch(() => ({}))) as {
        authenticated?: boolean;
        token?: string;
        username?: string;
        email?: string;
        error?: string;
      };

      if (!res.ok || !data.authenticated) {
        playUiSound('error');
        setError(
          data.error ||
            (activeTab === 'code'
              ? 'Invalid import access code. Please check and try again.'
              : activeTab === 'register'
                ? 'Could not create account. Check your username and password.'
                : 'Invalid username or password.')
        );
        return;
      }

      if (data.token) {
        setClientAuthToken(data.token);
      }
      playUiSound('success');
      onAuthenticated(data.username || data.email || 'Creator Access');
    } catch {
      playUiSound('error');
      setError('Unable to reach authentication server.');
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.28, ease: 'easeOut' }}
      className="mx-auto max-w-md py-10"
    >
      <div className="rounded-2xl border border-[#262A3E] bg-[#111218]/92 p-7 backdrop-blur-md shadow-[0_24px_64px_rgba(0,0,0,0.55)]">
        <div className="flex items-center gap-3.5">
          <div className="relative h-12 w-12 shrink-0 overflow-hidden rounded-xl border border-[#8B5CF6]/45 shadow-[0_0_20px_rgba(139,92,246,0.3)]">
            <Image
              src="/assets/aistudio/zyntra-ai-logo-rounded_5b64714d.png"
              alt="Zyntra Game Store logo"
              fill
              sizes="48px"
              referrerPolicy="no-referrer"
              className="object-cover"
            />
          </div>
          <div>
            <span className="inline-flex items-center gap-1.5 text-xs font-semibold tracking-wider text-[#38BDF8] uppercase">
              <KeyRound className="h-3.5 w-3.5" aria-hidden="true" />
              <span>Creator Studio</span>
            </span>
            <h1 className="font-display text-2xl font-bold text-[#F4F4F8]">{title}</h1>
          </div>
        </div>

        <p className="mt-3 text-sm leading-relaxed text-[#9CA3B4]">{subtitle}</p>

        {/* Auth Method Tabs */}
        <div
          role="tablist"
          aria-label="Creator sign-in options"
          className="mt-5 grid grid-cols-3 gap-1 rounded-xl border border-[#232638] bg-[#0B0C11] p-1"
        >
          <button
            type="button"
            role="tab"
            aria-selected={activeTab === 'code'}
            onClick={() => switchTab('code')}
            className={`inline-flex items-center justify-center gap-1.5 rounded-lg px-2.5 py-2 text-xs font-semibold transition-all ${
              activeTab === 'code'
                ? 'bg-gradient-to-r from-[#7C3AED] to-[#0EA5E9] text-white shadow-[0_0_16px_rgba(124,58,237,0.35)]'
                : 'text-[#9CA3B4] hover:text-white'
            }`}
          >
            <KeyRound className="h-3.5 w-3.5" aria-hidden="true" />
            <span>Access Code</span>
          </button>
          <button
            type="button"
            role="tab"
            aria-selected={activeTab === 'login'}
            onClick={() => switchTab('login')}
            className={`inline-flex items-center justify-center gap-1.5 rounded-lg px-2.5 py-2 text-xs font-semibold transition-all ${
              activeTab === 'login'
                ? 'bg-gradient-to-r from-[#7C3AED] to-[#0EA5E9] text-white shadow-[0_0_16px_rgba(124,58,237,0.35)]'
                : 'text-[#9CA3B4] hover:text-white'
            }`}
          >
            <LogIn className="h-3.5 w-3.5" aria-hidden="true" />
            <span>Login</span>
          </button>
          <button
            type="button"
            role="tab"
            aria-selected={activeTab === 'register'}
            onClick={() => switchTab('register')}
            className={`inline-flex items-center justify-center gap-1.5 rounded-lg px-2.5 py-2 text-xs font-semibold transition-all ${
              activeTab === 'register'
                ? 'bg-gradient-to-r from-[#7C3AED] to-[#0EA5E9] text-white shadow-[0_0_16px_rgba(124,58,237,0.35)]'
                : 'text-[#9CA3B4] hover:text-white'
            }`}
          >
            <UserPlus className="h-3.5 w-3.5" aria-hidden="true" />
            <span>New Account</span>
          </button>
        </div>

        <form onSubmit={handleSubmit} className="mt-5 space-y-4">
          {activeTab === 'code' ? (
            <div>
              <label htmlFor="import-access-code" className="block text-sm font-medium text-[#D1D5E2]">
                Import Access Code
              </label>
              <div className="zyntra-search-wrap mt-1.5 relative">
                <input
                  id="import-access-code"
                  type={showSecret ? 'text' : 'password'}
                  required
                  autoComplete="off"
                  autoCapitalize="characters"
                  spellCheck={false}
                  value={accessCode}
                  onChange={(e) => setAccessCode(e.target.value)}
                  placeholder="Enter access code"
                  className="w-full rounded-lg border border-[#262938] bg-[#0B0C11] py-2.5 pl-3.5 pr-11 font-mono text-sm text-[#F4F4F8] placeholder-[#5F657A] focus:border-[#8B5CF6] focus:outline-none"
                />
                <button
                  type="button"
                  onClick={() => setShowSecret((prev) => !prev)}
                  aria-label={showSecret ? 'Hide access code' : 'Show access code'}
                  className="absolute right-2 top-1/2 -translate-y-1/2 inline-flex h-8 w-8 items-center justify-center rounded-md text-[#8E94A8] transition-colors hover:text-[#38BDF8]"
                >
                  {showSecret ? <EyeOff className="h-4 w-4" aria-hidden="true" /> : <Eye className="h-4 w-4" aria-hidden="true" />}
                </button>
              </div>
              <p className="mt-1.5 text-xs text-[#7E849A]">
                Enter once to unlock game uploads and publishing—no email required.
              </p>
            </div>
          ) : (
            <>
              <div>
                <label htmlFor="creator-username" className="block text-sm font-medium text-[#D1D5E2]">
                  Creator Username
                </label>
                <input
                  id="creator-username"
                  type="text"
                  required
                  autoComplete="username"
                  spellCheck={false}
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="e.g. jsr_studio"
                  className="mt-1.5 w-full rounded-lg border border-[#262938] bg-[#0B0C11] px-3.5 py-2.5 text-sm text-[#F4F4F8] placeholder-[#5F657A] focus:border-[#8B5CF6] focus:outline-none"
                />
              </div>

              <div>
                <label htmlFor="creator-password" className="block text-sm font-medium text-[#D1D5E2]">
                  Password
                </label>
                <div className="zyntra-search-wrap mt-1.5 relative">
                  <input
                    id="creator-password"
                    type={showSecret ? 'text' : 'password'}
                    required
                    minLength={4}
                    autoComplete={activeTab === 'register' ? 'new-password' : 'current-password'}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder={activeTab === 'register' ? 'Choose a password (min 4 chars)' : 'Enter your password'}
                    className="w-full rounded-lg border border-[#262938] bg-[#0B0C11] py-2.5 pl-3.5 pr-11 text-sm text-[#F4F4F8] placeholder-[#5F657A] focus:border-[#8B5CF6] focus:outline-none"
                  />
                  <button
                    type="button"
                    onClick={() => setShowSecret((prev) => !prev)}
                    aria-label={showSecret ? 'Hide password' : 'Show password'}
                    className="absolute right-2 top-1/2 -translate-y-1/2 inline-flex h-8 w-8 items-center justify-center rounded-md text-[#8E94A8] transition-colors hover:text-[#38BDF8]"
                  >
                    {showSecret ? <EyeOff className="h-4 w-4" aria-hidden="true" /> : <Eye className="h-4 w-4" aria-hidden="true" />}
                  </button>
                </div>
              </div>

              <p className="text-xs text-[#7E849A]">
                {activeTab === 'register'
                  ? 'No Gmail or email address required. Sign up with username and password only.'
                  : 'Sign in using the username and password you created.'}
              </p>
            </>
          )}

          {error && (
            <motion.div
              initial={{ opacity: 0, y: -4 }}
              animate={{ opacity: 1, y: 0 }}
              role="alert"
              className="flex items-start gap-2.5 rounded-lg border border-rose-500/30 bg-rose-500/10 px-3.5 py-2.5 text-sm text-rose-300"
            >
              <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" aria-hidden="true" />
              <span>{error}</span>
            </motion.div>
          )}

          <button
            type="submit"
            disabled={submitting}
            className="zyntra-btn-shine inline-flex w-full items-center justify-center gap-2 rounded-lg bg-gradient-to-r from-[#7C3AED] to-[#0EA5E9] px-5 py-3 text-sm font-semibold text-white shadow-[0_0_24px_rgba(124,58,237,0.35)] transition-all duration-150 hover:scale-[1.01] hover:brightness-110 disabled:opacity-60"
          >
            {submitting ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
                <span>
                  {activeTab === 'register'
                    ? 'Creating Account...'
                    : activeTab === 'login'
                      ? 'Signing In...'
                      : 'Verifying Access Code...'}
                </span>
              </>
            ) : (
              <span>
                {activeTab === 'register'
                  ? 'Create Creator Account'
                  : activeTab === 'login'
                    ? 'Login to Studio'
                    : 'Unlock Creator Access'}
              </span>
            )}
          </button>
        </form>
      </div>
    </motion.div>
  );
}
