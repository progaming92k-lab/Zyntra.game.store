'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { motion } from 'motion/react';
import { Download, Gamepad2, Play } from 'lucide-react';
import { formatBytes } from '@/lib/game-logic';
import type { GameRecord } from '@/lib/types';

interface GameCardProps {
  game: GameRecord;
}

export default function GameCard({ game }: GameCardProps) {
  const [imgError, setImgError] = useState(false);

  return (
    <motion.article
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -4 }}
      transition={{ duration: 0.22, ease: 'easeOut' }}
      className="group flex flex-col overflow-hidden rounded-xl border border-[#242738] bg-[#111218]/86 backdrop-blur-md transition-colors duration-200 hover:border-[#8B5CF6]/70 hover:shadow-[0_16px_38px_rgba(139,92,246,0.22)]"
    >
      <Link href={`/games/${game.slug}`} className="relative block aspect-video w-full overflow-hidden bg-[#0A0B10]">
        {!imgError && game.coverImage ? (
          <img
            src={game.coverImage}
            alt={`${game.title} cover art`}
            referrerPolicy="no-referrer"
            onError={() => setImgError(true)}
            className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-[1.04]"
          />
        ) : (
          <div className="flex h-full w-full flex-col items-center justify-center bg-gradient-to-br from-[#12131D] via-[#171528] to-[#0B1520] p-4 text-center">
            <Gamepad2 className="h-8 w-8 text-[#8B5CF6]" aria-hidden="true" />
            <span className="mt-2 font-display text-sm font-semibold text-[#F4F4F8]">{game.title}</span>
          </div>
        )}
        <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-[#111218]/80 via-transparent to-transparent" />
      </Link>

      <div className="flex flex-1 flex-col p-5">
        <div className="flex flex-wrap items-center gap-1.5 text-xs text-[#8E94A8]">
          <span className="font-medium text-[#38BDF8]">{game.category}</span>
          <span aria-hidden="true">·</span>
          <span>{game.platform}</span>
          <span aria-hidden="true">·</span>
          <span className="font-mono tabular-nums">v{game.version}</span>
          <span aria-hidden="true">·</span>
          <span className="font-mono tabular-nums">{formatBytes(game.fileSize)}</span>
          <span aria-hidden="true">·</span>
          <span className="font-medium text-emerald-400">
            {game.pricingType === 'paid' ? game.priceLabel || 'Paid' : 'Free'}
          </span>
        </div>

        <Link href={`/games/${game.slug}`} className="mt-2 block">
          <h3 className="font-display text-lg font-semibold leading-snug text-[#F4F4F8] transition-colors group-hover:text-[#38BDF8] line-clamp-1">
            {game.title}
          </h3>
        </Link>

        <p className="mt-2 flex-1 text-sm leading-relaxed text-[#9CA3B4] line-clamp-2">
          {game.shortDescription}
        </p>

        <div className="mt-5 flex items-center gap-2.5 pt-3 border-t border-[#1B1D28]">
          {game.isBrowserPlayable ? (
            <Link
              href={`/games/${game.slug}/play`}
              className="zyntra-btn-shine inline-flex flex-1 items-center justify-center gap-2 rounded-lg bg-gradient-to-r from-[#8B5CF6] to-[#7C3AED] px-4 py-2 text-sm font-semibold text-white transition-all duration-150 hover:scale-[1.02] hover:shadow-[0_0_20px_rgba(139,92,246,0.5)] whitespace-nowrap"
            >
              <Play className="h-4 w-4 fill-current" aria-hidden="true" />
              <span>Play Game</span>
            </Link>
          ) : (
            <a
              href={`/api/games/${game.id}/download`}
              className="zyntra-btn-shine inline-flex flex-1 items-center justify-center gap-2 rounded-lg bg-gradient-to-r from-[#0EA5E9] to-[#0284C7] px-4 py-2 text-sm font-semibold text-white transition-all duration-150 hover:scale-[1.02] hover:shadow-[0_0_20px_rgba(14,165,233,0.45)] whitespace-nowrap"
            >
              <Download className="h-4 w-4" aria-hidden="true" />
              <span>Download</span>
            </a>
          )}

          <Link
            href={`/games/${game.slug}`}
            className="inline-flex items-center justify-center rounded-lg border border-[#272A3A] bg-[#161822] px-3.5 py-2 text-sm font-medium text-[#D1D5E2] transition-colors hover:border-[#38BDF8]/60 hover:text-white whitespace-nowrap shrink-0"
          >
            Details
          </Link>
        </div>
      </div>
    </motion.article>
  );
}
