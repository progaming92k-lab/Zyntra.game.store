import React from 'react';
import Image from 'next/image';

interface ZyntraLoaderProps {
  title?: string;
  subtitle?: string;
  compact?: boolean;
}

export default function ZyntraLoader({
  title = 'Loading Zyntra...',
  subtitle = 'Preparing storefront experience',
  compact = false,
}: ZyntraLoaderProps) {
  return (
    <div
      role="status"
      aria-live="polite"
      data-testid="zyntra-z-loader"
      className={`flex flex-col items-center justify-center text-center ${
        compact ? 'py-4' : 'py-16'
      }`}
    >
      <div className="relative flex h-20 w-20 items-center justify-center">
        {/* Ambient halo */}
        <div
          aria-hidden="true"
          className="absolute inset-0 rounded-full bg-gradient-to-tr from-[#7C3AED]/35 to-[#38BDF8]/35 blur-md"
        />
        {/* Rotating dual-arc orbital ring */}
        <div
          aria-hidden="true"
          className="absolute inset-0 rounded-full border-2 border-[#26293B] border-t-[#38BDF8] border-r-[#A855F7] animate-spin"
        />
        {/* Official Zyntra Logo */}
        <div className="relative h-14 w-14 overflow-hidden rounded-2xl border border-[#2C3046] bg-[#0D0E15] shadow-[0_0_20px_rgba(139,92,246,0.35)]">
          <Image
            src="/assets/aistudio/zyntra-ai-logo-rounded_5b64714d.png"
            alt="Zyntra Game Store logo"
            fill
            sizes="56px"
            referrerPolicy="no-referrer"
            className="object-cover"
          />
        </div>
      </div>

      <p className="mt-4 font-display text-base font-bold text-[#F4F4F8] sm:text-lg">
        {title}
      </p>
      {subtitle && <p className="mt-1 text-xs text-[#8E94A8]">{subtitle}</p>}
    </div>
  );
}
