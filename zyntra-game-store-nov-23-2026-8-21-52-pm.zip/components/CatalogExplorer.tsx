'use client';

import React, { useMemo, useState } from 'react';
import { Search, SlidersHorizontal } from 'lucide-react';
import GameCard from './GameCard';
import EmptyStoreState from './EmptyStoreState';
import { filterAndSortGames } from '@/lib/game-logic';
import type { CategoryRecord, GameRecord } from '@/lib/types';

interface CatalogExplorerProps {
  initialGames: GameRecord[];
  categories: CategoryRecord[];
  initialQuery?: string;
  initialCategory?: string;
  heading?: string;
  subheading?: string;
}

const PLATFORMS = ['All', 'HTML5', 'Unity WebGL', 'Android', 'PC', 'Other'];

export default function CatalogExplorer({
  initialGames,
  categories,
  initialQuery = '',
  initialCategory = 'All',
  heading = 'All Games',
  subheading = 'Browse every published release across HTML5, WebGL, Android, and desktop builds.',
}: CatalogExplorerProps) {
  const [query, setQuery] = useState(initialQuery);
  const [category, setCategory] = useState(initialCategory);
  const [platform, setPlatform] = useState('All');
  const [sort, setSort] = useState<'newest' | 'popular' | 'downloads' | 'title'>('newest');

  const filtered = useMemo(
    () =>
      filterAndSortGames(initialGames, {
        query,
        category: category === 'All' ? '' : category,
        platform: platform === 'All' ? '' : platform,
        sort,
        status: 'published',
      }),
    [initialGames, query, category, platform, sort]
  );

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
      <div className="flex flex-col gap-4 border-b border-[#1D1F2B] pb-8 md:flex-row md:items-end md:justify-between">
        <div>
          <h1 className="font-display text-3xl font-bold text-[#F4F4F8] sm:text-4xl">{heading}</h1>
          <p className="mt-2 max-w-2xl text-sm text-[#9CA3B4] sm:text-base">{subheading}</p>
        </div>
        <div className="font-mono text-xs text-[#8E94A8] tabular-nums">
          {filtered.length} {filtered.length === 1 ? 'title' : 'titles'} shown
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="mt-6 grid grid-cols-1 gap-3 lg:grid-cols-12">
        <div className="zyntra-search-wrap relative lg:col-span-6">
          <Search
            className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-[#38BDF8]/80"
            aria-hidden="true"
          />
          <input
            type="search"
            aria-label="Search games by title, genre, tags, or developer"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search by title, category, genre, tags, or developer..."
            className="w-full rounded-lg border border-[#232634] bg-[#111218]/90 py-2.5 pl-10 pr-4 text-sm text-[#F4F4F8] placeholder-[#676D82] transition-colors focus:border-[#38BDF8] focus:outline-none"
          />
        </div>

        <div className="lg:col-span-3">
          <label htmlFor="platform-filter" className="sr-only">
            Filter by platform
          </label>
          <select
            id="platform-filter"
            value={platform}
            onChange={(e) => setPlatform(e.target.value)}
            className="w-full rounded-lg border border-[#232634] bg-[#111218] px-3.5 py-2.5 text-sm text-[#F4F4F8] focus:border-[#38BDF8] focus:outline-none"
          >
            {PLATFORMS.map((p) => (
              <option key={p} value={p}>
                Platform: {p}
              </option>
            ))}
          </select>
        </div>

        <div className="lg:col-span-3">
          <label htmlFor="sort-filter" className="sr-only">
            Sort games
          </label>
          <div className="relative">
            <SlidersHorizontal
              className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-[#73788C]"
              aria-hidden="true"
            />
            <select
              id="sort-filter"
              value={sort}
              onChange={(e) => setSort(e.target.value as 'newest' | 'popular' | 'downloads' | 'title')}
              className="w-full rounded-lg border border-[#232634] bg-[#111218] py-2.5 pl-10 pr-4 text-sm text-[#F4F4F8] focus:border-[#38BDF8] focus:outline-none"
            >
              <option value="newest">Sort: Newest Releases</option>
              <option value="popular">Sort: Most Popular</option>
              <option value="downloads">Sort: Most Downloaded</option>
              <option value="title">Sort: Title A–Z</option>
            </select>
          </div>
        </div>
      </div>

      {/* Category Filter Buttons */}
      <div className="mt-5 flex flex-wrap items-center gap-1.5" role="group" aria-label="Filter by category">
        <button
          type="button"
          onClick={() => setCategory('All')}
          className={`rounded-lg px-3 py-1.5 text-xs font-medium transition-all duration-150 hover:scale-[1.03] whitespace-nowrap ${
            category === 'All'
              ? 'bg-gradient-to-r from-[#8B5CF6] to-[#0EA5E9] text-white shadow-[0_0_16px_rgba(139,92,246,0.35)]'
              : 'border border-[#232634] bg-[#111218]/90 text-[#A0A4B8] hover:border-[#38BDF8]/50 hover:text-white'
          }`}
        >
          All
        </button>
        {categories.map((cat) => (
          <button
            key={cat.id}
            type="button"
            onClick={() => setCategory(cat.name)}
            className={`rounded-lg px-3 py-1.5 text-xs font-medium transition-all duration-150 hover:scale-[1.03] whitespace-nowrap ${
              category.toLowerCase() === cat.name.toLowerCase()
                ? 'bg-gradient-to-r from-[#8B5CF6] to-[#0EA5E9] text-white shadow-[0_0_16px_rgba(139,92,246,0.35)]'
                : 'border border-[#232634] bg-[#111218]/90 text-[#A0A4B8] hover:border-[#38BDF8]/50 hover:text-white'
            }`}
          >
            {cat.name}
          </button>
        ))}
      </div>

      {/* Results Grid */}
      <div className="mt-8">
        {initialGames.length === 0 ? (
          <EmptyStoreState />
        ) : filtered.length === 0 ? (
          <div className="rounded-xl border border-[#222432] bg-[#111218] p-12 text-center">
            <h2 className="font-display text-xl font-semibold text-[#F4F4F8]">No matching games found</h2>
            <p className="mt-2 text-sm text-[#9CA3B4]">
              Try adjusting your search keywords, platform filter, or selected category.
            </p>
            <button
              type="button"
              onClick={() => {
                setQuery('');
                setCategory('All');
                setPlatform('All');
              }}
              className="mt-5 rounded-lg border border-[#2C3042] bg-[#181A24] px-4 py-2 text-sm font-medium text-[#38BDF8] hover:border-[#38BDF8]"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {filtered.map((game) => (
              <GameCard key={game.id} game={game} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
