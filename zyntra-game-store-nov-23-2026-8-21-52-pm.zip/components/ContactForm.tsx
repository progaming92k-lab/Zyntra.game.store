'use client';

import React, { useState } from 'react';
import { AlertCircle, CheckCircle2, Loader2, Send } from 'lucide-react';
import { playUiSound } from '@/lib/sound';

export default function ContactForm() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [sent, setSent] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (submitting) return;
    setError(null);
    setSent(false);
    setSubmitting(true);

    try {
      const res = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, subject, message }),
      });
      const data = (await res.json().catch(() => ({}))) as { saved?: boolean; error?: string };
      if (!res.ok || !data.saved) {
        throw new Error(data.error || 'Failed to send message.');
      }
      playUiSound('success');
      setSent(true);
      setName('');
      setEmail('');
      setSubject('');
      setMessage('');
    } catch (err) {
      playUiSound('error');
      setError(err instanceof Error ? err.message : 'Unable to send message.');
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4 rounded-2xl border border-[#232634] bg-[#111218]/86 p-6 backdrop-blur-md sm:p-8">
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <div>
          <label htmlFor="contact-name" className="block text-sm font-medium text-[#D1D5E2]">
            Your Name
          </label>
          <input
            id="contact-name"
            type="text"
            required
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Alex Rivera"
            className="mt-1.5 w-full rounded-lg border border-[#262938] bg-[#0B0C11] px-3.5 py-2.5 text-sm text-[#F4F4F8] placeholder-[#5F657A] focus:border-[#38BDF8] focus:outline-none"
          />
        </div>
        <div>
          <label htmlFor="contact-email" className="block text-sm font-medium text-[#D1D5E2]">
            Email Address
          </label>
          <input
            id="contact-email"
            type="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="you@example.com"
            className="mt-1.5 w-full rounded-lg border border-[#262938] bg-[#0B0C11] px-3.5 py-2.5 text-sm text-[#F4F4F8] placeholder-[#5F657A] focus:border-[#38BDF8] focus:outline-none"
          />
        </div>
      </div>

      <div>
        <label htmlFor="contact-subject" className="block text-sm font-medium text-[#D1D5E2]">
          Subject
        </label>
        <input
          id="contact-subject"
          type="text"
          required
          value={subject}
          onChange={(e) => setSubject(e.target.value)}
          placeholder="Game feedback, bug report, or inquiry"
          className="mt-1.5 w-full rounded-lg border border-[#262938] bg-[#0B0C11] px-3.5 py-2.5 text-sm text-[#F4F4F8] placeholder-[#5F657A] focus:border-[#38BDF8] focus:outline-none"
        />
      </div>

      <div>
        <label htmlFor="contact-message" className="block text-sm font-medium text-[#D1D5E2]">
          Message
        </label>
        <textarea
          id="contact-message"
          rows={5}
          required
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          placeholder="Write your message here..."
          className="mt-1.5 w-full rounded-lg border border-[#262938] bg-[#0B0C11] px-3.5 py-2.5 text-sm text-[#F4F4F8] placeholder-[#5F657A] focus:border-[#38BDF8] focus:outline-none"
        />
      </div>

      {sent && (
        <div className="flex items-center gap-2 rounded-lg border border-emerald-500/35 bg-emerald-500/10 px-4 py-3 text-sm text-emerald-300">
          <CheckCircle2 className="h-4 w-4 shrink-0" aria-hidden="true" />
          <span>Your message has been received. Thank you for contacting Zyntra Game Store.</span>
        </div>
      )}

      {error && (
        <div role="alert" className="flex items-center gap-2 rounded-lg border border-rose-500/35 bg-rose-500/10 px-4 py-3 text-sm text-rose-300">
          <AlertCircle className="h-4 w-4 shrink-0" aria-hidden="true" />
          <span>{error}</span>
        </div>
      )}

      <button
        type="submit"
        disabled={submitting}
        className="inline-flex items-center gap-2 rounded-lg bg-gradient-to-r from-[#7C3AED] to-[#0EA5E9] px-6 py-2.5 text-sm font-semibold text-white transition-all hover:brightness-110 disabled:opacity-60"
      >
        {submitting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
        <span>Send Message</span>
      </button>
    </form>
  );
}
