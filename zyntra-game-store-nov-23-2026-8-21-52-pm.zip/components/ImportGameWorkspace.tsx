'use client';

import React, { useMemo, useRef, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import {
  AlertCircle,
  ArrowLeft,
  ArrowRight,
  CalendarClock,
  CheckCircle2,
  Cpu,
  Download,
  ExternalLink,
  Eye,
  FileArchive,
  FileUp,
  Gamepad2,
  Globe,
  GlobeLock,
  ImagePlus,
  Images,
  Info,
  Loader2,
  LogOut,
  Play,
  Rocket,
  Save,
  Settings,
  Sparkles,
  Trash2,
  Upload,
} from 'lucide-react';
import OwnerLoginGate from './OwnerLoginGate';
import ShareButton from './ShareButton';
import ZyntraLoader from './ZyntraLoader';
import { buildAuthHeaders, clearClientAuthToken } from '@/lib/client-auth';
import { formatBytes } from '@/lib/game-logic';
import { playUiSound } from '@/lib/sound';
import type {
  CategoryRecord,
  GameLifecycleStatus,
  GamePlatform,
  GameRecord,
  GameStatus,
  GameVisibility,
  PricingType,
} from '@/lib/types';

interface ImportGameWorkspaceProps {
  initialAuthenticated: boolean;
  initialEmail: string | null;
  categories: CategoryRecord[];
  initialGame?: GameRecord | null;
}

type PublishingStage =
  | 'import'
  | 'detection'
  | 'info'
  | 'media'
  | 'settings'
  | 'preview'
  | 'publish'
  | 'public_page';

const STAGES: Array<{ id: PublishingStage; label: string; shortLabel: string }> = [
  { id: 'import', label: 'Import Game', shortLabel: '1. Import' },
  { id: 'detection', label: 'Automatic Detection', shortLabel: '2. Detection' },
  { id: 'info', label: 'Game Information', shortLabel: '3. Info' },
  { id: 'media', label: 'Media & Screenshots', shortLabel: '4. Media' },
  { id: 'settings', label: 'Settings', shortLabel: '5. Settings' },
  { id: 'preview', label: 'Preview', shortLabel: '6. Preview' },
  { id: 'publish', label: 'Publish', shortLabel: '7. Publish' },
  { id: 'public_page', label: 'Public Game Page', shortLabel: '8. Public Page' },
];

const PLATFORMS: GamePlatform[] = [
  'HTML5',
  'Unity WebGL',
  'Web',
  'Android',
  'Windows',
  'iOS',
  'PC',
  'Mac',
  'Linux',
  'Cross-Platform',
  'Other',
];

const GAME_STATUSES: GameLifecycleStatus[] = ['Released', 'Beta', 'Early Access', 'Alpha'];

export default function ImportGameWorkspace({
  initialAuthenticated,
  initialEmail,
  categories,
  initialGame = null,
}: ImportGameWorkspaceProps) {
  const router = useRouter();
  const [authenticated, setAuthenticated] = useState(initialAuthenticated);
  const [creatorName, setCreatorName] = useState(initialEmail);
  const [stage, setStage] = useState<PublishingStage>(initialGame ? 'detection' : 'import');
  const [dragActive, setDragActive] = useState(false);
  const [analyzing, setAnalyzing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [replacingFile, setReplacingFile] = useState(false);
  const [confirmDeleteOpen, setConfirmDeleteOpen] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [draft, setDraft] = useState<GameRecord | null>(initialGame);
  const [tagsInput, setTagsInput] = useState(initialGame ? initialGame.tags.join(', ') : '');
  const [releaseMode, setReleaseMode] = useState<'now' | 'schedule'>(
    initialGame?.status === 'scheduled' ? 'schedule' : 'now'
  );
  const [scheduleInput, setScheduleInput] = useState(
    initialGame?.scheduledReleaseAt ? initialGame.scheduledReleaseAt.slice(0, 16) : ''
  );
  const [newVersionInput, setNewVersionInput] = useState(initialGame?.version || '');

  const fileInputRef = useRef<HTMLInputElement>(null);
  const replaceFileInputRef = useRef<HTMLInputElement>(null);

  const stageIndex = useMemo(() => STAGES.findIndex((s) => s.id === stage), [stage]);

  async function handleLogout() {
    await fetch('/api/auth/logout', {
      method: 'POST',
      headers: buildAuthHeaders(),
    }).catch(() => {});
    clearClientAuthToken();
    setAuthenticated(false);
    setCreatorName(null);
    setDraft(null);
    setStage('import');
  }

  async function handleFileSelected(file: File) {
    setError(null);
    setNotice(null);
    setAnalyzing(true);

    try {
      const formData = new FormData();
      formData.append('file', file);

      const res = await fetch('/api/import/analyze', {
        method: 'POST',
        headers: buildAuthHeaders(),
        body: formData,
      });

      const data = (await res.json().catch(() => ({}))) as { game?: GameRecord; error?: string };
      if (!res.ok || !data.game) {
        if (res.status === 401) {
          setAuthenticated(false);
        }
        throw new Error(data.error || 'Could not analyze uploaded game file.');
      }

      playUiSound('success');
      setDraft(data.game);
      setTagsInput(data.game.tags.join(', '));
      setNewVersionInput(data.game.version);
      setReleaseMode('now');
      setScheduleInput('');
      setStage('detection');
    } catch (err) {
      playUiSound('error');
      setError(err instanceof Error ? err.message : 'Upload failed. Please try again.');
    } finally {
      setAnalyzing(false);
    }
  }

  async function handleUploadImage(kind: 'cover' | 'icon' | 'screenshot', file: File) {
    if (!draft) return;
    setError(null);
    setNotice(null);
    const fd = new FormData();
    fd.append('kind', kind);
    fd.append('file', file);

    const res = await fetch(`/api/games/${encodeURIComponent(draft.id)}/upload-image`, {
      method: 'POST',
      headers: buildAuthHeaders(),
      body: fd,
    });
    const data = (await res.json().catch(() => ({}))) as { game?: GameRecord; error?: string };
    if (res.ok && data.game) {
      setDraft(data.game);
      playUiSound('success');
      setNotice(
        kind === 'screenshot'
          ? 'Screenshot uploaded.'
          : kind === 'icon'
            ? 'Game icon updated.'
            : 'Cover image updated.'
      );
    } else {
      playUiSound('error');
      setError(data.error || 'Failed to upload image.');
    }
  }

  async function handleRemoveScreenshot(url: string) {
    if (!draft) return;
    const nextShots = draft.screenshots.filter((s) => s !== url);
    setDraft({ ...draft, screenshots: nextShots });
    await fetch(`/api/games/${encodeURIComponent(draft.id)}`, {
      method: 'PATCH',
      headers: buildAuthHeaders({ 'Content-Type': 'application/json' }),
      body: JSON.stringify({ screenshots: nextShots }),
    }).catch(() => {});
  }

  async function handleReplaceBuildFile(file: File) {
    if (!draft || replacingFile) return;
    setReplacingFile(true);
    setError(null);
    setNotice(null);
    try {
      const fd = new FormData();
      fd.append('file', file);
      if (newVersionInput.trim()) {
        fd.append('version', newVersionInput.trim());
      }
      const res = await fetch(`/api/games/${encodeURIComponent(draft.id)}/replace-file`, {
        method: 'POST',
        headers: buildAuthHeaders(),
        body: fd,
      });
      const data = (await res.json().catch(() => ({}))) as { game?: GameRecord; error?: string };
      if (!res.ok || !data.game) {
        throw new Error(data.error || 'Failed to replace game file.');
      }
      setDraft(data.game);
      setNewVersionInput(data.game.version);
      playUiSound('success');
      setNotice(`Build replaced (${data.game.originalFilename}) · v${data.game.version}`);
      router.refresh();
    } catch (err) {
      playUiSound('error');
      setError(err instanceof Error ? err.message : 'Unable to replace game file.');
    } finally {
      setReplacingFile(false);
    }
  }

  async function saveGameState(targetStatus: GameStatus, goPublicStage = false) {
    if (!draft || saving) return;
    setSaving(true);
    setError(null);
    setNotice(null);

    try {
      const parsedTags = tagsInput
        .split(',')
        .map((t) => t.trim())
        .filter(Boolean);

      let scheduledIso: string | null = null;
      if (targetStatus === 'scheduled') {
        if (!scheduleInput) {
          throw new Error('Please choose a release date and time for scheduled publishing.');
        }
        const dt = new Date(scheduleInput);
        if (Number.isNaN(dt.getTime())) {
          throw new Error('Invalid scheduled release date/time.');
        }
        scheduledIso = dt.toISOString();
      }

      const res = await fetch(`/api/games/${encodeURIComponent(draft.id)}`, {
        method: 'PATCH',
        headers: buildAuthHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify({
          title: draft.title,
          shortTitle: draft.shortTitle,
          slug: draft.slug,
          shortDescription: draft.shortDescription,
          fullDescription: draft.fullDescription,
          category: draft.category,
          genre: draft.genre,
          platform: draft.platform,
          version: newVersionInput.trim() || draft.version,
          developer: draft.developer,
          publisher: draft.publisher,
          ageRating: draft.ageRating,
          contentRating: draft.contentRating,
          languages: draft.languages,
          playerMode: draft.playerMode,
          internetRequirement: draft.internetRequirement,
          controls: draft.controls,
          instructions: draft.instructions,
          minRequirements: draft.minRequirements,
          recRequirements: draft.recRequirements,
          privacyPolicy: draft.privacyPolicy,
          termsConditions: draft.termsConditions,
          copyrightInfo: draft.copyrightInfo,
          permissions: draft.permissions,
          releaseDate: draft.releaseDate,
          gameStatus: draft.gameStatus,
          visibility: draft.visibility,
          featured: draft.featured,
          trending: draft.trending,
          pricingType: draft.pricingType,
          priceLabel: draft.pricingType === 'free' ? 'Free' : draft.priceLabel || '$4.99',
          isBrowserPlayable: draft.isBrowserPlayable,
          isDownloadable: draft.isDownloadable,
          collectionName: draft.collectionName,
          tags: parsedTags,
          screenshots: draft.screenshots,
          scheduledReleaseAt: scheduledIso,
          status: targetStatus,
        }),
      });

      const data = (await res.json().catch(() => ({}))) as { game?: GameRecord; error?: string };
      if (!res.ok || !data.game) {
        if (res.status === 401) setAuthenticated(false);
        throw new Error(data.error || 'Failed to save listing.');
      }

      setDraft(data.game);
      setNewVersionInput(data.game.version);
      playUiSound('success');
      router.refresh();

      if (goPublicStage || targetStatus === 'published' || targetStatus === 'scheduled') {
        setStage('public_page');
        setNotice(
          targetStatus === 'scheduled'
            ? `Release scheduled for ${new Date(scheduledIso!).toLocaleString()}.`
            : `${data.game.title} is now live on Zyntra Game Store!`
        );
      } else if (targetStatus === 'unpublished') {
        setNotice('Game unpublished from the public store.');
      } else {
        setNotice('Draft saved to Zyntra database.');
      }
    } catch (err) {
      playUiSound('error');
      setError(err instanceof Error ? err.message : 'Unable to save game listing.');
    } finally {
      setSaving(false);
    }
  }

  async function handleDeleteDraft() {
    if (!draft) return;
    setSaving(true);
    try {
      const res = await fetch(`/api/games/${encodeURIComponent(draft.id)}`, {
        method: 'DELETE',
        headers: buildAuthHeaders(),
      });
      if (!res.ok) throw new Error('Failed to delete game.');
      playUiSound('success');
      setConfirmDeleteOpen(false);
      setDraft(null);
      setStage('import');
      setNotice('Game deleted permanently.');
      router.refresh();
    } catch (err) {
      playUiSound('error');
      setError(err instanceof Error ? err.message : 'Unable to delete game.');
    } finally {
      setSaving(false);
    }
  }

  if (!authenticated) {
    return (
      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        <OwnerLoginGate
          title="Import Game Studio"
          subtitle="Sign in with Access Code or your Creator Username & Password—no email required."
          onAuthenticated={(label) => {
            setCreatorName(label);
            setAuthenticated(true);
          }}
        />
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-6xl px-4 py-8 sm:px-6 lg:px-8">
      {/* Studio Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-[#1D1F2B] pb-5">
        <div>
          <h1 className="font-display text-2xl font-bold text-[#F4F4F8] sm:text-3xl">
            Game Publishing Dashboard
          </h1>
          <p className="mt-1 text-sm text-[#9CA3B4]">
            Upload any game package—automatic detection populates all 32 fields for one-click publishing.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          {creatorName && (
            <span className="rounded-lg border border-[#262938] bg-[#111218] px-3 py-1.5 text-xs font-medium text-[#38BDF8]">
              {creatorName}
            </span>
          )}
          <Link
            href="/admin"
            className="rounded-lg border border-[#262938] bg-[#111218] px-3.5 py-2 text-xs font-semibold text-[#D1D5E2] hover:border-[#38BDF8]/60 hover:text-white whitespace-nowrap"
          >
            Admin Dashboard
          </Link>
          <button
            type="button"
            onClick={handleLogout}
            className="inline-flex items-center gap-1.5 rounded-lg border border-[#262938] bg-[#111218] px-3.5 py-2 text-xs font-semibold text-[#9CA3B4] hover:text-white whitespace-nowrap"
          >
            <LogOut className="h-3.5 w-3.5" aria-hidden="true" />
            <span>Sign Out</span>
          </button>
        </div>
      </div>

      {/* 8-Stage Pipeline Stepper */}
      <nav aria-label="Publishing stages" className="mt-6 overflow-x-auto pb-2">
        <ol className="flex min-w-max items-center gap-1.5">
          {STAGES.map((st, idx) => {
            const isActive = stage === st.id;
            const isDisabled = st.id !== 'import' && !draft;
            return (
              <li key={st.id} className="flex items-center gap-1.5">
                <button
                  type="button"
                  disabled={isDisabled}
                  onClick={() => setStage(st.id)}
                  className={`rounded-lg border px-3 py-1.5 text-xs font-semibold transition-all whitespace-nowrap ${
                    isActive
                      ? 'border-[#8B5CF6] bg-gradient-to-r from-[#7C3AED]/30 to-[#0EA5E9]/25 text-white shadow-[0_0_16px_rgba(139,92,246,0.25)]'
                      : isDisabled
                        ? 'cursor-not-allowed border-[#1B1D29] bg-[#0D0E14] text-[#4E5368]'
                        : 'border-[#252838] bg-[#111218] text-[#A5ABBE] hover:border-[#38BDF8]/60 hover:text-white'
                  }`}
                >
                  {st.shortLabel}
                </button>
                {idx < STAGES.length - 1 && (
                  <span className="text-xs text-[#3A3E52]" aria-hidden="true">
                    →
                  </span>
                )}
              </li>
            );
          })}
        </ol>
      </nav>

      {error && (
        <div
          role="alert"
          className="mt-4 flex items-center gap-2.5 rounded-xl border border-rose-500/35 bg-rose-500/10 px-4 py-3 text-sm text-rose-300"
        >
          <AlertCircle className="h-4 w-4 shrink-0" aria-hidden="true" />
          <span>{error}</span>
        </div>
      )}

      {notice && (
        <div
          role="status"
          className="mt-4 flex items-center gap-2.5 rounded-xl border border-emerald-500/35 bg-emerald-500/10 px-4 py-3 text-sm text-emerald-300"
        >
          <CheckCircle2 className="h-4 w-4 shrink-0" aria-hidden="true" />
          <span>{notice}</span>
        </div>
      )}

      {/* STAGE 1: IMPORT GAME */}
      {stage === 'import' && !analyzing && (
        <div className="mt-6">
          <div
            onDragOver={(e) => {
              e.preventDefault();
              setDragActive(true);
            }}
            onDragLeave={() => setDragActive(false)}
            onDrop={(e) => {
              e.preventDefault();
              setDragActive(false);
              const file = e.dataTransfer.files?.[0];
              if (file) handleFileSelected(file);
            }}
            className={`relative flex flex-col items-center justify-center rounded-2xl border-2 border-dashed px-6 py-16 text-center transition-all ${
              dragActive
                ? 'border-[#38BDF8] bg-[#38BDF8]/10'
                : 'border-[#2A2D3E] bg-[#101118]/90 hover:border-[#8B5CF6]/70'
            }`}
          >
            <div className="flex h-16 w-16 items-center justify-center rounded-2xl border border-[#8B5CF6]/40 bg-[#8B5CF6]/15 text-[#A855F7]">
              <FileArchive className="h-7 w-7" aria-hidden="true" />
            </div>

            <h2 className="mt-5 font-display text-2xl font-bold text-[#F4F4F8]">
              Drop your game file here
            </h2>
            <p className="mt-2 max-w-xl text-sm leading-relaxed text-[#9CA3B4]">
              Supports HTML5 &amp; Unity WebGL ZIP archives (with index.html), standalone HTML games, Android APK/AAB, Windows (.exe/.msi), iOS (.ipa), Mac (.dmg), and Linux builds.
            </p>

            <input
              ref={fileInputRef}
              type="file"
              aria-label="Select game file to upload"
              accept=".zip,.html,.htm,.apk,.aab,.ipa,.exe,.msi,.dmg,.appimage,.tar.gz,.rar,.7z,.unitypackage"
              onChange={(e) => {
                const file = e.target.files?.[0];
                if (file) handleFileSelected(file);
              }}
              className="sr-only"
            />

            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="zyntra-btn-shine mt-7 inline-flex items-center gap-2 rounded-lg bg-gradient-to-r from-[#7C3AED] to-[#0EA5E9] px-6 py-3 text-sm font-semibold text-white shadow-[0_0_24px_rgba(124,58,237,0.35)] transition-all duration-200 hover:scale-[1.02] hover:brightness-110"
            >
              <Upload className="h-4 w-4" aria-hidden="true" />
              <span>Select Game File</span>
            </button>
          </div>
        </div>
      )}

      {/* ANALYZING LOADER */}
      {analyzing && (
        <div className="mt-6 rounded-2xl border border-[#232634] bg-[#111218]/90 p-10 text-center backdrop-blur-md">
          <ZyntraLoader
            compact
            title="Analyzing Game Package..."
            subtitle="Auto-detecting format, platform, metadata, controls, permissions, requirements, and generating storefront assets."
          />
        </div>
      )}

      {/* STAGES 2-8 DASHBOARD */}
      {draft && !analyzing && stage !== 'import' && (
        <div className="mt-6 space-y-6">
          {/* Persistent Quick-Publish Summary Bar */}
          <div className="flex flex-wrap items-center justify-between gap-4 rounded-xl border border-[#232634] bg-[#111218]/90 p-4">
            <div className="flex items-center gap-3.5 min-w-0">
              <img
                src={draft.iconImage}
                alt={`${draft.title} icon`}
                referrerPolicy="no-referrer"
                className="h-12 w-12 shrink-0 rounded-xl border border-[#282B3D] object-cover"
              />
              <div className="min-w-0">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="font-display text-base font-bold text-white truncate max-w-[260px]">
                    {draft.title}
                  </span>
                  <span className="font-mono text-xs text-[#38BDF8]">v{newVersionInput || draft.version}</span>
                  <span className="text-xs text-[#8E94A8]">·</span>
                  <span
                    className={`text-xs font-semibold ${
                      draft.status === 'published'
                        ? 'text-emerald-400'
                        : draft.status === 'scheduled'
                          ? 'text-[#38BDF8]'
                          : 'text-amber-300'
                    }`}
                  >
                    {draft.status.toUpperCase()}
                  </span>
                  <span className="text-xs text-[#8E94A8]">· {draft.visibility.toUpperCase()}</span>
                </div>
                <p className="mt-0.5 text-xs text-[#8E94A8] truncate">
                  ID: <span className="font-mono">{draft.id.slice(0, 8)}</span> · {draft.originalFilename} (
                  <span className="font-mono">{formatBytes(draft.fileSize)}</span>)
                </p>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                disabled={saving}
                onClick={() => saveGameState('draft')}
                className="inline-flex items-center gap-1.5 rounded-lg border border-[#282B3B] bg-[#161822] px-3.5 py-2 text-xs font-semibold text-[#F4F4F8] hover:border-[#38BDF8]/60 disabled:opacity-60 whitespace-nowrap"
              >
                <Save className="h-3.5 w-3.5" aria-hidden="true" />
                <span>Save as Draft</span>
              </button>
              <button
                type="button"
                onClick={() => setStage('preview')}
                className="inline-flex items-center gap-1.5 rounded-lg border border-[#282B3B] bg-[#161822] px-3.5 py-2 text-xs font-semibold text-[#D1D5E2] hover:text-white whitespace-nowrap"
              >
                <Eye className="h-3.5 w-3.5" aria-hidden="true" />
                <span>Preview Game</span>
              </button>
              <button
                type="button"
                disabled={saving}
                onClick={() => saveGameState(releaseMode === 'schedule' ? 'scheduled' : 'published', true)}
                className="zyntra-btn-shine inline-flex items-center gap-1.5 rounded-lg bg-gradient-to-r from-[#7C3AED] to-[#0EA5E9] px-4 py-2 text-xs font-semibold text-white shadow-[0_0_20px_rgba(124,58,237,0.35)] hover:brightness-110 disabled:opacity-60 whitespace-nowrap"
              >
                {saving ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Rocket className="h-3.5 w-3.5" />}
                <span>{draft.status === 'published' ? 'Publish Update' : 'Publish Game'}</span>
              </button>
            </div>
          </div>

          {/* STAGE 2: AUTOMATIC GAME DETECTION (ALL 32 FIELDS) */}
          {stage === 'detection' && (
            <section className="space-y-6 rounded-2xl border border-[#232634] bg-[#111218]/90 p-6">
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#1D1F2B] pb-4">
                <div className="flex items-center gap-2.5">
                  <Sparkles className="h-5 w-5 text-[#38BDF8]" aria-hidden="true" />
                  <div>
                    <h2 className="font-display text-xl font-bold text-[#F4F4F8]">
                      Automatic Game Detection (32 Fields Populated)
                    </h2>
                    <p className="text-xs text-[#9CA3B4]">{draft.aiSummaryNotes}</p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setStage('info')}
                  className="inline-flex items-center gap-1.5 rounded-lg bg-[#8B5CF6] px-4 py-2 text-xs font-semibold text-white hover:bg-[#7C3AED]"
                >
                  <span>Edit Game Information</span>
                  <ArrowRight className="h-3.5 w-3.5" aria-hidden="true" />
                </button>
              </div>

              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
                {[
                  ['1. Game Name', draft.title],
                  ['2. Icon Asset', draft.iconImage ? 'Auto-assigned' : 'Pending'],
                  ['3. Version', `v${draft.version}`],
                  ['4. File Name', draft.originalFilename],
                  ['5. File Size', formatBytes(draft.fileSize)],
                  ['6. File Format', draft.fileFormat.toUpperCase()],
                  ['7. Platform', draft.platform],
                  ['8. Category / Genre', `${draft.category} · ${draft.genre}`],
                  ['9. Description', draft.shortDescription],
                  ['10. Developer', draft.developer],
                  ['11. Publisher', draft.publisher],
                  ['12. Release Date', draft.releaseDate],
                  ['13. Last Updated', draft.updatedAt.slice(0, 10)],
                  ['14. Screenshots', `${draft.screenshots.length} attached`],
                  ['15. Cover Banner', draft.coverImage ? 'Ready' : 'Pending'],
                  ['16. Tags', draft.tags.join(', ') || 'Indie'],
                  ['17. Min Requirements', draft.minRequirements],
                  ['18. Rec Requirements', draft.recRequirements],
                  ['19. Age Rating', draft.ageRating],
                  ['20. Languages', draft.languages],
                  ['21. Player Mode', draft.playerMode],
                  ['22. Internet Req', draft.internetRequirement],
                  ['23. Controls', draft.controls],
                  ['24. Privacy Policy', draft.privacyPolicy],
                  ['25. Terms & Cond.', draft.termsConditions],
                  ['26. Copyright', draft.copyrightInfo],
                  ['27. Permissions', draft.permissions],
                  ['28. Content Rating', draft.contentRating],
                  ['29. Game ID', draft.id],
                  ['30. Upload Date', draft.uploadDate.slice(0, 10)],
                  ['31. Game Status', draft.gameStatus],
                  ['32. Publishing Status', draft.status.toUpperCase()],
                ].map(([label, value]) => (
                  <div key={label} className="rounded-xl border border-[#1E2130] bg-[#0B0C11] p-3.5">
                    <div className="text-[11px] font-semibold text-[#38BDF8] uppercase tracking-wider">{label}</div>
                    <div className="mt-1 text-xs text-[#E4E7F2] line-clamp-2 break-words">{value}</div>
                  </div>
                ))}
              </div>
            </section>
          )}

          {/* STAGE 3: GAME INFORMATION */}
          {stage === 'info' && (
            <section className="space-y-6 rounded-2xl border border-[#232634] bg-[#111218]/90 p-6">
              <div className="flex items-center gap-2 border-b border-[#1D1F2B] pb-4">
                <Info className="h-5 w-5 text-[#A855F7]" aria-hidden="true" />
                <h2 className="font-display text-xl font-bold text-[#F4F4F8]">Edit Game Information</h2>
              </div>

              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
                <div className="sm:col-span-2">
                  <label htmlFor="edit-title" className="block text-xs font-medium text-[#A5ABBE]">
                    Game Name / Title
                  </label>
                  <input
                    id="edit-title"
                    type="text"
                    value={draft.title}
                    onChange={(e) => setDraft({ ...draft, title: e.target.value })}
                    className="mt-1 w-full rounded-lg border border-[#262938] bg-[#0B0C11] px-3.5 py-2 text-sm text-[#F4F4F8] focus:border-[#38BDF8] focus:outline-none"
                  />
                </div>

                <div>
                  <label htmlFor="edit-version" className="block text-xs font-medium text-[#A5ABBE]">
                    Game Version
                  </label>
                  <input
                    id="edit-version"
                    type="text"
                    value={newVersionInput}
                    onChange={(e) => {
                      setNewVersionInput(e.target.value);
                      setDraft({ ...draft, version: e.target.value });
                    }}
                    className="mt-1 w-full rounded-lg border border-[#262938] bg-[#0B0C11] px-3.5 py-2 font-mono text-sm text-[#F4F4F8] focus:border-[#38BDF8] focus:outline-none"
                  />
                </div>

                <div>
                  <label htmlFor="edit-category" className="block text-xs font-medium text-[#A5ABBE]">
                    Category
                  </label>
                  <select
                    id="edit-category"
                    value={draft.category}
                    onChange={(e) => setDraft({ ...draft, category: e.target.value })}
                    className="mt-1 w-full rounded-lg border border-[#262938] bg-[#0B0C11] px-3.5 py-2 text-sm text-[#F4F4F8] focus:border-[#38BDF8] focus:outline-none"
                  >
                    {categories.map((cat) => (
                      <option key={cat.id} value={cat.name}>
                        {cat.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label htmlFor="edit-genre" className="block text-xs font-medium text-[#A5ABBE]">
                    Genre
                  </label>
                  <input
                    id="edit-genre"
                    type="text"
                    value={draft.genre}
                    onChange={(e) => setDraft({ ...draft, genre: e.target.value })}
                    className="mt-1 w-full rounded-lg border border-[#262938] bg-[#0B0C11] px-3.5 py-2 text-sm text-[#F4F4F8] focus:border-[#38BDF8] focus:outline-none"
                  />
                </div>

                <div>
                  <label htmlFor="edit-platform" className="block text-xs font-medium text-[#A5ABBE]">
                    Platform
                  </label>
                  <select
                    id="edit-platform"
                    value={draft.platform}
                    onChange={(e) => setDraft({ ...draft, platform: e.target.value as GamePlatform })}
                    className="mt-1 w-full rounded-lg border border-[#262938] bg-[#0B0C11] px-3.5 py-2 text-sm text-[#F4F4F8] focus:border-[#38BDF8] focus:outline-none"
                  >
                    {PLATFORMS.map((p) => (
                      <option key={p} value={p}>
                        {p}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label htmlFor="edit-developer" className="block text-xs font-medium text-[#A5ABBE]">
                    Developer Name
                  </label>
                  <input
                    id="edit-developer"
                    type="text"
                    value={draft.developer}
                    onChange={(e) => setDraft({ ...draft, developer: e.target.value })}
                    className="mt-1 w-full rounded-lg border border-[#262938] bg-[#0B0C11] px-3.5 py-2 text-sm text-[#F4F4F8] focus:border-[#38BDF8] focus:outline-none"
                  />
                </div>

                <div>
                  <label htmlFor="edit-publisher" className="block text-xs font-medium text-[#A5ABBE]">
                    Publisher Name
                  </label>
                  <input
                    id="edit-publisher"
                    type="text"
                    value={draft.publisher}
                    onChange={(e) => setDraft({ ...draft, publisher: e.target.value })}
                    className="mt-1 w-full rounded-lg border border-[#262938] bg-[#0B0C11] px-3.5 py-2 text-sm text-[#F4F4F8] focus:border-[#38BDF8] focus:outline-none"
                  />
                </div>

                <div>
                  <label htmlFor="edit-game-status" className="block text-xs font-medium text-[#A5ABBE]">
                    Game Build Status
                  </label>
                  <select
                    id="edit-game-status"
                    value={draft.gameStatus}
                    onChange={(e) => setDraft({ ...draft, gameStatus: e.target.value as GameLifecycleStatus })}
                    className="mt-1 w-full rounded-lg border border-[#262938] bg-[#0B0C11] px-3.5 py-2 text-sm text-[#F4F4F8] focus:border-[#38BDF8] focus:outline-none"
                  >
                    {GAME_STATUSES.map((s) => (
                      <option key={s} value={s}>
                        {s}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label htmlFor="edit-release-date" className="block text-xs font-medium text-[#A5ABBE]">
                    Release Date
                  </label>
                  <input
                    id="edit-release-date"
                    type="date"
                    value={draft.releaseDate.slice(0, 10)}
                    onChange={(e) => setDraft({ ...draft, releaseDate: e.target.value })}
                    className="mt-1 w-full rounded-lg border border-[#262938] bg-[#0B0C11] px-3.5 py-2 font-mono text-sm text-[#F4F4F8] focus:border-[#38BDF8] focus:outline-none"
                  />
                </div>

                <div>
                  <label htmlFor="edit-age-rating" className="block text-xs font-medium text-[#A5ABBE]">
                    Age Rating
                  </label>
                  <input
                    id="edit-age-rating"
                    type="text"
                    value={draft.ageRating}
                    onChange={(e) => setDraft({ ...draft, ageRating: e.target.value })}
                    className="mt-1 w-full rounded-lg border border-[#262938] bg-[#0B0C11] px-3.5 py-2 text-sm text-[#F4F4F8] focus:border-[#38BDF8] focus:outline-none"
                  />
                </div>

                <div>
                  <label htmlFor="edit-content-rating" className="block text-xs font-medium text-[#A5ABBE]">
                    Content Rating
                  </label>
                  <input
                    id="edit-content-rating"
                    type="text"
                    value={draft.contentRating}
                    onChange={(e) => setDraft({ ...draft, contentRating: e.target.value })}
                    className="mt-1 w-full rounded-lg border border-[#262938] bg-[#0B0C11] px-3.5 py-2 text-sm text-[#F4F4F8] focus:border-[#38BDF8] focus:outline-none"
                  />
                </div>

                <div>
                  <label htmlFor="edit-languages" className="block text-xs font-medium text-[#A5ABBE]">
                    Languages Supported
                  </label>
                  <input
                    id="edit-languages"
                    type="text"
                    value={draft.languages}
                    onChange={(e) => setDraft({ ...draft, languages: e.target.value })}
                    className="mt-1 w-full rounded-lg border border-[#262938] bg-[#0B0C11] px-3.5 py-2 text-sm text-[#F4F4F8] focus:border-[#38BDF8] focus:outline-none"
                  />
                </div>

                <div>
                  <label htmlFor="edit-player-mode" className="block text-xs font-medium text-[#A5ABBE]">
                    Multiplayer / Single Player
                  </label>
                  <input
                    id="edit-player-mode"
                    type="text"
                    value={draft.playerMode}
                    onChange={(e) => setDraft({ ...draft, playerMode: e.target.value })}
                    className="mt-1 w-full rounded-lg border border-[#262938] bg-[#0B0C11] px-3.5 py-2 text-sm text-[#F4F4F8] focus:border-[#38BDF8] focus:outline-none"
                  />
                </div>

                <div>
                  <label htmlFor="edit-internet-req" className="block text-xs font-medium text-[#A5ABBE]">
                    Internet Requirement
                  </label>
                  <select
                    id="edit-internet-req"
                    value={draft.internetRequirement}
                    onChange={(e) => setDraft({ ...draft, internetRequirement: e.target.value })}
                    className="mt-1 w-full rounded-lg border border-[#262938] bg-[#0B0C11] px-3.5 py-2 text-sm text-[#F4F4F8] focus:border-[#38BDF8] focus:outline-none"
                  >
                    <option value="Offline Supported">Offline Supported</option>
                    <option value="Online Required">Online Required</option>
                    <option value="Online Optional">Online Optional</option>
                  </select>
                </div>

                <div className="sm:col-span-2 lg:col-span-3">
                  <label htmlFor="edit-short-desc" className="block text-xs font-medium text-[#A5ABBE]">
                    Short Description
                  </label>
                  <input
                    id="edit-short-desc"
                    type="text"
                    value={draft.shortDescription}
                    onChange={(e) => setDraft({ ...draft, shortDescription: e.target.value })}
                    className="mt-1 w-full rounded-lg border border-[#262938] bg-[#0B0C11] px-3.5 py-2 text-sm text-[#F4F4F8] focus:border-[#38BDF8] focus:outline-none"
                  />
                </div>

                <div className="sm:col-span-2 lg:col-span-3">
                  <label htmlFor="edit-full-desc" className="block text-xs font-medium text-[#A5ABBE]">
                    Full Description
                  </label>
                  <textarea
                    id="edit-full-desc"
                    rows={4}
                    value={draft.fullDescription}
                    onChange={(e) => setDraft({ ...draft, fullDescription: e.target.value })}
                    className="mt-1 w-full rounded-lg border border-[#262938] bg-[#0B0C11] px-3.5 py-2 text-sm text-[#F4F4F8] focus:border-[#38BDF8] focus:outline-none"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label htmlFor="edit-controls" className="block text-xs font-medium text-[#A5ABBE]">
                    Controls Information
                  </label>
                  <input
                    id="edit-controls"
                    type="text"
                    value={draft.controls}
                    onChange={(e) => setDraft({ ...draft, controls: e.target.value })}
                    className="mt-1 w-full rounded-lg border border-[#262938] bg-[#0B0C11] px-3.5 py-2 text-sm text-[#F4F4F8] focus:border-[#38BDF8] focus:outline-none"
                  />
                </div>

                <div>
                  <label htmlFor="edit-tags" className="block text-xs font-medium text-[#A5ABBE]">
                    Tags / Keywords (comma separated)
                  </label>
                  <input
                    id="edit-tags"
                    type="text"
                    value={tagsInput}
                    onChange={(e) => setTagsInput(e.target.value)}
                    className="mt-1 w-full rounded-lg border border-[#262938] bg-[#0B0C11] px-3.5 py-2 text-sm text-[#F4F4F8] focus:border-[#38BDF8] focus:outline-none"
                  />
                </div>

                <div className="sm:col-span-2 lg:col-span-3">
                  <label htmlFor="edit-instructions" className="block text-xs font-medium text-[#A5ABBE]">
                    How to Play / Instructions
                  </label>
                  <input
                    id="edit-instructions"
                    type="text"
                    value={draft.instructions}
                    onChange={(e) => setDraft({ ...draft, instructions: e.target.value })}
                    className="mt-1 w-full rounded-lg border border-[#262938] bg-[#0B0C11] px-3.5 py-2 text-sm text-[#F4F4F8] focus:border-[#38BDF8] focus:outline-none"
                  />
                </div>

                <div className="lg:col-span-1 sm:col-span-2">
                  <label htmlFor="edit-min-req" className="block text-xs font-medium text-[#A5ABBE]">
                    Minimum System Requirements
                  </label>
                  <input
                    id="edit-min-req"
                    type="text"
                    value={draft.minRequirements}
                    onChange={(e) => setDraft({ ...draft, minRequirements: e.target.value })}
                    className="mt-1 w-full rounded-lg border border-[#262938] bg-[#0B0C11] px-3.5 py-2 text-sm text-[#F4F4F8] focus:border-[#38BDF8] focus:outline-none"
                  />
                </div>

                <div className="lg:col-span-2 sm:col-span-2">
                  <label htmlFor="edit-rec-req" className="block text-xs font-medium text-[#A5ABBE]">
                    Recommended System Requirements
                  </label>
                  <input
                    id="edit-rec-req"
                    type="text"
                    value={draft.recRequirements}
                    onChange={(e) => setDraft({ ...draft, recRequirements: e.target.value })}
                    className="mt-1 w-full rounded-lg border border-[#262938] bg-[#0B0C11] px-3.5 py-2 text-sm text-[#F4F4F8] focus:border-[#38BDF8] focus:outline-none"
                  />
                </div>

                <div className="sm:col-span-2 lg:col-span-3">
                  <label htmlFor="edit-permissions" className="block text-xs font-medium text-[#A5ABBE]">
                    Game Permissions
                  </label>
                  <input
                    id="edit-permissions"
                    type="text"
                    value={draft.permissions}
                    onChange={(e) => setDraft({ ...draft, permissions: e.target.value })}
                    className="mt-1 w-full rounded-lg border border-[#262938] bg-[#0B0C11] px-3.5 py-2 text-sm text-[#F4F4F8] focus:border-[#38BDF8] focus:outline-none"
                  />
                </div>

                <div>
                  <label htmlFor="edit-copyright" className="block text-xs font-medium text-[#A5ABBE]">
                    Copyright Information
                  </label>
                  <input
                    id="edit-copyright"
                    type="text"
                    value={draft.copyrightInfo}
                    onChange={(e) => setDraft({ ...draft, copyrightInfo: e.target.value })}
                    className="mt-1 w-full rounded-lg border border-[#262938] bg-[#0B0C11] px-3.5 py-2 text-sm text-[#F4F4F8] focus:border-[#38BDF8] focus:outline-none"
                  />
                </div>

                <div>
                  <label htmlFor="edit-privacy" className="block text-xs font-medium text-[#A5ABBE]">
                    Privacy Policy Summary
                  </label>
                  <input
                    id="edit-privacy"
                    type="text"
                    value={draft.privacyPolicy}
                    onChange={(e) => setDraft({ ...draft, privacyPolicy: e.target.value })}
                    className="mt-1 w-full rounded-lg border border-[#262938] bg-[#0B0C11] px-3.5 py-2 text-sm text-[#F4F4F8] focus:border-[#38BDF8] focus:outline-none"
                  />
                </div>

                <div>
                  <label htmlFor="edit-terms" className="block text-xs font-medium text-[#A5ABBE]">
                    Terms &amp; Conditions
                  </label>
                  <input
                    id="edit-terms"
                    type="text"
                    value={draft.termsConditions}
                    onChange={(e) => setDraft({ ...draft, termsConditions: e.target.value })}
                    className="mt-1 w-full rounded-lg border border-[#262938] bg-[#0B0C11] px-3.5 py-2 text-sm text-[#F4F4F8] focus:border-[#38BDF8] focus:outline-none"
                  />
                </div>
              </div>
            </section>
          )}

          {/* STAGE 4: MEDIA & SCREENSHOTS */}
          {stage === 'media' && (
            <section className="space-y-6 rounded-2xl border border-[#232634] bg-[#111218]/90 p-6">
              <div className="flex items-center gap-2 border-b border-[#1D1F2B] pb-4">
                <Images className="h-5 w-5 text-[#38BDF8]" aria-hidden="true" />
                <h2 className="font-display text-xl font-bold text-[#F4F4F8]">Media &amp; Screenshots</h2>
              </div>

              <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
                {/* Cover Banner */}
                <div className="rounded-xl border border-[#232634] bg-[#0B0C11] p-4">
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-sm font-semibold text-[#F4F4F8]">Cover Image / Banner</span>
                    <label className="inline-flex cursor-pointer items-center gap-1.5 rounded-lg border border-[#2A2D3E] bg-[#161822] px-3 py-1.5 text-xs font-medium text-[#D1D5E2] hover:border-[#38BDF8]/60 hover:text-white">
                      <ImagePlus className="h-3.5 w-3.5" aria-hidden="true" />
                      <span>Upload Cover</span>
                      <input
                        type="file"
                        accept="image/*"
                        className="sr-only"
                        onChange={(e) => {
                          const f = e.target.files?.[0];
                          if (f) handleUploadImage('cover', f);
                        }}
                      />
                    </label>
                  </div>
                  <img
                    src={draft.coverImage}
                    alt="Game cover preview"
                    referrerPolicy="no-referrer"
                    className="aspect-video w-full rounded-lg border border-[#222432] object-cover"
                  />
                </div>

                {/* Game Icon / Logo */}
                <div className="rounded-xl border border-[#232634] bg-[#0B0C11] p-4 flex flex-col justify-between">
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-sm font-semibold text-[#F4F4F8]">Game Icon / Logo</span>
                    <label className="inline-flex cursor-pointer items-center gap-1.5 rounded-lg border border-[#2A2D3E] bg-[#161822] px-3 py-1.5 text-xs font-medium text-[#D1D5E2] hover:border-[#38BDF8]/60 hover:text-white">
                      <ImagePlus className="h-3.5 w-3.5" aria-hidden="true" />
                      <span>Upload Icon</span>
                      <input
                        type="file"
                        accept="image/*"
                        className="sr-only"
                        onChange={(e) => {
                          const f = e.target.files?.[0];
                          if (f) handleUploadImage('icon', f);
                        }}
                      />
                    </label>
                  </div>
                  <div className="flex items-center gap-5 py-6">
                    <img
                      src={draft.iconImage}
                      alt="Game icon preview"
                      referrerPolicy="no-referrer"
                      className="h-24 w-24 rounded-2xl border border-[#2A2D3E] object-cover"
                    />
                    <p className="text-xs leading-relaxed text-[#9CA3B4]">
                      Square icon displayed in store specs, browser player header, and game cards. Auto-generated cleanly when not included in the uploaded package.
                    </p>
                  </div>
                </div>
              </div>

              {/* Screenshots Gallery */}
              <div className="rounded-xl border border-[#232634] bg-[#0B0C11] p-5">
                <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
                  <div>
                    <h3 className="text-sm font-semibold text-[#F4F4F8]">
                      Game Screenshots ({draft.screenshots.length})
                    </h3>
                    <p className="text-xs text-[#8E94A8]">Upload gameplay screenshots shown on the public game page.</p>
                  </div>
                  <label className="inline-flex cursor-pointer items-center gap-1.5 rounded-lg bg-[#8B5CF6] px-3.5 py-2 text-xs font-semibold text-white hover:bg-[#7C3AED]">
                    <ImagePlus className="h-3.5 w-3.5" aria-hidden="true" />
                    <span>Add Screenshot</span>
                    <input
                      type="file"
                      accept="image/*"
                      className="sr-only"
                      onChange={(e) => {
                        const f = e.target.files?.[0];
                        if (f) handleUploadImage('screenshot', f);
                      }}
                    />
                  </label>
                </div>

                {draft.screenshots.length === 0 ? (
                  <p className="rounded-lg border border-dashed border-[#262938] py-8 text-center text-xs text-[#7E849A]">
                    No additional screenshots yet. You can upload screenshots above or proceed with your cover artwork.
                  </p>
                ) : (
                  <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
                    {draft.screenshots.map((shot, idx) => (
                      <div key={shot} className="group relative overflow-hidden rounded-lg border border-[#232634]">
                        <img
                          src={shot}
                          alt={`Screenshot ${idx + 1}`}
                          referrerPolicy="no-referrer"
                          className="aspect-video w-full object-cover"
                        />
                        <button
                          type="button"
                          onClick={() => handleRemoveScreenshot(shot)}
                          aria-label={`Remove screenshot ${idx + 1}`}
                          className="absolute right-2 top-2 rounded-md bg-black/75 p-1.5 text-rose-300 hover:bg-rose-600 hover:text-white"
                        >
                          <Trash2 className="h-3.5 w-3.5" aria-hidden="true" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </section>
          )}

          {/* STAGE 5: SETTINGS */}
          {stage === 'settings' && (
            <section className="space-y-6 rounded-2xl border border-[#232634] bg-[#111218]/90 p-6">
              <div className="flex items-center gap-2 border-b border-[#1D1F2B] pb-4">
                <Settings className="h-5 w-5 text-[#38BDF8]" aria-hidden="true" />
                <h2 className="font-display text-xl font-bold text-[#F4F4F8]">
                  Visibility, Pricing, Build &amp; Release Settings
                </h2>
              </div>

              <div className="grid grid-cols-1 gap-5 md:grid-cols-2">
                {/* Visibility & URL */}
                <div className="space-y-4 rounded-xl border border-[#232634] bg-[#0B0C11] p-5">
                  <h3 className="text-sm font-semibold text-[#F4F4F8]">Visibility &amp; Game Page URL</h3>
                  <div>
                    <label className="block text-xs font-medium text-[#A5ABBE]">Public / Private Visibility</label>
                    <div className="mt-2 grid grid-cols-2 gap-2">
                      {(['public', 'private'] as GameVisibility[]).map((vis) => (
                        <button
                          key={vis}
                          type="button"
                          onClick={() => setDraft({ ...draft, visibility: vis })}
                          className={`inline-flex items-center justify-center gap-2 rounded-lg border px-3 py-2 text-xs font-semibold ${
                            draft.visibility === vis
                              ? 'border-[#38BDF8] bg-[#38BDF8]/15 text-white'
                              : 'border-[#252838] bg-[#111218] text-[#9CA3B4]'
                          }`}
                        >
                          {vis === 'public' ? <Globe className="h-3.5 w-3.5" /> : <GlobeLock className="h-3.5 w-3.5" />}
                          <span>{vis === 'public' ? 'Public' : 'Private'}</span>
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label htmlFor="settings-slug" className="block text-xs font-medium text-[#A5ABBE]">
                      Game Page URL Slug
                    </label>
                    <div className="mt-1 flex items-center rounded-lg border border-[#262938] bg-[#111218] px-3">
                      <span className="text-xs text-[#73788C]">/games/</span>
                      <input
                        id="settings-slug"
                        type="text"
                        value={draft.slug}
                        onChange={(e) => setDraft({ ...draft, slug: e.target.value })}
                        className="w-full bg-transparent py-2 pl-1 font-mono text-xs text-[#38BDF8] focus:outline-none"
                      />
                    </div>
                  </div>

                  <div>
                    <label htmlFor="settings-collection" className="block text-xs font-medium text-[#A5ABBE]">
                      Collection Name
                    </label>
                    <input
                      id="settings-collection"
                      type="text"
                      value={draft.collectionName}
                      onChange={(e) => setDraft({ ...draft, collectionName: e.target.value })}
                      className="mt-1 w-full rounded-lg border border-[#262938] bg-[#111218] px-3 py-2 text-sm text-[#F4F4F8]"
                    />
                  </div>
                </div>

                {/* Pricing & Play/Download Settings */}
                <div className="space-y-4 rounded-xl border border-[#232634] bg-[#0B0C11] p-5">
                  <h3 className="text-sm font-semibold text-[#F4F4F8]">Pricing, Play &amp; Download Settings</h3>
                  <div>
                    <label className="block text-xs font-medium text-[#A5ABBE]">Free / Paid Game</label>
                    <div className="mt-2 grid grid-cols-2 gap-2">
                      {(['free', 'paid'] as PricingType[]).map((pt) => (
                        <button
                          key={pt}
                          type="button"
                          onClick={() =>
                            setDraft({
                              ...draft,
                              pricingType: pt,
                              priceLabel: pt === 'free' ? 'Free' : draft.priceLabel === 'Free' ? '$4.99' : draft.priceLabel,
                            })
                          }
                          className={`rounded-lg border px-3 py-2 text-xs font-semibold ${
                            draft.pricingType === pt
                              ? 'border-[#8B5CF6] bg-[#8B5CF6]/20 text-white'
                              : 'border-[#252838] bg-[#111218] text-[#9CA3B4]'
                          }`}
                        >
                          {pt === 'free' ? 'Free Game' : 'Paid Game'}
                        </button>
                      ))}
                    </div>
                  </div>

                  {draft.pricingType === 'paid' && (
                    <div>
                      <label htmlFor="settings-price" className="block text-xs font-medium text-[#A5ABBE]">
                        Display Price
                      </label>
                      <input
                        id="settings-price"
                        type="text"
                        value={draft.priceLabel}
                        onChange={(e) => setDraft({ ...draft, priceLabel: e.target.value })}
                        placeholder="$4.99"
                        className="mt-1 w-full rounded-lg border border-[#262938] bg-[#111218] px-3 py-2 font-mono text-sm text-white"
                      />
                    </div>
                  )}

                  <div className="space-y-2.5 pt-1">
                    <label className="flex items-center gap-2.5 text-sm text-[#D1D5E2]">
                      <input
                        type="checkbox"
                        checked={draft.isDownloadable}
                        onChange={(e) => setDraft({ ...draft, isDownloadable: e.target.checked })}
                        className="h-4 w-4 accent-[#38BDF8]"
                      />
                      <span>Enable Direct Download</span>
                    </label>
                    <label className="flex items-center gap-2.5 text-sm text-[#D1D5E2]">
                      <input
                        type="checkbox"
                        checked={draft.isBrowserPlayable}
                        onChange={(e) => setDraft({ ...draft, isBrowserPlayable: e.target.checked })}
                        className="h-4 w-4 accent-[#8B5CF6]"
                      />
                      <span>Enable Play Online (Browser Player)</span>
                    </label>
                    <label className="flex items-center gap-2.5 text-sm text-[#D1D5E2]">
                      <input
                        type="checkbox"
                        checked={draft.featured}
                        onChange={(e) => setDraft({ ...draft, featured: e.target.checked })}
                        className="h-4 w-4 accent-[#8B5CF6]"
                      />
                      <span>Featured Game (Homepage Spotlight)</span>
                    </label>
                    <label className="flex items-center gap-2.5 text-sm text-[#D1D5E2]">
                      <input
                        type="checkbox"
                        checked={draft.trending}
                        onChange={(e) => setDraft({ ...draft, trending: e.target.checked })}
                        className="h-4 w-4 accent-[#38BDF8]"
                      />
                      <span>Trending Game</span>
                    </label>
                  </div>
                </div>

                {/* Replace Game File & Update Version */}
                <div className="space-y-3 rounded-xl border border-[#232634] bg-[#0B0C11] p-5 md:col-span-2">
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <div>
                      <h3 className="text-sm font-semibold text-[#F4F4F8]">Replace Game File &amp; Update Version</h3>
                      <p className="text-xs text-[#8E94A8]">
                        Current build: <span className="font-mono text-[#D1D5E2]">{draft.originalFilename}</span> · v{newVersionInput}
                      </p>
                    </div>
                    <div className="flex flex-wrap items-center gap-2.5">
                      <input
                        type="text"
                        aria-label="New build version"
                        value={newVersionInput}
                        onChange={(e) => {
                          setNewVersionInput(e.target.value);
                          setDraft({ ...draft, version: e.target.value });
                        }}
                        placeholder="v1.0.1"
                        className="w-28 rounded-lg border border-[#262938] bg-[#111218] px-3 py-2 font-mono text-xs text-white"
                      />
                      <input
                        ref={replaceFileInputRef}
                        type="file"
                        className="sr-only"
                        onChange={(e) => {
                          const f = e.target.files?.[0];
                          if (f) handleReplaceBuildFile(f);
                        }}
                      />
                      <button
                        type="button"
                        disabled={replacingFile}
                        onClick={() => replaceFileInputRef.current?.click()}
                        className="inline-flex items-center gap-2 rounded-lg border border-[#38BDF8]/50 bg-[#0EA5E9]/15 px-3.5 py-2 text-xs font-semibold text-[#38BDF8] hover:bg-[#0EA5E9]/25 disabled:opacity-50"
                      >
                        {replacingFile ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <FileUp className="h-3.5 w-3.5" />}
                        <span>Replace Game File</span>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </section>
          )}

          {/* STAGE 6: PREVIEW */}
          {stage === 'preview' && (
            <section className="space-y-6 rounded-2xl border border-[#232634] bg-[#111218]/90 p-6">
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#1D1F2B] pb-4">
                <div className="flex items-center gap-2">
                  <Eye className="h-5 w-5 text-[#38BDF8]" aria-hidden="true" />
                  <h2 className="font-display text-xl font-bold text-[#F4F4F8]">Storefront Listing Preview</h2>
                </div>
                <Link
                  href={`/games/${draft.slug}?preview=1`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#38BDF8] hover:underline"
                >
                  <span>Open Full Page Preview</span>
                  <ExternalLink className="h-3.5 w-3.5" aria-hidden="true" />
                </Link>
              </div>

              <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
                <div className="space-y-4 lg:col-span-7">
                  <img
                    src={draft.coverImage}
                    alt={draft.title}
                    referrerPolicy="no-referrer"
                    className="aspect-video w-full rounded-xl border border-[#252838] object-cover"
                  />
                  <div className="rounded-xl border border-[#232634] bg-[#0B0C11] p-5">
                    <h3 className="font-display text-lg font-bold text-white">About {draft.title}</h3>
                    <p className="mt-2 whitespace-pre-line text-sm text-[#B6BCCF]">{draft.fullDescription}</p>
                    <div className="mt-4 grid grid-cols-1 gap-3 border-t border-[#1D1F2B] pt-4 text-xs text-[#9CA3B4] sm:grid-cols-2">
                      <div>
                        <span className="font-semibold text-[#F4F4F8]">Controls: </span>
                        {draft.controls}
                      </div>
                      <div>
                        <span className="font-semibold text-[#F4F4F8]">Permissions: </span>
                        {draft.permissions}
                      </div>
                    </div>
                  </div>
                </div>

                <div className="rounded-xl border border-[#232634] bg-[#0B0C11] p-5 lg:col-span-5 space-y-4">
                  <div className="flex items-start gap-3.5">
                    <img
                      src={draft.iconImage}
                      alt={draft.title}
                      referrerPolicy="no-referrer"
                      className="h-14 w-14 rounded-xl border border-[#2A2D3E] object-cover"
                    />
                    <div>
                      <div className="text-xs font-medium text-[#38BDF8]">
                        {draft.category} · {draft.platform} · {draft.pricingType === 'free' ? 'Free' : draft.priceLabel}
                      </div>
                      <h3 className="font-display text-xl font-bold text-white">{draft.title}</h3>
                      <p className="text-xs text-[#9CA3B4]">
                        by {draft.developer} · {draft.gameStatus}
                      </p>
                    </div>
                  </div>

                  <p className="text-sm text-[#A5ABBE]">{draft.shortDescription}</p>

                  <div className="flex flex-wrap gap-2">
                    {draft.isBrowserPlayable && (
                      <span className="inline-flex items-center gap-1.5 rounded-lg bg-[#7C3AED] px-4 py-2 text-xs font-semibold text-white">
                        <Play className="h-3.5 w-3.5 fill-current" />
                        Play Game
                      </span>
                    )}
                    {draft.isDownloadable && (
                      <span className="inline-flex items-center gap-1.5 rounded-lg border border-[#2A2D3E] bg-[#161822] px-4 py-2 text-xs font-semibold text-[#F4F4F8]">
                        <Download className="h-3.5 w-3.5" />
                        Download ({formatBytes(draft.fileSize)})
                      </span>
                    )}
                  </div>

                  <dl className="divide-y divide-[#1A1C28] border-t border-[#1A1C28] text-xs">
                    {[
                      ['Version', `v${newVersionInput || draft.version}`],
                      ['Languages', draft.languages],
                      ['Player Mode', draft.playerMode],
                      ['Internet', draft.internetRequirement],
                      ['Age Rating', `${draft.ageRating} (${draft.contentRating})`],
                      ['Visibility', draft.visibility === 'public' ? 'Public Storefront' : 'Private'],
                    ].map(([k, v]) => (
                      <div key={k} className="flex justify-between py-2">
                        <dt className="text-[#8E94A8]">{k}</dt>
                        <dd className="text-[#F4F4F8] text-right">{v}</dd>
                      </div>
                    ))}
                  </dl>
                </div>
              </div>
            </section>
          )}

          {/* STAGE 7: PUBLISH */}
          {stage === 'publish' && (
            <section className="space-y-6 rounded-2xl border border-[#232634] bg-[#111218]/90 p-6">
              <div className="flex items-center gap-2 border-b border-[#1D1F2B] pb-4">
                <Rocket className="h-5 w-5 text-[#A855F7]" aria-hidden="true" />
                <h2 className="font-display text-xl font-bold text-[#F4F4F8]">Publish &amp; Lifecycle Controls</h2>
              </div>

              <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                <div className="rounded-xl border border-[#232634] bg-[#0B0C11] p-5 space-y-4">
                  <h3 className="text-sm font-semibold text-white">Release Timing</h3>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => setReleaseMode('now')}
                      className={`inline-flex items-center justify-center gap-2 rounded-lg border px-3 py-2.5 text-xs font-semibold ${
                        releaseMode === 'now'
                          ? 'border-[#8B5CF6] bg-[#8B5CF6]/20 text-white'
                          : 'border-[#252838] bg-[#111218] text-[#9CA3B4]'
                      }`}
                    >
                      <Rocket className="h-3.5 w-3.5" />
                      <span>Publish Immediately</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setReleaseMode('schedule')}
                      className={`inline-flex items-center justify-center gap-2 rounded-lg border px-3 py-2.5 text-xs font-semibold ${
                        releaseMode === 'schedule'
                          ? 'border-[#38BDF8] bg-[#38BDF8]/20 text-white'
                          : 'border-[#252838] bg-[#111218] text-[#9CA3B4]'
                      }`}
                    >
                      <CalendarClock className="h-3.5 w-3.5" />
                      <span>Schedule Release</span>
                    </button>
                  </div>

                  {releaseMode === 'schedule' && (
                    <div>
                      <label htmlFor="schedule-release-at" className="block text-xs font-medium text-[#A5ABBE]">
                        Scheduled Release Date &amp; Time
                      </label>
                      <input
                        id="schedule-release-at"
                        type="datetime-local"
                        value={scheduleInput}
                        onChange={(e) => setScheduleInput(e.target.value)}
                        className="mt-1.5 w-full rounded-lg border border-[#262938] bg-[#111218] px-3 py-2 text-sm text-white"
                      />
                    </div>
                  )}
                </div>

                <div className="rounded-xl border border-[#232634] bg-[#0B0C11] p-5 space-y-3">
                  <h3 className="text-sm font-semibold text-white">Actions</h3>
                  <div className="flex flex-wrap gap-2.5">
                    <button
                      type="button"
                      disabled={saving}
                      onClick={() => saveGameState(releaseMode === 'schedule' ? 'scheduled' : 'published', true)}
                      className="zyntra-btn-shine inline-flex items-center gap-2 rounded-lg bg-gradient-to-r from-[#7C3AED] to-[#0EA5E9] px-5 py-2.5 text-sm font-semibold text-white shadow-[0_0_24px_rgba(124,58,237,0.35)] hover:brightness-110 disabled:opacity-60"
                    >
                      <Rocket className="h-4 w-4" />
                      <span>
                        {releaseMode === 'schedule'
                          ? 'Schedule Release'
                          : draft.status === 'published'
                            ? 'Publish Update'
                            : 'Publish Game'}
                      </span>
                    </button>

                    <button
                      type="button"
                      disabled={saving}
                      onClick={() => saveGameState('draft')}
                      className="inline-flex items-center gap-2 rounded-lg border border-[#2A2D3E] bg-[#161822] px-4 py-2.5 text-sm font-semibold text-[#F4F4F8] hover:border-[#38BDF8]"
                    >
                      <Save className="h-4 w-4" />
                      <span>Save as Draft</span>
                    </button>

                    {draft.status === 'published' && (
                      <button
                        type="button"
                        disabled={saving}
                        onClick={() => saveGameState('unpublished')}
                        className="inline-flex items-center gap-2 rounded-lg border border-amber-500/40 bg-amber-500/10 px-4 py-2.5 text-sm font-semibold text-amber-300 hover:bg-amber-500/20"
                      >
                        <GlobeLock className="h-4 w-4" />
                        <span>Unpublish Game</span>
                      </button>
                    )}

                    <button
                      type="button"
                      disabled={saving}
                      onClick={() => setConfirmDeleteOpen(true)}
                      className="inline-flex items-center gap-2 rounded-lg border border-rose-500/40 bg-rose-500/10 px-4 py-2.5 text-sm font-semibold text-rose-300 hover:bg-rose-500/20"
                    >
                      <Trash2 className="h-4 w-4" />
                      <span>Delete Game</span>
                    </button>
                  </div>
                </div>
              </div>
            </section>
          )}

          {/* STAGE 8: PUBLIC GAME PAGE */}
          {stage === 'public_page' && (
            <section className="rounded-2xl border border-emerald-500/35 bg-[#0F1B18]/90 p-7">
              <div className="flex flex-col gap-5 sm:flex-row sm:items-center sm:justify-between">
                <div className="flex items-start gap-3.5">
                  <CheckCircle2 className="mt-0.5 h-7 w-7 shrink-0 text-emerald-400" aria-hidden="true" />
                  <div>
                    <h2 className="font-display text-xl font-bold text-white">
                      {draft.status === 'scheduled'
                        ? `${draft.title} Scheduled for Release`
                        : `${draft.title} is Live on Zyntra Game Store`}
                    </h2>
                    <p className="mt-1 text-sm text-emerald-200/80">
                      Public URL: <span className="font-mono text-[#38BDF8]">/games/{draft.slug}</span> · Visible across Homepage, Search, Categories, and Developer Profile.
                    </p>
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-2.5">
                  <Link
                    href={`/games/${draft.slug}`}
                    className="zyntra-btn-shine inline-flex items-center gap-2 rounded-lg bg-[#8B5CF6] px-4 py-2.5 text-sm font-semibold text-white hover:bg-[#7C3AED] whitespace-nowrap"
                  >
                    <Gamepad2 className="h-4 w-4" aria-hidden="true" />
                    <span>Open Public Game Page</span>
                  </Link>
                  {draft.isBrowserPlayable && (
                    <Link
                      href={`/games/${draft.slug}/play`}
                      className="inline-flex items-center gap-2 rounded-lg bg-[#0EA5E9] px-4 py-2.5 text-sm font-semibold text-white hover:bg-[#0284C7] whitespace-nowrap"
                    >
                      <Play className="h-4 w-4 fill-current" aria-hidden="true" />
                      <span>Play Online</span>
                    </Link>
                  )}
                  <ShareButton
                    variant="hero"
                    label="Share Game"
                    urlPath={`/games/${draft.slug}`}
                    title={draft.title}
                    text={draft.shortDescription}
                  />
                  <button
                    type="button"
                    onClick={() => {
                      setDraft(null);
                      setNotice(null);
                      setStage('import');
                    }}
                    className="rounded-lg border border-[#2C3042] bg-[#161822] px-4 py-2.5 text-sm font-medium text-[#D1D5E2] hover:text-white whitespace-nowrap"
                  >
                    Upload Another Game
                  </button>
                </div>
              </div>
            </section>
          )}

          {/* Stage Footer Navigation */}
          <div className="flex items-center justify-between border-t border-[#1D1F2B] pt-4">
            <button
              type="button"
              disabled={stageIndex <= 1}
              onClick={() => {
                if (stageIndex > 1) setStage(STAGES[stageIndex - 1].id);
              }}
              className="inline-flex items-center gap-1.5 rounded-lg border border-[#262938] bg-[#111218] px-4 py-2 text-xs font-semibold text-[#D1D5E2] hover:text-white disabled:opacity-40"
            >
              <ArrowLeft className="h-3.5 w-3.5" aria-hidden="true" />
              <span>Previous Stage</span>
            </button>

            <span className="font-mono text-xs text-[#7E849A]">
              Stage {stageIndex + 1} of {STAGES.length}
            </span>

            {stageIndex < STAGES.length - 1 ? (
              <button
                type="button"
                onClick={() => setStage(STAGES[stageIndex + 1].id)}
                className="inline-flex items-center gap-1.5 rounded-lg border border-[#38BDF8]/45 bg-[#161824] px-4 py-2 text-xs font-semibold text-[#38BDF8] hover:bg-[#38BDF8]/15"
              >
                <span>Next: {STAGES[stageIndex + 1].label}</span>
                <ArrowRight className="h-3.5 w-3.5" aria-hidden="true" />
              </button>
            ) : (
              <button
                type="button"
                onClick={() => setStage('info')}
                className="inline-flex items-center gap-1.5 rounded-lg border border-[#262938] bg-[#111218] px-4 py-2 text-xs font-semibold text-[#D1D5E2] hover:text-white"
              >
                <Cpu className="h-3.5 w-3.5" aria-hidden="true" />
                <span>Edit Game Info</span>
              </button>
            )}
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {confirmDeleteOpen && draft && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 backdrop-blur-sm">
          <div className="w-full max-w-md rounded-2xl border border-rose-500/35 bg-[#111218] p-6">
            <h3 className="font-display text-xl font-bold text-[#F4F4F8]">Delete {draft.title}?</h3>
            <p className="mt-2 text-sm text-[#9CA3B4]">
              This permanently removes the game, stored build file, and playable files from Zyntra Game Store.
            </p>
            <div className="mt-6 flex justify-end gap-3">
              <button
                type="button"
                onClick={() => setConfirmDeleteOpen(false)}
                className="rounded-lg border border-[#262938] px-4 py-2 text-sm text-[#D1D5E2] hover:text-white"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={saving}
                onClick={handleDeleteDraft}
                className="rounded-lg bg-rose-600 px-4 py-2 text-sm font-semibold text-white hover:bg-rose-500 disabled:opacity-60"
              >
                {saving ? 'Deleting...' : 'Confirm Delete'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
