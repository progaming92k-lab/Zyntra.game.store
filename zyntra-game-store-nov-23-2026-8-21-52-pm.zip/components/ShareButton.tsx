'use client';

import React, { useEffect, useState } from 'react';
import { createPortal } from 'react-dom';
import { AnimatePresence, motion } from 'motion/react';
import { Check, Copy, ExternalLink, Share2, X } from 'lucide-react';
import { playUiSound } from '@/lib/sound';

interface ShareButtonProps {
  variant?: 'hero' | 'card' | 'dock' | 'compact';
  label?: string;
  title?: string;
  text?: string;
  urlPath?: string;
}

export default function ShareButton({
  variant = 'hero',
  label = 'Share',
  title = 'Zyntra Game Store',
  text = 'Check out Zyntra Game Store — play browser games and download original indie releases!',
  urlPath,
}: ShareButtonProps) {
  const [open, setOpen] = useState(false);
  const [copied, setCopied] = useState(false);
  const [shareUrl, setShareUrl] = useState('');
  const [canNativeShare, setCanNativeShare] = useState(false);

  useEffect(() => {
    if (!open) return;
    function onKeyDown(e: KeyboardEvent) {
      if (e.key === 'Escape') {
        setOpen(false);
      }
    }
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [open]);

  function resolveCurrentUrl() {
    if (typeof window === 'undefined') return '';
    if (urlPath) {
      return `${window.location.origin}${urlPath.startsWith('/') ? urlPath : `/${urlPath}`}`;
    }
    return window.location.href;
  }

  function handleOpen() {
    const resolved = resolveCurrentUrl();
    setShareUrl(resolved);
    setCanNativeShare(typeof navigator !== 'undefined' && typeof navigator.share === 'function');
    setCopied(false);
    setOpen(true);
  }

  async function handleCopy() {
    const targetUrl = shareUrl || resolveCurrentUrl();
    try {
      await navigator.clipboard.writeText(targetUrl);
      playUiSound('success');
      setCopied(true);
      setTimeout(() => setCopied(false), 2400);
    } catch {
      playUiSound('error');
    }
  }

  async function handleNativeShare() {
    const targetUrl = shareUrl || resolveCurrentUrl();
    if (typeof navigator === 'undefined' || typeof navigator.share !== 'function') return;
    try {
      await navigator.share({
        title,
        text,
        url: targetUrl,
      });
      playUiSound('success');
    } catch {
      // User dismissed native share sheet
    }
  }

  const encodedUrl = encodeURIComponent(shareUrl);
  const encodedText = encodeURIComponent(`${title} — ${text}`);
  const whatsappUrl = `https://wa.me/?text=${encodeURIComponent(`${title} — ${text} ${shareUrl}`)}`;
  const telegramUrl = `https://t.me/share/url?url=${encodedUrl}&text=${encodedText}`;
  const xUrl = `https://twitter.com/intent/tweet?url=${encodedUrl}&text=${encodedText}`;

  const triggerClass =
    variant === 'dock'
      ? 'inline-flex h-10 items-center gap-2 rounded-lg border border-[#282B3E] bg-[#111218]/90 px-3 text-xs font-medium text-[#D1D5E2] backdrop-blur-md shadow-[0_8px_24px_rgba(0,0,0,0.45)] transition-all duration-150 hover:border-[#8B5CF6]/70 hover:text-white whitespace-nowrap'
      : variant === 'card'
        ? 'inline-flex w-full items-center justify-center gap-2 rounded-lg border border-[#282B3E] bg-[#161822] px-4 py-2.5 text-sm font-semibold text-[#F4F4F8] transition-all duration-150 hover:border-[#38BDF8]/60 hover:text-[#38BDF8] whitespace-nowrap'
        : variant === 'compact'
          ? 'inline-flex items-center gap-1.5 rounded-lg border border-[#232634] bg-[#111218] px-3.5 py-2 text-xs font-semibold text-[#D1D5E2] transition-colors hover:border-[#38BDF8]/60 hover:text-white whitespace-nowrap'
          : 'inline-flex items-center gap-2 rounded-lg border border-[#38BDF8]/40 bg-[#0EA5E9]/10 px-4 py-2.5 text-sm font-semibold text-[#7DD3FC] transition-colors hover:bg-[#0EA5E9]/20 hover:text-white whitespace-nowrap';

  const modal =
    typeof document !== 'undefined'
      ? createPortal(
          <AnimatePresence>
            {open && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.16 }}
                role="dialog"
                aria-modal="true"
                aria-labelledby="share-dialog-title"
                data-testid="share-modal"
                className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 backdrop-blur-sm"
                onClick={(e) => {
                  if (e.target === e.currentTarget) setOpen(false);
                }}
              >
                <motion.div
                  initial={{ opacity: 0, scale: 0.94, y: 10 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.96, y: 6 }}
                  transition={{ duration: 0.18, ease: 'easeOut' }}
                  className="w-full max-w-md rounded-2xl border border-[#2A2E42] bg-[#10111A] p-6 shadow-[0_24px_70px_rgba(0,0,0,0.75)]"
                >
              <div className="flex items-start justify-between gap-4">
                <div>
                  <h2 id="share-dialog-title" className="font-display text-xl font-bold text-[#F4F4F8]">
                    Share {title}
                  </h2>
                  <p className="mt-1 text-xs text-[#9CA3B4]">
                    Copy the direct link or share with friends on your favorite platform.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setOpen(false)}
                  aria-label="Close share dialog"
                  className="inline-flex h-8 w-8 items-center justify-center rounded-lg border border-[#26293B] bg-[#161824] text-[#9CA3B4] hover:text-white"
                >
                  <X className="h-4 w-4" aria-hidden="true" />
                </button>
              </div>

              <div className="mt-5">
                <label htmlFor="share-link-input" className="block text-xs font-medium text-[#A5ABBE]">
                  Shareable Link
                </label>
                <div className="mt-1.5 flex items-center gap-2">
                  <input
                    id="share-link-input"
                    type="text"
                    readOnly
                    value={shareUrl}
                    onFocus={(e) => e.target.select()}
                    className="w-full rounded-lg border border-[#282B3E] bg-[#08090E] px-3 py-2 font-mono text-xs text-[#E5E7EB] focus:border-[#38BDF8] focus:outline-none"
                  />
                  <button
                    type="button"
                    onClick={handleCopy}
                    data-testid="share-copy-btn"
                    className="inline-flex shrink-0 items-center gap-1.5 rounded-lg bg-gradient-to-r from-[#7C3AED] to-[#0EA5E9] px-3.5 py-2 text-xs font-semibold text-white transition-all hover:brightness-110 whitespace-nowrap"
                  >
                    {copied ? (
                      <>
                        <Check className="h-3.5 w-3.5" aria-hidden="true" />
                        <span>Copied!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="h-3.5 w-3.5" aria-hidden="true" />
                        <span>Copy</span>
                      </>
                    )}
                  </button>
                </div>
              </div>

              <div className="mt-5 grid grid-cols-3 gap-2.5">
                <a
                  href={whatsappUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center justify-center gap-1.5 rounded-lg border border-[#26293B] bg-[#151722] px-3 py-2 text-xs font-medium text-[#E5E7EB] transition-colors hover:border-[#38BDF8]/60 hover:text-white"
                >
                  <span>WhatsApp</span>
                  <ExternalLink className="h-3 w-3 opacity-70" aria-hidden="true" />
                </a>
                <a
                  href={telegramUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center justify-center gap-1.5 rounded-lg border border-[#26293B] bg-[#151722] px-3 py-2 text-xs font-medium text-[#E5E7EB] transition-colors hover:border-[#38BDF8]/60 hover:text-white"
                >
                  <span>Telegram</span>
                  <ExternalLink className="h-3 w-3 opacity-70" aria-hidden="true" />
                </a>
                <a
                  href={xUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center justify-center gap-1.5 rounded-lg border border-[#26293B] bg-[#151722] px-3 py-2 text-xs font-medium text-[#E5E7EB] transition-colors hover:border-[#38BDF8]/60 hover:text-white"
                >
                  <span>X / Post</span>
                  <ExternalLink className="h-3 w-3 opacity-70" aria-hidden="true" />
                </a>
              </div>

              {canNativeShare && (
                <button
                  type="button"
                  onClick={handleNativeShare}
                  className="mt-3 inline-flex w-full items-center justify-center gap-2 rounded-lg border border-[#8B5CF6]/40 bg-[#8B5CF6]/15 px-4 py-2 text-xs font-semibold text-[#C4B5FD] transition-colors hover:bg-[#8B5CF6]/25 hover:text-white"
                >
                  <Share2 className="h-3.5 w-3.5" aria-hidden="true" />
                  <span>Share via Device Sheet</span>
                </button>
              )}
                </motion.div>
              </motion.div>
            )}
          </AnimatePresence>,
          document.body
        )
      : null;

  return (
    <>
      <button
        type="button"
        onClick={handleOpen}
        data-testid={`share-trigger-${variant}`}
        className={triggerClass}
      >
        <Share2 className={variant === 'dock' || variant === 'compact' ? 'h-3.5 w-3.5 text-[#A855F7]' : 'h-4 w-4'} aria-hidden="true" />
        <span>{label}</span>
      </button>
      {modal}
    </>
  );
}
