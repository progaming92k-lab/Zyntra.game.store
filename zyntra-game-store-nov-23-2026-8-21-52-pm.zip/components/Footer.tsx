import React from 'react';
import Image from 'next/image';
import Link from 'next/link';

export default function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer className="border-t border-[#1C1E29] bg-[#090A0F]/88 text-[#9CA3B4] backdrop-blur-md">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 gap-10 md:grid-cols-4">
          <div className="md:col-span-2">
            <Link href="/" className="inline-flex items-center gap-2.5 font-display text-lg font-bold text-[#F4F4F8] hover:text-[#38BDF8] transition-colors">
              <span className="relative h-7 w-7 shrink-0 overflow-hidden rounded-lg border border-[#8B5CF6]/50">
                <Image
                  src="/assets/aistudio/zyntra-ai-logo-rounded_5b64714d.png"
                  alt="Zyntra Game Store logo"
                  fill
                  sizes="28px"
                  referrerPolicy="no-referrer"
                  className="object-cover"
                />
              </span>
              <span>Zyntra Game Store</span>
            </Link>
            <p className="mt-3 max-w-md text-sm leading-relaxed text-[#8E94A8]">
              An independent digital storefront for creator-built HTML5, WebGL, Android, and desktop games. Play directly in your browser or download verified builds.
            </p>
          </div>

          <div>
            <h3 className="text-sm font-semibold text-[#F4F4F8]">Storefront</h3>
            <ul className="mt-3 space-y-2.5 text-sm">
              <li>
                <Link href="/games" className="transition-colors hover:text-[#38BDF8]">
                  All Games
                </Link>
              </li>
              <li>
                <Link href="/categories" className="transition-colors hover:text-[#38BDF8]">
                  Browse Categories
                </Link>
              </li>
              <li>
                <Link href="/search" className="transition-colors hover:text-[#38BDF8]">
                  Search Catalog
                </Link>
              </li>
              <li>
                <Link href="/import" className="transition-colors hover:text-[#38BDF8]">
                  Creator Import
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-sm font-semibold text-[#F4F4F8]">Platform</h3>
            <ul className="mt-3 space-y-2.5 text-sm">
              <li>
                <Link href="/about" className="transition-colors hover:text-[#38BDF8]">
                  About Us
                </Link>
              </li>
              <li>
                <Link href="/contact" className="transition-colors hover:text-[#38BDF8]">
                  Contact Us
                </Link>
              </li>
              <li>
                <Link href="/privacy" className="transition-colors hover:text-[#38BDF8]">
                  Privacy Policy
                </Link>
              </li>
              <li>
                <Link href="/terms" className="transition-colors hover:text-[#38BDF8]">
                  Terms &amp; Conditions
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-10 flex flex-col items-start justify-between gap-4 border-t border-[#181A24] pt-6 text-xs text-[#73788C] sm:flex-row sm:items-center">
          <p>&copy; {year} Zyntra Game Store. All rights reserved.</p>
          <div className="flex items-center gap-5">
            <Link href="/sitemap.xml" className="hover:text-[#A0A4B8]">
              Sitemap
            </Link>
            <Link href="/privacy" className="hover:text-[#A0A4B8]">
              Privacy
            </Link>
            <Link href="/terms" className="hover:text-[#A0A4B8]">
              Terms
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
