'use client';

import React, { useMemo, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import {
  AlertCircle,
  Edit3,
  Eye,
  FileUp,
  Flag,
  FolderPlus,
  Globe,
  GlobeLock,
  Loader2,
  LogOut,
  Search,
  SlidersHorizontal,
  Trash2,
  Upload,
  X,
} from 'lucide-react';
import OwnerLoginGate from './OwnerLoginGate';
import { buildAuthHeaders, clearClientAuthToken } from '@/lib/client-auth';
import { formatBytes } from '@/lib/game-logic';
import type { CategoryRecord, GamePlatform, GameRecord, GameReport, StoreStats } from '@/lib/types';

interface AdminDashboardProps {
  initialAuthenticated: boolean;
  initialEmail: string | null;
  initialGames: GameRecord[];
  initialStats: StoreStats | null;
  initialCategories: CategoryRecord[];
  initialReports?: GameReport[];
}

const PLATFORMS: GamePlatform[] = [
  'HTML5',
  'Unity WebGL',
  'Web',
  'Android',
  'Windows',
  'iOS',
  'PC',
  'Mac',
  'Linux',
  'Cross-Platform',
  'Other',
];

export default function AdminDashboard({
  initialAuthenticated,
  initialEmail,
  initialGames,
  initialStats,
  initialCategories,
  initialReports = [],
}: AdminDashboardProps) {
  const router = useRouter();
  const [authenticated, setAuthenticated] = useState(initialAuthenticated);
  const [ownerEmail, setOwnerEmail] = useState(initialEmail);
  const [games, setGames] = useState<GameRecord[]>(initialGames);
  const [stats, setStats] = useState<StoreStats | null>(initialStats);
  const [categories, setCategories] = useState<CategoryRecord[]>(initialCategories);
  const [reports, setReports] = useState<GameReport[]>(initialReports);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'published' | 'draft' | 'scheduled' | 'unpublished'>('all');
  const [categoryFilter, setCategoryFilter] = useState('All');
  const [busyId, setBusyId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Modals state
  const [editingGame, setEditingGame] = useState<GameRecord | null>(null);
  const [replacingGame, setReplacingGame] = useState<GameRecord | null>(null);
  const [replaceVersion, setReplaceVersion] = useState('');
  const [replaceFile, setReplaceFile] = useState<File | null>(null);
  const [deletingGame, setDeletingGame] = useState<GameRecord | null>(null);
  const [newCatName, setNewCatName] = useState('');
  const [newCatDesc, setNewCatDesc] = useState('');

  async function refreshDashboardData() {
    const authHeaders = buildAuthHeaders();
    const [gamesRes, statsRes, catsRes] = await Promise.all([
      fetch('/api/games?includeDrafts=1', { headers: authHeaders }),
      fetch('/api/admin/stats', { headers: authHeaders }),
      fetch('/api/categories'),
    ]);
    if (gamesRes.ok) {
      const gData = (await gamesRes.json()) as { games: GameRecord[] };
      setGames(gData.games);
    }
    if (statsRes.ok) {
      const sData = (await statsRes.json()) as { stats: StoreStats; reports?: GameReport[] };
      setStats(sData.stats);
      if (Array.isArray(sData.reports)) setReports(sData.reports);
    }
    if (catsRes.ok) {
      const cData = (await catsRes.json()) as { categories: CategoryRecord[] };
      setCategories(cData.categories);
    }
    router.refresh();
  }

  async function handleLogout() {
    await fetch('/api/auth/logout', {
      method: 'POST',
      headers: buildAuthHeaders(),
    }).catch(() => {});
    clearClientAuthToken();
    setAuthenticated(false);
    setOwnerEmail(null);
  }

  async function togglePublish(game: GameRecord) {
    setBusyId(game.id);
    setError(null);
    const nextStatus = game.status === 'published' ? 'unpublished' : 'published';
    try {
      const res = await fetch(`/api/games/${encodeURIComponent(game.id)}`, {
        method: 'PATCH',
        headers: buildAuthHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify({ status: nextStatus }),
      });
      if (!res.ok) throw new Error('Failed to update status.');
      await refreshDashboardData();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to update game status.');
    } finally {
      setBusyId(null);
    }
  }

  async function handleSaveEdit(e: React.FormEvent) {
    e.preventDefault();
    if (!editingGame) return;
    setBusyId(editingGame.id);
    setError(null);

    try {
      const res = await fetch(`/api/games/${encodeURIComponent(editingGame.id)}`, {
        method: 'PATCH',
        headers: buildAuthHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify({
          title: editingGame.title,
          shortDescription: editingGame.shortDescription,
          fullDescription: editingGame.fullDescription,
          category: editingGame.category,
          platform: editingGame.platform,
          version: editingGame.version,
          developer: editingGame.developer,
          publisher: editingGame.publisher,
          controls: editingGame.controls,
          instructions: editingGame.instructions,
          featured: editingGame.featured,
          trending: editingGame.trending,
          visibility: editingGame.visibility,
          pricingType: editingGame.pricingType,
          priceLabel: editingGame.priceLabel,
          collectionName: editingGame.collectionName,
        }),
      });
      if (!res.ok) throw new Error('Failed to save changes.');
      setEditingGame(null);
      await refreshDashboardData();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Error updating listing.');
    } finally {
      setBusyId(null);
    }
  }

  async function handleEditImageUpload(gameId: string, kind: 'cover' | 'icon', file: File) {
    setBusyId(gameId);
    const fd = new FormData();
    fd.append('kind', kind);
    fd.append('file', file);
    const res = await fetch(`/api/games/${encodeURIComponent(gameId)}/upload-image`, {
      method: 'POST',
      headers: buildAuthHeaders(),
      body: fd,
    });
    const data = (await res.json().catch(() => ({}))) as { game?: GameRecord };
    if (res.ok && data.game) {
      setEditingGame(data.game);
      await refreshDashboardData();
    }
    setBusyId(null);
  }

  async function handleReplaceFileSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!replacingGame || !replaceFile) return;
    setBusyId(replacingGame.id);
    setError(null);
    try {
      const fd = new FormData();
      fd.append('file', replaceFile);
      if (replaceVersion.trim()) fd.append('version', replaceVersion.trim());

      const res = await fetch(`/api/games/${encodeURIComponent(replacingGame.id)}/replace-file`, {
        method: 'POST',
        headers: buildAuthHeaders(),
        body: fd,
      });
      const data = (await res.json().catch(() => ({}))) as { error?: string };
      if (!res.ok) throw new Error(data.error || 'Failed to replace game file.');
      setReplacingGame(null);
      setReplaceFile(null);
      setReplaceVersion('');
      await refreshDashboardData();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to replace game file.');
    } finally {
      setBusyId(null);
    }
  }

  async function confirmDeleteGame() {
    if (!deletingGame) return;
    setBusyId(deletingGame.id);
    setError(null);
    try {
      const res = await fetch(`/api/games/${encodeURIComponent(deletingGame.id)}`, {
        method: 'DELETE',
        headers: buildAuthHeaders(),
      });
      if (!res.ok) throw new Error('Failed to delete game.');
      setDeletingGame(null);
      await refreshDashboardData();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to delete game.');
    } finally {
      setBusyId(null);
    }
  }

  async function handleAddCategory(e: React.FormEvent) {
    e.preventDefault();
    if (!newCatName.trim()) return;
    setError(null);
    const res = await fetch('/api/categories', {
      method: 'POST',
      headers: buildAuthHeaders({ 'Content-Type': 'application/json' }),
      body: JSON.stringify({ name: newCatName.trim(), description: newCatDesc.trim() }),
    });
    const data = (await res.json().catch(() => ({}))) as { error?: string };
    if (!res.ok) {
      setError(data.error || 'Failed to add category.');
      return;
    }
    setNewCatName('');
    setNewCatDesc('');
    await refreshDashboardData();
  }

  async function handleDeleteCategory(id: string) {
    const res = await fetch(`/api/categories?id=${encodeURIComponent(id)}`, {
      method: 'DELETE',
      headers: buildAuthHeaders(),
    });
    if (res.ok) {
      await refreshDashboardData();
    }
  }

  const visibleGames = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return games.filter((g) => {
      if (statusFilter !== 'all' && g.status !== statusFilter) return false;
      if (categoryFilter !== 'All' && g.category.toLowerCase() !== categoryFilter.toLowerCase()) return false;
      if (q) {
        const text = `${g.title} ${g.category} ${g.platform} ${g.developer} ${g.version}`.toLowerCase();
        if (!text.includes(q)) return false;
      }
      return true;
    });
  }, [games, searchQuery, statusFilter, categoryFilter]);

  if (!authenticated) {
    return (
      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        <OwnerLoginGate
          title="Admin Dashboard"
          subtitle="Sign in with Access Code or your Creator Username & Password to manage uploaded games and store analytics."
          onAuthenticated={async (label) => {
            setOwnerEmail(label);
            setAuthenticated(true);
            await refreshDashboardData();
          }}
        />
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-7xl space-y-10 px-4 py-10 sm:px-6 lg:px-8">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-[#1D1F2B] pb-6">
        <div>
          <h1 className="font-display text-3xl font-bold text-[#F4F4F8]">Admin Dashboard</h1>
          <p className="mt-1 text-sm text-[#9CA3B4]">
            Manage games, publish drafts, monitor views, likes, plays, downloads, and community reports.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          {ownerEmail && <span className="hidden text-xs text-[#38BDF8] sm:inline">{ownerEmail}</span>}
          <Link
            href="/import"
            className="inline-flex items-center gap-2 rounded-lg bg-gradient-to-r from-[#7C3AED] to-[#0EA5E9] px-4 py-2 text-sm font-semibold text-white hover:brightness-110 whitespace-nowrap"
          >
            <Upload className="h-4 w-4" aria-hidden="true" />
            <span>Import Game</span>
          </Link>
          <button
            type="button"
            onClick={handleLogout}
            className="inline-flex items-center gap-1.5 rounded-lg border border-[#262938] bg-[#111218] px-3.5 py-2 text-sm font-medium text-[#9CA3B4] hover:text-white whitespace-nowrap"
          >
            <LogOut className="h-4 w-4" aria-hidden="true" />
            <span>Sign Out</span>
          </button>
        </div>
      </div>

      {error && (
        <div
          role="alert"
          className="flex items-center gap-2.5 rounded-xl border border-rose-500/35 bg-rose-500/10 px-4 py-3 text-sm text-rose-300"
        >
          <AlertCircle className="h-4 w-4 shrink-0" aria-hidden="true" />
          <span>{error}</span>
        </div>
      )}

      {/* KPI Metrics Grid */}
      <section aria-label="Store statistics" className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6">
        <div className="rounded-xl border border-[#222432] bg-[#111218] p-4">
          <div className="text-xs font-medium text-[#8E94A8]">Published</div>
          <div className="mt-1.5 font-mono text-2xl font-bold text-[#F4F4F8] tabular-nums">
            {stats?.totalPublished ?? 0}
          </div>
        </div>
        <div className="rounded-xl border border-[#222432] bg-[#111218] p-4">
          <div className="text-xs font-medium text-[#8E94A8]">Total Uploads</div>
          <div className="mt-1.5 font-mono text-2xl font-bold text-[#F4F4F8] tabular-nums">
            {stats?.totalUploads ?? 0}
          </div>
        </div>
        <div className="rounded-xl border border-[#222432] bg-[#111218] p-4">
          <div className="text-xs font-medium text-[#8E94A8]">Views</div>
          <div className="mt-1.5 font-mono text-2xl font-bold text-[#F4F4F8] tabular-nums">
            {stats?.totalViews ?? 0}
          </div>
        </div>
        <div className="rounded-xl border border-[#222432] bg-[#111218] p-4">
          <div className="text-xs font-medium text-[#8E94A8]">Likes</div>
          <div className="mt-1.5 font-mono text-2xl font-bold text-rose-400 tabular-nums">
            {stats?.totalLikes ?? 0}
          </div>
        </div>
        <div className="rounded-xl border border-[#222432] bg-[#111218] p-4">
          <div className="text-xs font-medium text-[#8E94A8]">Downloads</div>
          <div className="mt-1.5 font-mono text-2xl font-bold text-[#38BDF8] tabular-nums">
            {stats?.totalDownloads ?? 0}
          </div>
        </div>
        <div className="rounded-xl border border-[#222432] bg-[#111218] p-4">
          <div className="text-xs font-medium text-[#8E94A8]">Plays / Storage</div>
          <div className="mt-1.5 font-mono text-lg font-bold text-[#A855F7] tabular-nums">
            {stats?.totalPlays ?? 0} · {formatBytes(stats?.storageUsedBytes ?? 0)}
          </div>
        </div>
      </section>

      {/* Game Management Section */}
      <section aria-labelledby="manage-games-heading" className="space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <h2 id="manage-games-heading" className="font-display text-xl font-bold text-[#F4F4F8]">
            Game Management
          </h2>

          <div className="flex flex-wrap items-center gap-2.5">
            <div className="relative">
              <Search
                className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-[#73788C]"
                aria-hidden="true"
              />
              <input
                type="search"
                aria-label="Search uploaded games"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search games..."
                className="rounded-lg border border-[#232634] bg-[#111218] py-2 pl-9 pr-3 text-sm text-[#F4F4F8] placeholder-[#6B7186] focus:border-[#38BDF8] focus:outline-none"
              />
            </div>

            <select
              aria-label="Filter by status"
              value={statusFilter}
              onChange={(e) =>
                setStatusFilter(e.target.value as 'all' | 'published' | 'draft' | 'scheduled' | 'unpublished')
              }
              className="rounded-lg border border-[#232634] bg-[#111218] px-3 py-2 text-sm text-[#F4F4F8] focus:border-[#38BDF8] focus:outline-none"
            >
              <option value="all">All Statuses</option>
              <option value="published">Published</option>
              <option value="draft">Drafts</option>
              <option value="scheduled">Scheduled</option>
              <option value="unpublished">Unpublished</option>
            </select>

            <select
              aria-label="Filter by category"
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              className="rounded-lg border border-[#232634] bg-[#111218] px-3 py-2 text-sm text-[#F4F4F8] focus:border-[#38BDF8] focus:outline-none"
            >
              <option value="All">All Categories</option>
              {categories.map((c) => (
                <option key={c.id} value={c.name}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>
        </div>

        {visibleGames.length === 0 ? (
          <div className="rounded-xl border border-[#222432] bg-[#111218] p-12 text-center">
            <h3 className="font-display text-lg font-semibold text-[#F4F4F8]">No games in this view</h3>
            <p className="mt-2 text-sm text-[#9CA3B4]">
              Import your first game or adjust your search/status filters.
            </p>
            <Link
              href="/import"
              className="mt-5 inline-flex items-center gap-2 rounded-lg bg-[#8B5CF6] px-4 py-2 text-sm font-semibold text-white hover:bg-[#7C3AED]"
            >
              <Upload className="h-4 w-4" aria-hidden="true" />
              <span>Import Game</span>
            </Link>
          </div>
        ) : (
          <div className="overflow-x-auto rounded-xl border border-[#222432] bg-[#111218]">
            <table className="w-full text-left text-sm">
              <thead className="border-b border-[#1D1F2B] bg-[#0D0E14] text-xs font-semibold text-[#8E94A8]">
                <tr>
                  <th className="px-3 py-3">Game</th>
                  <th className="px-3 py-3">Status</th>
                  <th className="px-3 py-3">Version</th>
                  <th className="px-3 py-3">Size</th>
                  <th className="px-3 py-3 text-right">Views / Likes</th>
                  <th className="px-3 py-3 text-right">Downloads / Plays</th>
                  <th className="px-3 py-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1A1C26]">
                {visibleGames.map((game) => (
                  <tr key={game.id} className="hover:bg-[#151722]/70 transition-colors">
                    <td className="px-3 py-3">
                      <div className="flex items-center gap-2.5">
                        <img
                          src={game.coverImage}
                          alt={game.title}
                          referrerPolicy="no-referrer"
                          className="h-10 w-14 shrink-0 rounded-md border border-[#262938] object-cover"
                        />
                        <div className="min-w-0">
                          <div className="font-semibold text-[#F4F4F8] truncate max-w-[170px]">{game.title}</div>
                          <div className="text-xs text-[#8E94A8] truncate">
                            {game.category} · {game.platform} · {game.visibility}
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="px-3 py-3 whitespace-nowrap">
                      <span
                        className={`text-xs font-semibold ${
                          game.status === 'published'
                            ? 'text-emerald-400'
                            : game.status === 'scheduled'
                              ? 'text-[#38BDF8]'
                              : 'text-amber-300'
                        }`}
                      >
                        {game.status.charAt(0).toUpperCase() + game.status.slice(1)}
                      </span>
                    </td>
                    <td className="px-3 py-3 font-mono text-xs text-[#D1D5E2] tabular-nums whitespace-nowrap">
                      v{game.version}
                    </td>
                    <td className="px-3 py-3 font-mono text-xs text-[#D1D5E2] tabular-nums whitespace-nowrap">
                      {formatBytes(game.fileSize)}
                    </td>
                    <td className="px-3 py-3 text-right font-mono text-xs text-[#D1D5E2] tabular-nums whitespace-nowrap">
                      {game.viewCount} / {game.likeCount}
                    </td>
                    <td className="px-3 py-3 text-right font-mono text-xs text-[#38BDF8] tabular-nums whitespace-nowrap">
                      {game.downloadCount} / <span className="text-[#A855F7]">{game.playCount}</span>
                    </td>
                    <td className="px-3 py-3">
                      <div className="flex items-center justify-end gap-1">
                        <Link
                          href={`/import?edit=${encodeURIComponent(game.id)}`}
                          aria-label={`Open studio for ${game.title}`}
                          title="Open 8-stage publishing studio"
                          className="inline-flex h-8 items-center gap-1 rounded-md border border-[#262938] bg-[#161822] px-2 text-xs font-medium text-[#38BDF8] hover:border-[#38BDF8]/60 hover:text-white"
                        >
                          <SlidersHorizontal className="h-3.5 w-3.5" aria-hidden="true" />
                          <span>Studio</span>
                        </Link>

                        <button
                          type="button"
                          onClick={() => setEditingGame(game)}
                          aria-label={`Edit ${game.title}`}
                          title="Quick edit"
                          className="inline-flex h-8 items-center gap-1 rounded-md border border-[#262938] bg-[#161822] px-2 text-xs font-medium text-[#D1D5E2] hover:border-[#38BDF8]/60 hover:text-white"
                        >
                          <Edit3 className="h-3.5 w-3.5" aria-hidden="true" />
                          <span>Edit</span>
                        </button>

                        <Link
                          href={`/games/${game.slug}?preview=1`}
                          aria-label={`Preview ${game.title}`}
                          title="Preview game page"
                          className="inline-flex h-8 items-center gap-1 rounded-md border border-[#262938] bg-[#161822] px-2 text-xs font-medium text-[#D1D5E2] hover:text-white"
                        >
                          <Eye className="h-3.5 w-3.5" aria-hidden="true" />
                          <span>Preview</span>
                        </Link>

                        <button
                          type="button"
                          disabled={busyId === game.id}
                          onClick={() => togglePublish(game)}
                          aria-label={`${game.status === 'published' ? 'Unpublish' : 'Publish'} ${game.title}`}
                          className="inline-flex h-8 items-center gap-1 rounded-md border border-[#262938] bg-[#161822] px-2 text-xs font-medium text-[#D1D5E2] hover:border-[#8B5CF6]/60 hover:text-white disabled:opacity-50 whitespace-nowrap"
                        >
                          {game.status === 'published' ? (
                            <>
                              <GlobeLock className="h-3.5 w-3.5 text-amber-300" aria-hidden="true" />
                              <span>Unpublish</span>
                            </>
                          ) : (
                            <>
                              <Globe className="h-3.5 w-3.5 text-emerald-400" aria-hidden="true" />
                              <span>Publish</span>
                            </>
                          )}
                        </button>

                        <button
                          type="button"
                          onClick={() => {
                            setReplacingGame(game);
                            setReplaceVersion(game.version);
                            setReplaceFile(null);
                          }}
                          aria-label={`Replace file for ${game.title}`}
                          className="inline-flex h-8 items-center gap-1 rounded-md border border-[#262938] bg-[#161822] px-2 text-xs font-medium text-[#D1D5E2] hover:border-[#38BDF8]/60 hover:text-white whitespace-nowrap"
                        >
                          <FileUp className="h-3.5 w-3.5" aria-hidden="true" />
                          <span>Replace</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => setDeletingGame(game)}
                          aria-label={`Delete ${game.title}`}
                          className="inline-flex h-8 items-center gap-1 rounded-md border border-rose-500/30 bg-rose-500/10 px-2 text-xs font-medium text-rose-300 hover:bg-rose-500/20 whitespace-nowrap"
                        >
                          <Trash2 className="h-3.5 w-3.5" aria-hidden="true" />
                          <span>Delete</span>
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>

      {/* Community Reports Section */}
      {reports.length > 0 && (
        <section aria-labelledby="reports-heading" className="rounded-2xl border border-[#222432] bg-[#111218] p-6">
          <div className="flex items-center gap-2">
            <Flag className="h-5 w-5 text-amber-300" aria-hidden="true" />
            <h2 id="reports-heading" className="font-display text-xl font-bold text-[#F4F4F8]">
              Submitted Reports ({reports.length})
            </h2>
          </div>
          <div className="mt-4 divide-y divide-[#1C1E2B]">
            {reports.slice(0, 10).map((rep) => (
              <div key={rep.id} className="flex flex-wrap items-center justify-between gap-2 py-3 text-sm">
                <div>
                  <span className="font-semibold text-[#F4F4F8]">{rep.gameTitle}</span>
                  <span className="mx-2 text-[#5E6478]">·</span>
                  <span className="text-amber-300">{rep.reason}</span>
                  {rep.details && <p className="mt-1 text-xs text-[#9CA3B4]">{rep.details}</p>}
                </div>
                <span className="font-mono text-xs text-[#7E849A]">{rep.createdAt.slice(0, 10)}</span>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Category Management Section */}
      <section aria-labelledby="manage-categories-heading" className="rounded-2xl border border-[#222432] bg-[#111218] p-6">
        <h2 id="manage-categories-heading" className="font-display text-xl font-bold text-[#F4F4F8]">
          Manage Categories
        </h2>
        <p className="mt-1 text-sm text-[#9CA3B4]">
          Add new storefront categories or remove unused custom categories.
        </p>

        <form onSubmit={handleAddCategory} className="mt-5 grid grid-cols-1 gap-3 sm:grid-cols-12">
          <input
            type="text"
            required
            value={newCatName}
            onChange={(e) => setNewCatName(e.target.value)}
            placeholder="Category name (e.g. Retro)"
            className="rounded-lg border border-[#262938] bg-[#0B0C11] px-3.5 py-2 text-sm text-[#F4F4F8] sm:col-span-4 focus:border-[#38BDF8] focus:outline-none"
          />
          <input
            type="text"
            value={newCatDesc}
            onChange={(e) => setNewCatDesc(e.target.value)}
            placeholder="Short description..."
            className="rounded-lg border border-[#262938] bg-[#0B0C11] px-3.5 py-2 text-sm text-[#F4F4F8] sm:col-span-6 focus:border-[#38BDF8] focus:outline-none"
          />
          <button
            type="submit"
            className="inline-flex items-center justify-center gap-2 rounded-lg bg-[#8B5CF6] px-4 py-2 text-sm font-semibold text-white hover:bg-[#7C3AED] sm:col-span-2 whitespace-nowrap"
          >
            <FolderPlus className="h-4 w-4" aria-hidden="true" />
            <span>Add</span>
          </button>
        </form>

        <div className="mt-6 grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {categories.map((cat) => (
            <div
              key={cat.id}
              className="flex items-center justify-between gap-2 rounded-lg border border-[#1E202C] bg-[#0B0C11] px-3.5 py-2.5"
            >
              <div className="min-w-0">
                <div className="text-sm font-medium text-[#F4F4F8] truncate">{cat.name}</div>
                <div className="font-mono text-xs text-[#73788C] tabular-nums">{cat.gameCount || 0} published</div>
              </div>
              <button
                type="button"
                aria-label={`Delete category ${cat.name}`}
                onClick={() => handleDeleteCategory(cat.id)}
                className="rounded p-1.5 text-[#73788C] hover:bg-rose-500/15 hover:text-rose-300"
              >
                <Trash2 className="h-3.5 w-3.5" />
              </button>
            </div>
          ))}
        </div>
      </section>

      {/* Edit Game Modal */}
      {editingGame && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 backdrop-blur-sm">
          <div className="max-h-[90vh] w-full max-w-2xl overflow-y-auto rounded-2xl border border-[#262938] bg-[#111218] p-6">
            <div className="flex items-center justify-between border-b border-[#1D1F2B] pb-4">
              <h3 className="font-display text-xl font-bold text-[#F4F4F8]">Edit {editingGame.title}</h3>
              <button
                type="button"
                aria-label="Close edit modal"
                onClick={() => setEditingGame(null)}
                className="rounded-lg p-1.5 text-[#8E94A8] hover:text-white"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleSaveEdit} className="mt-5 space-y-4">
              <div className="flex flex-wrap items-center gap-4">
                <img
                  src={editingGame.coverImage}
                  alt="Cover preview"
                  referrerPolicy="no-referrer"
                  className="h-20 w-36 rounded-lg border border-[#262938] object-cover"
                />
                <div className="space-y-2">
                  <label className="inline-flex cursor-pointer items-center gap-2 rounded-lg border border-[#2A2D3E] bg-[#161822] px-3 py-1.5 text-xs font-medium text-[#F4F4F8] hover:border-[#38BDF8]">
                    <span>Change Cover Image</span>
                    <input
                      type="file"
                      accept="image/*"
                      className="sr-only"
                      onChange={(e) => {
                        const f = e.target.files?.[0];
                        if (f) handleEditImageUpload(editingGame.id, 'cover', f);
                      }}
                    />
                  </label>
                  <label className="ml-2 inline-flex cursor-pointer items-center gap-2 rounded-lg border border-[#2A2D3E] bg-[#161822] px-3 py-1.5 text-xs font-medium text-[#F4F4F8] hover:border-[#38BDF8]">
                    <span>Change Icon</span>
                    <input
                      type="file"
                      accept="image/*"
                      className="sr-only"
                      onChange={(e) => {
                        const f = e.target.files?.[0];
                        if (f) handleEditImageUpload(editingGame.id, 'icon', f);
                      }}
                    />
                  </label>
                </div>
              </div>

              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div className="sm:col-span-2">
                  <label className="block text-xs font-medium text-[#A5ABBE]">Title</label>
                  <input
                    type="text"
                    required
                    value={editingGame.title}
                    onChange={(e) => setEditingGame({ ...editingGame, title: e.target.value })}
                    className="mt-1 w-full rounded-lg border border-[#262938] bg-[#0B0C11] px-3 py-2 text-sm text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-[#A5ABBE]">Category</label>
                  <select
                    value={editingGame.category}
                    onChange={(e) => setEditingGame({ ...editingGame, category: e.target.value })}
                    className="mt-1 w-full rounded-lg border border-[#262938] bg-[#0B0C11] px-3 py-2 text-sm text-white"
                  >
                    {categories.map((c) => (
                      <option key={c.id} value={c.name}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-medium text-[#A5ABBE]">Platform</label>
                  <select
                    value={editingGame.platform}
                    onChange={(e) => setEditingGame({ ...editingGame, platform: e.target.value as GamePlatform })}
                    className="mt-1 w-full rounded-lg border border-[#262938] bg-[#0B0C11] px-3 py-2 text-sm text-white"
                  >
                    {PLATFORMS.map((p) => (
                      <option key={p} value={p}>
                        {p}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-medium text-[#A5ABBE]">Version</label>
                  <input
                    type="text"
                    value={editingGame.version}
                    onChange={(e) => setEditingGame({ ...editingGame, version: e.target.value })}
                    className="mt-1 w-full rounded-lg border border-[#262938] bg-[#0B0C11] px-3 py-2 font-mono text-sm text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-[#A5ABBE]">Developer</label>
                  <input
                    type="text"
                    value={editingGame.developer}
                    onChange={(e) => setEditingGame({ ...editingGame, developer: e.target.value })}
                    className="mt-1 w-full rounded-lg border border-[#262938] bg-[#0B0C11] px-3 py-2 text-sm text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-[#A5ABBE]">Visibility</label>
                  <select
                    value={editingGame.visibility}
                    onChange={(e) =>
                      setEditingGame({ ...editingGame, visibility: e.target.value as 'public' | 'private' })
                    }
                    className="mt-1 w-full rounded-lg border border-[#262938] bg-[#0B0C11] px-3 py-2 text-sm text-white"
                  >
                    <option value="public">Public</option>
                    <option value="private">Private</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-medium text-[#A5ABBE]">Pricing</label>
                  <select
                    value={editingGame.pricingType}
                    onChange={(e) =>
                      setEditingGame({
                        ...editingGame,
                        pricingType: e.target.value as 'free' | 'paid',
                        priceLabel: e.target.value === 'free' ? 'Free' : editingGame.priceLabel || '$4.99',
                      })
                    }
                    className="mt-1 w-full rounded-lg border border-[#262938] bg-[#0B0C11] px-3 py-2 text-sm text-white"
                  >
                    <option value="free">Free</option>
                    <option value="paid">Paid</option>
                  </select>
                </div>
                <div className="sm:col-span-2">
                  <label className="block text-xs font-medium text-[#A5ABBE]">Short Description</label>
                  <input
                    type="text"
                    value={editingGame.shortDescription}
                    onChange={(e) => setEditingGame({ ...editingGame, shortDescription: e.target.value })}
                    className="mt-1 w-full rounded-lg border border-[#262938] bg-[#0B0C11] px-3 py-2 text-sm text-white"
                  />
                </div>
                <div className="sm:col-span-2">
                  <label className="block text-xs font-medium text-[#A5ABBE]">Full Description</label>
                  <textarea
                    rows={4}
                    value={editingGame.fullDescription}
                    onChange={(e) => setEditingGame({ ...editingGame, fullDescription: e.target.value })}
                    className="mt-1 w-full rounded-lg border border-[#262938] bg-[#0B0C11] px-3 py-2 text-sm text-white"
                  />
                </div>
                <div className="sm:col-span-2 flex flex-wrap items-center gap-5">
                  <label className="flex items-center gap-2 text-sm text-[#D1D5E2]">
                    <input
                      type="checkbox"
                      checked={editingGame.featured}
                      onChange={(e) => setEditingGame({ ...editingGame, featured: e.target.checked })}
                      className="h-4 w-4 accent-[#8B5CF6]"
                    />
                    <span>Featured on Homepage</span>
                  </label>
                  <label className="flex items-center gap-2 text-sm text-[#D1D5E2]">
                    <input
                      type="checkbox"
                      checked={editingGame.trending}
                      onChange={(e) => setEditingGame({ ...editingGame, trending: e.target.checked })}
                      className="h-4 w-4 accent-[#38BDF8]"
                    />
                    <span>Trending Game</span>
                  </label>
                </div>
              </div>

              <div className="flex justify-end gap-3 border-t border-[#1D1F2B] pt-4">
                <button
                  type="button"
                  onClick={() => setEditingGame(null)}
                  className="rounded-lg border border-[#262938] px-4 py-2 text-sm text-[#D1D5E2] hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={busyId === editingGame.id}
                  className="rounded-lg bg-[#8B5CF6] px-5 py-2 text-sm font-semibold text-white hover:bg-[#7C3AED]"
                >
                  {busyId === editingGame.id ? 'Saving...' : 'Save Changes'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Replace Game File Modal */}
      {replacingGame && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 backdrop-blur-sm">
          <div className="w-full max-w-md rounded-2xl border border-[#262938] bg-[#111218] p-6">
            <h3 className="font-display text-xl font-bold text-[#F4F4F8]">
              Replace Build for {replacingGame.title}
            </h3>
            <p className="mt-1 text-xs text-[#9CA3B4]">
              Upload a newer ZIP, HTML, APK, or PC build while keeping your stats and listing URL.
            </p>
            <form onSubmit={handleReplaceFileSubmit} className="mt-5 space-y-4">
              <div>
                <label className="block text-xs font-medium text-[#A5ABBE]">New Version</label>
                <input
                  type="text"
                  value={replaceVersion}
                  onChange={(e) => setReplaceVersion(e.target.value)}
                  placeholder="1.1.0"
                  className="mt-1 w-full rounded-lg border border-[#262938] bg-[#0B0C11] px-3 py-2 font-mono text-sm text-white"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-[#A5ABBE]">New Game File</label>
                <input
                  type="file"
                  required
                  onChange={(e) => setReplaceFile(e.target.files?.[0] || null)}
                  className="mt-1 w-full text-sm text-[#D1D5E2]"
                />
              </div>
              <div className="flex justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setReplacingGame(null)}
                  className="rounded-lg border border-[#262938] px-4 py-2 text-sm text-[#D1D5E2]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={!replaceFile || busyId === replacingGame.id}
                  className="inline-flex items-center gap-2 rounded-lg bg-[#0EA5E9] px-4 py-2 text-sm font-semibold text-white hover:bg-[#0284C7] disabled:opacity-50"
                >
                  {busyId === replacingGame.id && <Loader2 className="h-4 w-4 animate-spin" />}
                  <span>Upload Replacement</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deletingGame && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 backdrop-blur-sm">
          <div className="w-full max-w-md rounded-2xl border border-rose-500/35 bg-[#111218] p-6">
            <h3 className="font-display text-xl font-bold text-[#F4F4F8]">Delete {deletingGame.title}?</h3>
            <p className="mt-2 text-sm text-[#9CA3B4]">
              This permanently removes the game listing, uploaded package file, and playable runtime files from Zyntra Game Store. This action cannot be undone.
            </p>
            <div className="mt-6 flex justify-end gap-3">
              <button
                type="button"
                onClick={() => setDeletingGame(null)}
                className="rounded-lg border border-[#262938] px-4 py-2 text-sm font-medium text-[#D1D5E2] hover:text-white"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={busyId === deletingGame.id}
                onClick={confirmDeleteGame}
                className="rounded-lg bg-rose-600 px-4 py-2 text-sm font-semibold text-white hover:bg-rose-500 disabled:opacity-60"
              >
                {busyId === deletingGame.id ? 'Deleting...' : 'Confirm Delete'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
