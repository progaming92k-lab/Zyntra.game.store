'use client';

import React, { useEffect, useRef } from 'react';

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  alpha: number;
  color: string;
}

export default function AnimatedBackground() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    const colors = ['#8B5CF6', '#38BDF8', '#A855F7', '#0EA5E9'];
    const particleCount = Math.min(48, Math.max(20, Math.floor((width * height) / 38000)));
    const particles: Particle[] = Array.from({ length: particleCount }, (_, i) => ({
      x: Math.random() * width,
      y: Math.random() * height,
      vx: (Math.random() - 0.5) * 0.28,
      vy: -0.12 - Math.random() * 0.24,
      radius: 1 + Math.random() * 1.6,
      alpha: 0.18 + Math.random() * 0.42,
      color: colors[i % colors.length],
    }));

    let pointerX = width * 0.5;
    let pointerY = height * 0.3;
    let rafId = 0;

    function handleResize() {
      if (!canvas) return;
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    }

    function handlePointerMove(e: PointerEvent) {
      pointerX = e.clientX;
      pointerY = e.clientY;
    }

    function drawFrame(animate: boolean) {
      if (!ctx) return;
      ctx.clearRect(0, 0, width, height);

      // Subtle interactive pointer glow
      const glow = ctx.createRadialGradient(pointerX, pointerY, 0, pointerX, pointerY, 360);
      glow.addColorStop(0, 'rgba(56, 189, 248, 0.055)');
      glow.addColorStop(0.5, 'rgba(139, 92, 246, 0.03)');
      glow.addColorStop(1, 'rgba(7, 7, 11, 0)');
      ctx.fillStyle = glow;
      ctx.fillRect(0, 0, width, height);

      // Subtle constellation lines & particles
      for (let i = 0; i < particles.length; i++) {
        const p = particles[i];
        if (animate) {
          p.x += p.vx;
          p.y += p.vy;
          if (p.y < -10) {
            p.y = height + 10;
            p.x = Math.random() * width;
          }
          if (p.x < -10) p.x = width + 10;
          if (p.x > width + 10) p.x = -10;
        }

        ctx.beginPath();
        ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
        ctx.fillStyle = p.color;
        ctx.globalAlpha = p.alpha;
        ctx.fill();

        // Connect nearby particles lightly
        for (let j = i + 1; j < particles.length; j++) {
          const q = particles[j];
          const dx = p.x - q.x;
          const dy = p.y - q.y;
          const distSq = dx * dx + dy * dy;
          if (distSq < 15000) {
            ctx.beginPath();
            ctx.moveTo(p.x, p.y);
            ctx.lineTo(q.x, q.y);
            ctx.strokeStyle = '#8B5CF6';
            ctx.globalAlpha = (1 - distSq / 15000) * 0.09;
            ctx.lineWidth = 1;
            ctx.stroke();
          }
        }
      }
      ctx.globalAlpha = 1;
    }

    function loop() {
      if (!document.hidden) {
        drawFrame(true);
      }
      rafId = window.requestAnimationFrame(loop);
    }

    window.addEventListener('resize', handleResize);
    window.addEventListener('pointermove', handlePointerMove, { passive: true });

    if (prefersReducedMotion) {
      drawFrame(false);
    } else {
      rafId = window.requestAnimationFrame(loop);
    }

    return () => {
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('pointermove', handlePointerMove);
      if (rafId) window.cancelAnimationFrame(rafId);
    };
  }, []);

  return (
    <div aria-hidden="true" className="pointer-events-none fixed inset-0 z-0 overflow-hidden bg-[#07070B]">
      {/* Subtle architectural perspective grid */}
      <div className="zyntra-bg-grid absolute inset-0 opacity-35" />

      {/* GPU-composited drifting neon purple & electric blue aurora orbs */}
      <div className="zyntra-aurora-purple absolute -left-32 -top-28 h-[520px] w-[520px] rounded-full bg-[radial-gradient(circle,rgba(139,92,246,0.19)_0%,rgba(139,92,246,0)_70%)] blur-2xl" />
      <div className="zyntra-aurora-blue absolute -right-32 top-[22%] h-[540px] w-[540px] rounded-full bg-[radial-gradient(circle,rgba(56,189,248,0.15)_0%,rgba(56,189,248,0)_70%)] blur-2xl" />
      <div className="zyntra-aurora-purple absolute bottom-[-180px] left-[28%] h-[480px] w-[480px] rounded-full bg-[radial-gradient(circle,rgba(168,85,247,0.12)_0%,rgba(168,85,247,0)_70%)] blur-2xl" />

      {/* Interactive ambient particle canvas */}
      <canvas ref={canvasRef} data-testid="animated-bg-canvas" className="absolute inset-0 h-full w-full" />
    </div>
  );
}
