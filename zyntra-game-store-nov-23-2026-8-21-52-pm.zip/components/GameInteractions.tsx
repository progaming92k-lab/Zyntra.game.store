'use client';

import React, { useMemo, useState } from 'react';
import { createPortal } from 'react-dom';
import { CheckCircle2, Flag, Heart, Loader2, MessageSquare, Star, X } from 'lucide-react';
import { playUiSound } from '@/lib/sound';
import type { GameReview } from '@/lib/types';

interface GameInteractionsProps {
  gameId: string;
  gameTitle: string;
  initialLikes: number;
  initialReviews: GameReview[];
}

export default function GameInteractions({
  gameId,
  gameTitle,
  initialLikes,
  initialReviews,
}: GameInteractionsProps) {
  const [likes, setLikes] = useState(initialLikes);
  const [liked, setLiked] = useState(false);
  const [liking, setLiking] = useState(false);

  const [reviews, setReviews] = useState<GameReview[]>(initialReviews);
  const [authorName, setAuthorName] = useState('');
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState('');
  const [submittingReview, setSubmittingReview] = useState(false);
  const [reviewNotice, setReviewNotice] = useState<string | null>(null);
  const [reviewError, setReviewError] = useState<string | null>(null);

  const [reportOpen, setReportOpen] = useState(false);
  const [reportReason, setReportReason] = useState('Broken File or Build');
  const [reportDetails, setReportDetails] = useState('');
  const [reporting, setReporting] = useState(false);
  const [reportSuccess, setReportSuccess] = useState(false);

  const avgRating = useMemo(() => {
    if (reviews.length === 0) return null;
    const sum = reviews.reduce((acc, r) => acc + r.rating, 0);
    return (sum / reviews.length).toFixed(1);
  }, [reviews]);

  async function handleLike() {
    if (liked || liking) return;
    setLiking(true);
    try {
      const res = await fetch(`/api/games/${encodeURIComponent(gameId)}/like`, {
        method: 'POST',
      });
      const data = (await res.json().catch(() => ({}))) as { likeCount?: number };
      if (res.ok) {
        playUiSound('success');
        setLiked(true);
        if (typeof data.likeCount === 'number') setLikes(data.likeCount);
        else setLikes((prev) => prev + 1);
      }
    } finally {
      setLiking(false);
    }
  }

  async function handleReviewSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (submittingReview) return;
    setReviewError(null);
    setReviewNotice(null);
    setSubmittingReview(true);

    try {
      const res = await fetch(`/api/games/${encodeURIComponent(gameId)}/reviews`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          authorName: authorName.trim() || 'Zyntra Player',
          rating,
          comment,
        }),
      });
      const data = (await res.json().catch(() => ({}))) as { review?: GameReview; error?: string };
      if (!res.ok || !data.review) {
        throw new Error(data.error || 'Could not post review.');
      }
      playUiSound('success');
      setReviews((prev) => [data.review!, ...prev]);
      setComment('');
      setReviewNotice('Your rating & review is now live.');
    } catch (err) {
      playUiSound('error');
      setReviewError(err instanceof Error ? err.message : 'Unable to submit review.');
    } finally {
      setSubmittingReview(false);
    }
  }

  async function handleReportSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (reporting) return;
    setReporting(true);
    try {
      const res = await fetch(`/api/games/${encodeURIComponent(gameId)}/report`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ reason: reportReason, details: reportDetails }),
      });
      if (res.ok) {
        playUiSound('success');
        setReportSuccess(true);
        setReportDetails('');
      }
    } finally {
      setReporting(false);
    }
  }

  return (
    <section aria-labelledby="community-reviews-heading" className="space-y-6">
      {/* Quick Reaction Bar: Like + Rating Summary + Report */}
      <div className="flex flex-wrap items-center justify-between gap-4 rounded-2xl border border-[#222432] bg-[#111218] p-5">
        <div className="flex flex-wrap items-center gap-4">
          <button
            type="button"
            disabled={liked || liking}
            onClick={handleLike}
            className={`inline-flex items-center gap-2 rounded-lg border px-4 py-2 text-sm font-semibold transition-all ${
              liked
                ? 'border-rose-500/50 bg-rose-500/15 text-rose-300'
                : 'border-[#272A3C] bg-[#161822] text-[#F4F4F8] hover:border-rose-400/60 hover:text-rose-300'
            }`}
          >
            <Heart className={`h-4 w-4 ${liked ? 'fill-current' : ''}`} aria-hidden="true" />
            <span>{liked ? 'Liked' : 'Like Game'}</span>
            <span className="font-mono tabular-nums text-xs">({likes})</span>
          </button>

          <div className="flex items-center gap-2 text-sm text-[#D1D5E2]">
            <Star className="h-4 w-4 fill-amber-400 text-amber-400" aria-hidden="true" />
            <span className="font-mono font-bold tabular-nums">{avgRating ? `${avgRating} / 5` : 'No ratings yet'}</span>
            <span className="text-xs text-[#8E94A8]">({reviews.length} {reviews.length === 1 ? 'review' : 'reviews'})</span>
          </div>
        </div>

        <button
          type="button"
          onClick={() => {
            setReportSuccess(false);
            setReportOpen(true);
          }}
          className="inline-flex items-center gap-1.5 rounded-lg border border-[#272A3C] bg-[#161822] px-3.5 py-2 text-xs font-medium text-[#9CA3B4] hover:border-amber-500/40 hover:text-amber-300"
        >
          <Flag className="h-3.5 w-3.5" aria-hidden="true" />
          <span>Report Game</span>
        </button>
      </div>

      {/* Ratings & Reviews Panel */}
      <div className="rounded-2xl border border-[#222432] bg-[#111218] p-6 sm:p-8">
        <div className="flex items-center gap-2">
          <MessageSquare className="h-5 w-5 text-[#38BDF8]" aria-hidden="true" />
          <h2 id="community-reviews-heading" className="font-display text-xl font-bold text-[#F4F4F8]">
            Ratings &amp; Reviews
          </h2>
        </div>

        <form onSubmit={handleReviewSubmit} className="mt-5 space-y-4 border-b border-[#1D1F2B] pb-6">
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div>
              <label htmlFor="review-author" className="block text-xs font-medium text-[#A5ABBE]">
                Your Name
              </label>
              <input
                id="review-author"
                type="text"
                value={authorName}
                onChange={(e) => setAuthorName(e.target.value)}
                placeholder="Player name (optional)"
                className="mt-1 w-full rounded-lg border border-[#262938] bg-[#0B0C11] px-3.5 py-2 text-sm text-[#F4F4F8] focus:border-[#38BDF8] focus:outline-none"
              />
            </div>

            <div>
              <span className="block text-xs font-medium text-[#A5ABBE]">Star Rating</span>
              <div className="mt-1.5 flex items-center gap-1.5" role="group" aria-label="Select star rating">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    type="button"
                    aria-label={`${star} star${star > 1 ? 's' : ''}`}
                    onClick={() => setRating(star)}
                    className="rounded p-1 transition-transform hover:scale-110"
                  >
                    <Star
                      className={`h-5 w-5 ${
                        star <= rating ? 'fill-amber-400 text-amber-400' : 'text-[#3B4056]'
                      }`}
                    />
                  </button>
                ))}
                <span className="ml-2 font-mono text-xs text-[#9CA3B4]">{rating}/5</span>
              </div>
            </div>
          </div>

          <div>
            <label htmlFor="review-comment" className="block text-xs font-medium text-[#A5ABBE]">
              Write a Review
            </label>
            <textarea
              id="review-comment"
              rows={3}
              required
              minLength={3}
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              placeholder={`Share your thoughts on ${gameTitle}...`}
              className="mt-1 w-full rounded-lg border border-[#262938] bg-[#0B0C11] px-3.5 py-2 text-sm text-[#F4F4F8] focus:border-[#38BDF8] focus:outline-none"
            />
          </div>

          {reviewError && <p className="text-xs text-rose-300">{reviewError}</p>}
          {reviewNotice && <p className="text-xs text-emerald-400">{reviewNotice}</p>}

          <button
            type="submit"
            disabled={submittingReview}
            className="zyntra-btn-shine inline-flex items-center gap-2 rounded-lg bg-gradient-to-r from-[#7C3AED] to-[#0EA5E9] px-5 py-2 text-sm font-semibold text-white hover:brightness-110 disabled:opacity-60"
          >
            {submittingReview && <Loader2 className="h-4 w-4 animate-spin" />}
            <span>Submit Review</span>
          </button>
        </form>

        <div className="mt-6 space-y-4">
          {reviews.length === 0 ? (
            <p className="text-sm text-[#8E94A8]">Be the first player to review {gameTitle}.</p>
          ) : (
            reviews.map((rev) => (
              <div key={rev.id} className="rounded-xl border border-[#1E202E] bg-[#0B0C11] p-4">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span className="text-sm font-semibold text-[#F4F4F8]">{rev.authorName}</span>
                  <div className="flex items-center gap-2">
                    <span className="inline-flex items-center gap-0.5 text-amber-400">
                      {Array.from({ length: rev.rating }).map((_, idx) => (
                        <Star key={idx} className="h-3.5 w-3.5 fill-current" aria-hidden="true" />
                      ))}
                    </span>
                    <span className="font-mono text-xs text-[#73788C]">{rev.createdAt.slice(0, 10)}</span>
                  </div>
                </div>
                <p className="mt-2 text-sm text-[#B6BCCF]">{rev.comment}</p>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Report Game Modal */}
      {reportOpen &&
        typeof document !== 'undefined' &&
        createPortal(
          <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/75 p-4 backdrop-blur-sm">
            <div className="w-full max-w-md rounded-2xl border border-[#262938] bg-[#111218] p-6">
              <div className="flex items-center justify-between border-b border-[#1D1F2B] pb-3">
                <h3 className="font-display text-lg font-bold text-white">Report {gameTitle}</h3>
                <button
                  type="button"
                  aria-label="Close report modal"
                  onClick={() => setReportOpen(false)}
                  className="rounded-lg p-1 text-[#8E94A8] hover:text-white"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>

              {reportSuccess ? (
                <div className="mt-5 space-y-4">
                  <div className="flex items-start gap-2.5 text-sm text-emerald-300">
                    <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0" />
                    <span>Report received. Our moderation queue will review {gameTitle}.</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => setReportOpen(false)}
                    className="w-full rounded-lg bg-[#8B5CF6] py-2 text-sm font-semibold text-white"
                  >
                    Done
                  </button>
                </div>
              ) : (
                <form onSubmit={handleReportSubmit} className="mt-4 space-y-4">
                  <div>
                    <label htmlFor="report-reason" className="block text-xs font-medium text-[#A5ABBE]">
                      Reason
                    </label>
                    <select
                      id="report-reason"
                      value={reportReason}
                      onChange={(e) => setReportReason(e.target.value)}
                      className="mt-1 w-full rounded-lg border border-[#262938] bg-[#0B0C11] px-3 py-2 text-sm text-white"
                    >
                      <option value="Broken File or Build">Broken File or Build</option>
                      <option value="Inappropriate Content">Inappropriate Content</option>
                      <option value="Copyright / Ownership Issue">Copyright / Ownership Issue</option>
                      <option value="Malware or Suspicious Behavior">Malware or Suspicious Behavior</option>
                      <option value="Other">Other</option>
                    </select>
                  </div>
                  <div>
                    <label htmlFor="report-details" className="block text-xs font-medium text-[#A5ABBE]">
                      Additional Details
                    </label>
                    <textarea
                      id="report-details"
                      rows={3}
                      value={reportDetails}
                      onChange={(e) => setReportDetails(e.target.value)}
                      placeholder="Describe what happened..."
                      className="mt-1 w-full rounded-lg border border-[#262938] bg-[#0B0C11] px-3 py-2 text-sm text-white"
                    />
                  </div>
                  <div className="flex justify-end gap-2.5 pt-1">
                    <button
                      type="button"
                      onClick={() => setReportOpen(false)}
                      className="rounded-lg border border-[#262938] px-4 py-2 text-xs font-medium text-[#D1D5E2]"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      disabled={reporting}
                      className="rounded-lg bg-amber-600 px-4 py-2 text-xs font-semibold text-white hover:bg-amber-500 disabled:opacity-60"
                    >
                      {reporting ? 'Submitting...' : 'Submit Report'}
                    </button>
                  </div>
                </form>
              )}
            </div>
          </div>,
          document.body
        )}
    </section>
  );
}
