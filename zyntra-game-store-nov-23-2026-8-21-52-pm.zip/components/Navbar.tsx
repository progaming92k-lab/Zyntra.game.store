'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { AnimatePresence, motion } from 'motion/react';
import { Menu, Upload, X } from 'lucide-react';

const NAV_LINKS = [
  { href: '/', label: 'Home' },
  { href: '/games', label: 'All Games' },
  { href: '/categories', label: 'Categories' },
  { href: '/search', label: 'Search' },
  { href: '/admin', label: 'Admin' },
];

export default function Navbar() {
  const pathname = usePathname();
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 border-b border-[#1E202C] bg-[#07070B]/92 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-2 sm:gap-4 md:gap-8 px-3 sm:px-6 lg:px-8">
        {/* Zone 1: Single-element Brand Wordmark */}
        <Link
          href="/"
          className="group inline-flex items-center gap-2 font-display text-sm sm:text-lg font-bold tracking-tight text-[#F4F4F8] whitespace-nowrap shrink-0 transition-colors hover:text-[#38BDF8]"
        >
          <span className="relative h-7 w-7 sm:h-8 sm:w-8 shrink-0 overflow-hidden rounded-lg border border-[#8B5CF6]/55 shadow-[0_0_16px_rgba(139,92,246,0.35)] transition-transform duration-200 group-hover:scale-105 group-hover:rotate-3">
            <Image
              src="/assets/aistudio/zyntra-ai-logo-rounded_5b64714d.png"
              alt="Zyntra Game Store logo"
              fill
              sizes="32px"
              priority
              referrerPolicy="no-referrer"
              className="object-cover"
            />
          </span>
          <span>Zyntra Game Store</span>
        </Link>

        {/* Zone 2: 5 concise single-line navigation links */}
        <nav aria-label="Main navigation" className="hidden md:flex items-center gap-7">
          {NAV_LINKS.map((item) => {
            const active =
              item.href === '/' ? pathname === '/' : pathname === item.href || pathname.startsWith(item.href + '/');
            return (
              <Link
                key={item.href}
                href={item.href}
                className={`relative py-2 text-sm font-medium whitespace-nowrap shrink-0 transition-colors duration-150 ${
                  active ? 'text-[#38BDF8]' : 'text-[#A0A4B8] hover:text-[#F4F4F8]'
                }`}
              >
                <span>{item.label}</span>
                {active && (
                  <motion.span
                    layoutId="navbar-active-indicator"
                    transition={{ type: 'spring', stiffness: 380, damping: 32 }}
                    className="absolute bottom-0 left-0 right-0 h-0.5 rounded-full bg-gradient-to-r from-[#8B5CF6] to-[#38BDF8]"
                  />
                )}
              </Link>
            );
          })}
        </nav>

        {/* Zone 3: Single Primary Action */}
        <div className="flex items-center gap-1.5 sm:gap-3 shrink-0">
          <Link
            href="/import"
            className="zyntra-btn-shine group inline-flex items-center gap-1.5 sm:gap-2 rounded-lg bg-gradient-to-r from-[#7C3AED] to-[#0EA5E9] px-2.5 py-2 sm:px-4 text-xs sm:text-sm font-semibold text-white shadow-[0_0_20px_rgba(124,58,237,0.35)] transition-all duration-200 hover:scale-[1.03] hover:shadow-[0_0_28px_rgba(56,189,248,0.5)] hover:brightness-110 whitespace-nowrap shrink-0"
          >
            <Upload className="h-3.5 w-3.5 sm:h-4 sm:w-4 transition-transform duration-200 group-hover:-translate-y-0.5" aria-hidden="true" />
            <span>Import Game</span>
          </Link>

          <button
            type="button"
            onClick={() => setMobileOpen((prev) => !prev)}
            aria-label={mobileOpen ? 'Close navigation menu' : 'Open navigation menu'}
            aria-expanded={mobileOpen}
            className="inline-flex h-10 w-10 sm:h-11 sm:w-11 items-center justify-center rounded-lg border border-[#232634] bg-[#111218] text-[#F4F4F8] transition-colors hover:border-[#38BDF8]/60 md:hidden shrink-0"
          >
            {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Navigation Drawer */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.nav
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.2, ease: 'easeOut' }}
            aria-label="Mobile navigation"
            className="overflow-hidden border-t border-[#1E202C] bg-[#0B0C11] px-4 py-4 md:hidden"
          >
            <div className="flex flex-col gap-1">
              {NAV_LINKS.map((item) => {
                const active =
                  item.href === '/' ? pathname === '/' : pathname === item.href || pathname.startsWith(item.href + '/');
                return (
                  <Link
                    key={item.href}
                    href={item.href}
                    onClick={() => setMobileOpen(false)}
                    className={`flex min-h-[44px] items-center rounded-lg px-3 text-sm font-medium transition-colors ${
                      active ? 'bg-[#181A24] text-[#38BDF8]' : 'text-[#C2C6D6] hover:bg-[#141620] hover:text-white'
                    }`}
                  >
                    {item.label}
                  </Link>
                );
              })}
            </div>
          </motion.nav>
        )}
      </AnimatePresence>
    </header>
  );
}
