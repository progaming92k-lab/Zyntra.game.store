import Database from 'better-sqlite3';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { DEFAULT_CATEGORIES, slugify } from './game-logic';
import type {
  CategoryRecord,
  CreatorAccount,
  GameLifecycleStatus,
  GamePlatform,
  GameRecord,
  GameReport,
  GameReview,
  GameStatus,
  GameVisibility,
  PricingType,
  StoreStats,
} from './types';

export const STORAGE_ROOT = path.resolve(process.cwd(), 'storage');
export const FILES_DIR = path.join(STORAGE_ROOT, 'files');
export const PLAYABLE_DIR = path.join(STORAGE_ROOT, 'playable');
export const MEDIA_DIR = path.join(STORAGE_ROOT, 'media');
export const COVERS_DIR = path.join(MEDIA_DIR, 'covers');
export const ICONS_DIR = path.join(MEDIA_DIR, 'icons');
export const SCREENSHOTS_DIR = path.join(MEDIA_DIR, 'screenshots');
const DB_PATH = path.join(STORAGE_ROOT, 'zyntra.db');

function ensureStorageDirectories() {
  for (const dir of [STORAGE_ROOT, FILES_DIR, PLAYABLE_DIR, MEDIA_DIR, COVERS_DIR, ICONS_DIR, SCREENSHOTS_DIR]) {
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
  }
}

const globalForDb = globalThis as unknown as {
  __zyntraDb?: Database.Database;
};

function ensureGameColumns(db: Database.Database) {
  const cols = db.prepare('PRAGMA table_info(games)').all() as Array<{ name: string }>;
  const existing = new Set(cols.map((c) => c.name));

  const additions: Array<[string, string]> = [
    ['publisher', "TEXT NOT NULL DEFAULT 'Zyntra Indie Publishing'"],
    ['creator_username', "TEXT NOT NULL DEFAULT ''"],
    ['content_rating', "TEXT NOT NULL DEFAULT 'All Ages · Family Friendly'"],
    ['languages', "TEXT NOT NULL DEFAULT 'English'"],
    ['player_mode', "TEXT NOT NULL DEFAULT 'Single Player'"],
    ['internet_requirement', "TEXT NOT NULL DEFAULT 'Offline Supported'"],
    ['rec_requirements', "TEXT NOT NULL DEFAULT ''"],
    ['privacy_policy', "TEXT NOT NULL DEFAULT ''"],
    ['terms_conditions', "TEXT NOT NULL DEFAULT ''"],
    ['copyright_info', "TEXT NOT NULL DEFAULT ''"],
    ['permissions', "TEXT NOT NULL DEFAULT ''"],
    ['scheduled_release_at', 'TEXT'],
    ['game_status', "TEXT NOT NULL DEFAULT 'Released'"],
    ['visibility', "TEXT NOT NULL DEFAULT 'public'"],
    ['trending', 'INTEGER NOT NULL DEFAULT 0'],
    ['pricing_type', "TEXT NOT NULL DEFAULT 'free'"],
    ['price_label', "TEXT NOT NULL DEFAULT 'Free'"],
    ['view_count', 'INTEGER NOT NULL DEFAULT 0'],
    ['like_count', 'INTEGER NOT NULL DEFAULT 0'],
  ];

  for (const [colName, colDef] of additions) {
    if (!existing.has(colName)) {
      db.exec(`ALTER TABLE games ADD COLUMN ${colName} ${colDef}`);
    }
  }
}

export function getDb(): Database.Database {
  if (globalForDb.__zyntraDb) {
    return globalForDb.__zyntraDb;
  }

  ensureStorageDirectories();
  const db = new Database(DB_PATH);
  db.pragma('journal_mode = WAL');
  db.pragma('foreign_keys = ON');

  db.exec(`
    CREATE TABLE IF NOT EXISTS games (
      id TEXT PRIMARY KEY,
      slug TEXT UNIQUE NOT NULL,
      title TEXT NOT NULL,
      short_title TEXT NOT NULL,
      short_description TEXT NOT NULL,
      full_description TEXT NOT NULL,
      category TEXT NOT NULL,
      genre TEXT NOT NULL,
      platform TEXT NOT NULL,
      version TEXT NOT NULL,
      developer TEXT NOT NULL,
      publisher TEXT NOT NULL DEFAULT 'Zyntra Indie Publishing',
      creator_username TEXT NOT NULL DEFAULT '',
      file_size INTEGER NOT NULL DEFAULT 0,
      file_format TEXT NOT NULL,
      original_filename TEXT NOT NULL,
      stored_file_path TEXT NOT NULL,
      extracted_dir TEXT,
      entry_file TEXT,
      is_browser_playable INTEGER NOT NULL DEFAULT 0,
      is_downloadable INTEGER NOT NULL DEFAULT 1,
      cover_image TEXT NOT NULL,
      icon_image TEXT NOT NULL,
      screenshots_json TEXT NOT NULL DEFAULT '[]',
      tags_json TEXT NOT NULL DEFAULT '[]',
      age_rating TEXT NOT NULL DEFAULT 'Everyone',
      content_rating TEXT NOT NULL DEFAULT 'All Ages · Family Friendly',
      languages TEXT NOT NULL DEFAULT 'English',
      player_mode TEXT NOT NULL DEFAULT 'Single Player',
      internet_requirement TEXT NOT NULL DEFAULT 'Offline Supported',
      controls TEXT NOT NULL DEFAULT '',
      instructions TEXT NOT NULL DEFAULT '',
      min_requirements TEXT NOT NULL DEFAULT '',
      rec_requirements TEXT NOT NULL DEFAULT '',
      privacy_policy TEXT NOT NULL DEFAULT '',
      terms_conditions TEXT NOT NULL DEFAULT '',
      copyright_info TEXT NOT NULL DEFAULT '',
      permissions TEXT NOT NULL DEFAULT '',
      release_date TEXT NOT NULL,
      upload_date TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      scheduled_release_at TEXT,
      game_status TEXT NOT NULL DEFAULT 'Released',
      status TEXT NOT NULL DEFAULT 'draft',
      visibility TEXT NOT NULL DEFAULT 'public',
      featured INTEGER NOT NULL DEFAULT 0,
      trending INTEGER NOT NULL DEFAULT 0,
      pricing_type TEXT NOT NULL DEFAULT 'free',
      price_label TEXT NOT NULL DEFAULT 'Free',
      collection_name TEXT NOT NULL DEFAULT '',
      download_count INTEGER NOT NULL DEFAULT 0,
      play_count INTEGER NOT NULL DEFAULT 0,
      view_count INTEGER NOT NULL DEFAULT 0,
      like_count INTEGER NOT NULL DEFAULT 0,
      ai_summary_notes TEXT NOT NULL DEFAULT ''
    );

    CREATE INDEX IF NOT EXISTS idx_games_status ON games(status);
    CREATE INDEX IF NOT EXISTS idx_games_category ON games(category);
    CREATE INDEX IF NOT EXISTS idx_games_slug ON games(slug);

    CREATE TABLE IF NOT EXISTS categories (
      id TEXT PRIMARY KEY,
      name TEXT UNIQUE NOT NULL,
      slug TEXT UNIQUE NOT NULL,
      description TEXT NOT NULL,
      sort_order INTEGER NOT NULL DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS creators (
      id TEXT PRIMARY KEY,
      username TEXT UNIQUE NOT NULL,
      display_name TEXT NOT NULL,
      password_hash TEXT NOT NULL,
      bio TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS game_reviews (
      id TEXT PRIMARY KEY,
      game_id TEXT NOT NULL,
      author_name TEXT NOT NULL,
      rating INTEGER NOT NULL,
      comment TEXT NOT NULL,
      created_at TEXT NOT NULL,
      FOREIGN KEY (game_id) REFERENCES games(id) ON DELETE CASCADE
    );
    CREATE INDEX IF NOT EXISTS idx_reviews_game ON game_reviews(game_id);

    CREATE TABLE IF NOT EXISTS game_reports (
      id TEXT PRIMARY KEY,
      game_id TEXT NOT NULL,
      reason TEXT NOT NULL,
      details TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL,
      FOREIGN KEY (game_id) REFERENCES games(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS app_config (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS contact_messages (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      email TEXT NOT NULL,
      subject TEXT NOT NULL,
      message TEXT NOT NULL,
      created_at TEXT NOT NULL
    );
  `);

  ensureGameColumns(db);

  // Seed default categories if empty
  const catCountRow = db.prepare('SELECT COUNT(*) as cnt FROM categories').get() as { cnt: number };
  if (catCountRow.cnt === 0) {
    const insertCat = db.prepare(
      'INSERT OR IGNORE INTO categories (id, name, slug, description, sort_order) VALUES (?, ?, ?, ?, ?)'
    );
    const seedTx = db.transaction(() => {
      DEFAULT_CATEGORIES.forEach((cat, idx) => {
        insertCat.run(crypto.randomUUID(), cat.name, cat.slug, cat.description, idx + 1);
      });
    });
    seedTx();
  }

  globalForDb.__zyntraDb = db;
  return db;
}

interface RawGameRow {
  id: string;
  slug: string;
  title: string;
  short_title: string;
  short_description: string;
  full_description: string;
  category: string;
  genre: string;
  platform: string;
  version: string;
  developer: string;
  publisher: string;
  creator_username: string;
  file_size: number;
  file_format: string;
  original_filename: string;
  stored_file_path: string;
  extracted_dir: string | null;
  entry_file: string | null;
  is_browser_playable: number;
  is_downloadable: number;
  cover_image: string;
  icon_image: string;
  screenshots_json: string;
  tags_json: string;
  age_rating: string;
  content_rating: string;
  languages: string;
  player_mode: string;
  internet_requirement: string;
  controls: string;
  instructions: string;
  min_requirements: string;
  rec_requirements: string;
  privacy_policy: string;
  terms_conditions: string;
  copyright_info: string;
  permissions: string;
  release_date: string;
  upload_date: string;
  updated_at: string;
  scheduled_release_at: string | null;
  game_status: string;
  status: string;
  visibility: string;
  featured: number;
  trending: number;
  pricing_type: string;
  price_label: string;
  collection_name: string;
  download_count: number;
  play_count: number;
  view_count: number;
  like_count: number;
  ai_summary_notes: string;
}

function normalizeStatus(status: string): GameStatus {
  if (status === 'published' || status === 'scheduled' || status === 'unpublished') return status;
  return 'draft';
}

function normalizeLifecycle(val: string): GameLifecycleStatus {
  if (val === 'Beta' || val === 'Early Access' || val === 'Alpha') return val;
  return 'Released';
}

function mapGameRow(row: RawGameRow): GameRecord {
  let screenshots: string[] = [];
  let tags: string[] = [];
  try {
    screenshots = JSON.parse(row.screenshots_json);
    if (!Array.isArray(screenshots)) screenshots = [];
  } catch {
    screenshots = [];
  }
  try {
    tags = JSON.parse(row.tags_json);
    if (!Array.isArray(tags)) tags = [];
  } catch {
    tags = [];
  }

  return {
    id: row.id,
    slug: row.slug,
    title: row.title,
    shortTitle: row.short_title,
    shortDescription: row.short_description,
    fullDescription: row.full_description,
    category: row.category,
    genre: row.genre,
    platform: row.platform as GamePlatform,
    version: row.version,
    developer: row.developer,
    publisher: row.publisher || 'Zyntra Indie Publishing',
    creatorUsername: row.creator_username || '',
    fileSize: row.file_size,
    fileFormat: row.file_format,
    originalFilename: row.original_filename,
    storedFilePath: row.stored_file_path,
    extractedDir: row.extracted_dir,
    entryFile: row.entry_file,
    isBrowserPlayable: Boolean(row.is_browser_playable),
    isDownloadable: Boolean(row.is_downloadable),
    coverImage: row.cover_image,
    iconImage: row.icon_image,
    screenshots,
    tags,
    ageRating: row.age_rating || 'Everyone',
    contentRating: row.content_rating || 'All Ages · Family Friendly',
    languages: row.languages || 'English',
    playerMode: row.player_mode || 'Single Player',
    internetRequirement: row.internet_requirement || 'Offline Supported',
    controls: row.controls,
    instructions: row.instructions,
    minRequirements: row.min_requirements,
    recRequirements: row.rec_requirements || '',
    privacyPolicy: row.privacy_policy || '',
    termsConditions: row.terms_conditions || '',
    copyrightInfo: row.copyright_info || '',
    permissions: row.permissions || '',
    releaseDate: row.release_date,
    uploadDate: row.upload_date,
    updatedAt: row.updated_at,
    scheduledReleaseAt: row.scheduled_release_at || null,
    gameStatus: normalizeLifecycle(row.game_status),
    status: normalizeStatus(row.status),
    visibility: (row.visibility === 'private' ? 'private' : 'public') as GameVisibility,
    featured: Boolean(row.featured),
    trending: Boolean(row.trending),
    pricingType: (row.pricing_type === 'paid' ? 'paid' : 'free') as PricingType,
    priceLabel: row.price_label || 'Free',
    collectionName: row.collection_name || '',
    downloadCount: row.download_count || 0,
    playCount: row.play_count || 0,
    viewCount: row.view_count || 0,
    likeCount: row.like_count || 0,
    aiSummaryNotes: row.ai_summary_notes || '',
  };
}

export function publishDueScheduledGames(dbInstance?: Database.Database): void {
  const db = dbInstance || getDb();
  const nowIso = new Date().toISOString();
  db.prepare(
    "UPDATE games SET status = 'published', updated_at = ? WHERE status = 'scheduled' AND scheduled_release_at IS NOT NULL AND datetime(scheduled_release_at) <= datetime(?)"
  ).run(nowIso, nowIso);
}

export function listGames(options: { includeDrafts?: boolean } = {}): GameRecord[] {
  const db = getDb();
  publishDueScheduledGames(db);
  const sql = options.includeDrafts
    ? 'SELECT * FROM games ORDER BY datetime(upload_date) DESC'
    : "SELECT * FROM games WHERE status = 'published' AND visibility = 'public' ORDER BY datetime(upload_date) DESC";
  const rows = db.prepare(sql).all() as RawGameRow[];
  return rows.map(mapGameRow);
}

export function listGamesByCreator(usernameOrDeveloper: string, includePrivate = false): GameRecord[] {
  const db = getDb();
  publishDueScheduledGames(db);
  const needle = usernameOrDeveloper.trim().toLowerCase();
  const sql = includePrivate
    ? 'SELECT * FROM games WHERE lower(creator_username) = ? OR lower(developer) = ? ORDER BY datetime(upload_date) DESC'
    : "SELECT * FROM games WHERE status = 'published' AND visibility = 'public' AND (lower(creator_username) = ? OR lower(developer) = ?) ORDER BY datetime(upload_date) DESC";
  const rows = db.prepare(sql).all(needle, needle) as RawGameRow[];
  return rows.map(mapGameRow);
}

export function getAllSlugs(): Set<string> {
  const db = getDb();
  const rows = db.prepare('SELECT slug FROM games').all() as Array<{ slug: string }>;
  return new Set(rows.map((r) => r.slug));
}

export function getGameBySlug(slug: string, includeDraft = false): GameRecord | null {
  const db = getDb();
  publishDueScheduledGames(db);
  const row = (
    includeDraft
      ? db.prepare('SELECT * FROM games WHERE slug = ?').get(slug)
      : db.prepare("SELECT * FROM games WHERE slug = ? AND status = 'published'").get(slug)
  ) as RawGameRow | undefined;
  return row ? mapGameRow(row) : null;
}

export function getGameById(id: string): GameRecord | null {
  const db = getDb();
  publishDueScheduledGames(db);
  const row = db.prepare('SELECT * FROM games WHERE id = ?').get(id) as RawGameRow | undefined;
  return row ? mapGameRow(row) : null;
}

export function insertGame(game: GameRecord): GameRecord {
  const db = getDb();
  db.prepare(`
    INSERT INTO games (
      id, slug, title, short_title, short_description, full_description,
      category, genre, platform, version, developer, publisher, creator_username,
      file_size, file_format, original_filename, stored_file_path, extracted_dir, entry_file,
      is_browser_playable, is_downloadable, cover_image, icon_image,
      screenshots_json, tags_json, age_rating, content_rating, languages,
      player_mode, internet_requirement, controls, instructions,
      min_requirements, rec_requirements, privacy_policy, terms_conditions,
      copyright_info, permissions, release_date, upload_date, updated_at,
      scheduled_release_at, game_status, status, visibility, featured, trending,
      pricing_type, price_label, collection_name, download_count, play_count,
      view_count, like_count, ai_summary_notes
    ) VALUES (
      @id, @slug, @title, @short_title, @short_description, @full_description,
      @category, @genre, @platform, @version, @developer, @publisher, @creator_username,
      @file_size, @file_format, @original_filename, @stored_file_path, @extracted_dir, @entry_file,
      @is_browser_playable, @is_downloadable, @cover_image, @icon_image,
      @screenshots_json, @tags_json, @age_rating, @content_rating, @languages,
      @player_mode, @internet_requirement, @controls, @instructions,
      @min_requirements, @rec_requirements, @privacy_policy, @terms_conditions,
      @copyright_info, @permissions, @release_date, @upload_date, @updated_at,
      @scheduled_release_at, @game_status, @status, @visibility, @featured, @trending,
      @pricing_type, @price_label, @collection_name, @download_count, @play_count,
      @view_count, @like_count, @ai_summary_notes
    )
  `).run({
    id: game.id,
    slug: game.slug,
    title: game.title,
    short_title: game.shortTitle,
    short_description: game.shortDescription,
    full_description: game.fullDescription,
    category: game.category,
    genre: game.genre,
    platform: game.platform,
    version: game.version,
    developer: game.developer,
    publisher: game.publisher,
    creator_username: game.creatorUsername,
    file_size: game.fileSize,
    file_format: game.fileFormat,
    original_filename: game.originalFilename,
    stored_file_path: game.storedFilePath,
    extracted_dir: game.extractedDir,
    entry_file: game.entryFile,
    is_browser_playable: game.isBrowserPlayable ? 1 : 0,
    is_downloadable: game.isDownloadable ? 1 : 0,
    cover_image: game.coverImage,
    icon_image: game.iconImage,
    screenshots_json: JSON.stringify(game.screenshots),
    tags_json: JSON.stringify(game.tags),
    age_rating: game.ageRating,
    content_rating: game.contentRating,
    languages: game.languages,
    player_mode: game.playerMode,
    internet_requirement: game.internetRequirement,
    controls: game.controls,
    instructions: game.instructions,
    min_requirements: game.minRequirements,
    rec_requirements: game.recRequirements,
    privacy_policy: game.privacyPolicy,
    terms_conditions: game.termsConditions,
    copyright_info: game.copyrightInfo,
    permissions: game.permissions,
    release_date: game.releaseDate,
    upload_date: game.uploadDate,
    updated_at: game.updatedAt,
    scheduled_release_at: game.scheduledReleaseAt,
    game_status: game.gameStatus,
    status: game.status,
    visibility: game.visibility,
    featured: game.featured ? 1 : 0,
    trending: game.trending ? 1 : 0,
    pricing_type: game.pricingType,
    price_label: game.priceLabel,
    collection_name: game.collectionName,
    download_count: game.downloadCount,
    play_count: game.playCount,
    view_count: game.viewCount,
    like_count: game.likeCount,
    ai_summary_notes: game.aiSummaryNotes,
  });
  return game;
}

export function updateGame(id: string, patch: Partial<GameRecord>): GameRecord | null {
  const existing = getGameById(id);
  if (!existing) return null;
  const merged: GameRecord = {
    ...existing,
    ...patch,
    id: existing.id,
    updatedAt: new Date().toISOString(),
  };

  const db = getDb();
  db.prepare(`
    UPDATE games SET
      slug = @slug,
      title = @title,
      short_title = @short_title,
      short_description = @short_description,
      full_description = @full_description,
      category = @category,
      genre = @genre,
      platform = @platform,
      version = @version,
      developer = @developer,
      publisher = @publisher,
      creator_username = @creator_username,
      file_size = @file_size,
      file_format = @file_format,
      original_filename = @original_filename,
      stored_file_path = @stored_file_path,
      extracted_dir = @extracted_dir,
      entry_file = @entry_file,
      is_browser_playable = @is_browser_playable,
      is_downloadable = @is_downloadable,
      cover_image = @cover_image,
      icon_image = @icon_image,
      screenshots_json = @screenshots_json,
      tags_json = @tags_json,
      age_rating = @age_rating,
      content_rating = @content_rating,
      languages = @languages,
      player_mode = @player_mode,
      internet_requirement = @internet_requirement,
      controls = @controls,
      instructions = @instructions,
      min_requirements = @min_requirements,
      rec_requirements = @rec_requirements,
      privacy_policy = @privacy_policy,
      terms_conditions = @terms_conditions,
      copyright_info = @copyright_info,
      permissions = @permissions,
      release_date = @release_date,
      updated_at = @updated_at,
      scheduled_release_at = @scheduled_release_at,
      game_status = @game_status,
      status = @status,
      visibility = @visibility,
      featured = @featured,
      trending = @trending,
      pricing_type = @pricing_type,
      price_label = @price_label,
      collection_name = @collection_name,
      ai_summary_notes = @ai_summary_notes
    WHERE id = @id
  `).run({
    id: merged.id,
    slug: merged.slug,
    title: merged.title,
    short_title: merged.shortTitle,
    short_description: merged.shortDescription,
    full_description: merged.fullDescription,
    category: merged.category,
    genre: merged.genre,
    platform: merged.platform,
    version: merged.version,
    developer: merged.developer,
    publisher: merged.publisher,
    creator_username: merged.creatorUsername,
    file_size: merged.fileSize,
    file_format: merged.fileFormat,
    original_filename: merged.originalFilename,
    stored_file_path: merged.storedFilePath,
    extracted_dir: merged.extractedDir,
    entry_file: merged.entryFile,
    is_browser_playable: merged.isBrowserPlayable ? 1 : 0,
    is_downloadable: merged.isDownloadable ? 1 : 0,
    cover_image: merged.coverImage,
    icon_image: merged.iconImage,
    screenshots_json: JSON.stringify(merged.screenshots),
    tags_json: JSON.stringify(merged.tags),
    age_rating: merged.ageRating,
    content_rating: merged.contentRating,
    languages: merged.languages,
    player_mode: merged.playerMode,
    internet_requirement: merged.internetRequirement,
    controls: merged.controls,
    instructions: merged.instructions,
    min_requirements: merged.minRequirements,
    rec_requirements: merged.recRequirements,
    privacy_policy: merged.privacyPolicy,
    terms_conditions: merged.termsConditions,
    copyright_info: merged.copyrightInfo,
    permissions: merged.permissions,
    release_date: merged.releaseDate,
    updated_at: merged.updatedAt,
    scheduled_release_at: merged.scheduledReleaseAt,
    game_status: merged.gameStatus,
    status: merged.status,
    visibility: merged.visibility,
    featured: merged.featured ? 1 : 0,
    trending: merged.trending ? 1 : 0,
    pricing_type: merged.pricingType,
    price_label: merged.priceLabel,
    collection_name: merged.collectionName,
    ai_summary_notes: merged.aiSummaryNotes,
  });

  return merged;
}

export function deleteGameById(id: string): boolean {
  const existing = getGameById(id);
  if (!existing) return false;
  const db = getDb();
  db.prepare('DELETE FROM games WHERE id = ?').run(id);

  try {
    const fileDir = path.dirname(path.join(FILES_DIR, existing.storedFilePath));
    if (fileDir.startsWith(FILES_DIR + path.sep) && fs.existsSync(fileDir)) {
      fs.rmSync(fileDir, { recursive: true, force: true });
    }
    if (existing.extractedDir) {
      const playPath = path.join(PLAYABLE_DIR, existing.extractedDir);
      if (playPath.startsWith(PLAYABLE_DIR + path.sep) && fs.existsSync(playPath)) {
        fs.rmSync(playPath, { recursive: true, force: true });
      }
    }
  } catch {
    // Best-effort file cleanup
  }
  return true;
}

export function incrementDownloadCount(id: string): void {
  const db = getDb();
  db.prepare('UPDATE games SET download_count = download_count + 1 WHERE id = ?').run(id);
}

export function incrementPlayCount(id: string): void {
  const db = getDb();
  db.prepare('UPDATE games SET play_count = play_count + 1 WHERE id = ?').run(id);
}

export function incrementViewCount(id: string): number {
  const db = getDb();
  db.prepare('UPDATE games SET view_count = view_count + 1 WHERE id = ?').run(id);
  const row = db.prepare('SELECT view_count FROM games WHERE id = ?').get(id) as { view_count: number } | undefined;
  return row ? row.view_count : 0;
}

export function incrementLikeCount(id: string): number {
  const db = getDb();
  db.prepare('UPDATE games SET like_count = like_count + 1 WHERE id = ?').run(id);
  const row = db.prepare('SELECT like_count FROM games WHERE id = ?').get(id) as { like_count: number } | undefined;
  return row ? row.like_count : 0;
}

export function listGameReviews(gameId: string): GameReview[] {
  const db = getDb();
  const rows = db
    .prepare('SELECT id, game_id, author_name, rating, comment, created_at FROM game_reviews WHERE game_id = ? ORDER BY datetime(created_at) DESC')
    .all(gameId) as Array<{
    id: string;
    game_id: string;
    author_name: string;
    rating: number;
    comment: string;
    created_at: string;
  }>;
  return rows.map((r) => ({
    id: r.id,
    gameId: r.game_id,
    authorName: r.author_name,
    rating: r.rating,
    comment: r.comment,
    createdAt: r.created_at,
  }));
}

export function addGameReview(input: {
  gameId: string;
  authorName: string;
  rating: number;
  comment: string;
}): GameReview {
  const db = getDb();
  const id = crypto.randomUUID();
  const createdAt = new Date().toISOString();
  const rating = Math.min(5, Math.max(1, Math.round(input.rating)));
  db.prepare(
    'INSERT INTO game_reviews (id, game_id, author_name, rating, comment, created_at) VALUES (?, ?, ?, ?, ?, ?)'
  ).run(id, input.gameId, input.authorName, rating, input.comment, createdAt);
  return {
    id,
    gameId: input.gameId,
    authorName: input.authorName,
    rating,
    comment: input.comment,
    createdAt,
  };
}

export function addGameReport(input: {
  gameId: string;
  reason: string;
  details: string;
}): GameReport {
  const db = getDb();
  const id = crypto.randomUUID();
  const createdAt = new Date().toISOString();
  db.prepare(
    'INSERT INTO game_reports (id, game_id, reason, details, created_at) VALUES (?, ?, ?, ?, ?)'
  ).run(id, input.gameId, input.reason, input.details, createdAt);
  return {
    id,
    gameId: input.gameId,
    reason: input.reason,
    details: input.details,
    createdAt,
  };
}

export function listGameReports(): GameReport[] {
  const db = getDb();
  const rows = db
    .prepare(
      `SELECT r.id, r.game_id, g.title as game_title, r.reason, r.details, r.created_at
       FROM game_reports r
       LEFT JOIN games g ON g.id = r.game_id
       ORDER BY datetime(r.created_at) DESC`
    )
    .all() as Array<{
    id: string;
    game_id: string;
    game_title: string | null;
    reason: string;
    details: string;
    created_at: string;
  }>;
  return rows.map((r) => ({
    id: r.id,
    gameId: r.game_id,
    gameTitle: r.game_title || 'Unknown Game',
    reason: r.reason,
    details: r.details,
    createdAt: r.created_at,
  }));
}

export function createCreatorAccount(input: {
  username: string;
  displayName: string;
  passwordHash: string;
  bio?: string;
}): CreatorAccount {
  const db = getDb();
  const id = crypto.randomUUID();
  const createdAt = new Date().toISOString();
  db.prepare(
    'INSERT INTO creators (id, username, display_name, password_hash, bio, created_at) VALUES (?, ?, ?, ?, ?, ?)'
  ).run(id, input.username, input.displayName, input.passwordHash, input.bio || '', createdAt);
  return {
    id,
    username: input.username,
    displayName: input.displayName,
    bio: input.bio || '',
    createdAt,
  };
}

export function getCreatorWithHashByUsername(username: string): (CreatorAccount & { passwordHash: string }) | null {
  const db = getDb();
  const row = db
    .prepare('SELECT id, username, display_name, password_hash, bio, created_at FROM creators WHERE lower(username) = ?')
    .get(username.trim().toLowerCase()) as
    | {
        id: string;
        username: string;
        display_name: string;
        password_hash: string;
        bio: string;
        created_at: string;
      }
    | undefined;
  if (!row) return null;
  return {
    id: row.id,
    username: row.username,
    displayName: row.display_name,
    passwordHash: row.password_hash,
    bio: row.bio,
    createdAt: row.created_at,
  };
}

export function getCreatorByUsername(username: string): CreatorAccount | null {
  const found = getCreatorWithHashByUsername(username);
  if (!found) return null;
  return {
    id: found.id,
    username: found.username,
    displayName: found.displayName,
    bio: found.bio,
    createdAt: found.createdAt,
  };
}

export function listCategories(includeCounts = true): CategoryRecord[] {
  const db = getDb();
  publishDueScheduledGames(db);
  const rows = db.prepare('SELECT * FROM categories ORDER BY sort_order ASC, name ASC').all() as Array<{
    id: string;
    name: string;
    slug: string;
    description: string;
    sort_order: number;
  }>;

  let countsMap = new Map<string, number>();
  if (includeCounts) {
    const countRows = db
      .prepare("SELECT category, COUNT(*) as cnt FROM games WHERE status = 'published' AND visibility = 'public' GROUP BY category")
      .all() as Array<{ category: string; cnt: number }>;
    countsMap = new Map(countRows.map((r) => [r.category.toLowerCase(), r.cnt]));
  }

  return rows.map((r) => ({
    id: r.id,
    name: r.name,
    slug: r.slug,
    description: r.description,
    sortOrder: r.sort_order,
    gameCount: countsMap.get(r.name.toLowerCase()) || 0,
  }));
}

export function createCategory(name: string, description: string): CategoryRecord {
  const db = getDb();
  const cleanName = name.trim();
  const slug = slugify(cleanName);
  const id = crypto.randomUUID();
  const maxOrderRow = db.prepare('SELECT COALESCE(MAX(sort_order), 0) as m FROM categories').get() as { m: number };
  db.prepare('INSERT INTO categories (id, name, slug, description, sort_order) VALUES (?, ?, ?, ?, ?)').run(
    id,
    cleanName,
    slug,
    description.trim() || `${cleanName} games on Zyntra Game Store.`,
    maxOrderRow.m + 1
  );
  return {
    id,
    name: cleanName,
    slug,
    description: description.trim() || `${cleanName} games on Zyntra Game Store.`,
    sortOrder: maxOrderRow.m + 1,
    gameCount: 0,
  };
}

export function deleteCategoryById(id: string): boolean {
  const db = getDb();
  const res = db.prepare('DELETE FROM categories WHERE id = ?').run(id);
  return res.changes > 0;
}

export function getStoreStats(): StoreStats {
  const db = getDb();
  publishDueScheduledGames(db);
  const row = db
    .prepare(
      `SELECT
        COUNT(*) as totalUploads,
        COALESCE(SUM(CASE WHEN status = 'published' THEN 1 ELSE 0 END), 0) as totalPublished,
        COALESCE(SUM(CASE WHEN status != 'published' THEN 1 ELSE 0 END), 0) as totalDrafts,
        COALESCE(SUM(download_count), 0) as totalDownloads,
        COALESCE(SUM(play_count), 0) as totalPlays,
        COALESCE(SUM(view_count), 0) as totalViews,
        COALESCE(SUM(like_count), 0) as totalLikes,
        COALESCE(SUM(file_size), 0) as storageUsedBytes
      FROM games`
    )
    .get() as StoreStats;
  return row;
}

export function getConfig(key: string): string | null {
  const db = getDb();
  const row = db.prepare('SELECT value FROM app_config WHERE key = ?').get(key) as { value: string } | undefined;
  return row ? row.value : null;
}

export function setConfig(key: string, value: string): void {
  const db = getDb();
  db.prepare('INSERT INTO app_config (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value').run(
    key,
    value
  );
}

export function saveContactMessage(input: {
  name: string;
  email: string;
  subject: string;
  message: string;
}): string {
  const db = getDb();
  const id = crypto.randomUUID();
  db.prepare(
    'INSERT INTO contact_messages (id, name, email, subject, message, created_at) VALUES (?, ?, ?, ?, ?, ?)'
  ).run(id, input.name, input.email, input.subject, input.message, new Date().toISOString());
  return id;
}
