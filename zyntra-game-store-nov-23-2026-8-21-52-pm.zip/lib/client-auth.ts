let memoryAuthToken: string | null = null;

export function setClientAuthToken(token: string | null): void {
  memoryAuthToken = token && token.trim() ? token.trim() : null;
}

export function getClientAuthToken(): string | null {
  return memoryAuthToken;
}

export function clearClientAuthToken(): void {
  memoryAuthToken = null;
}

export function buildAuthHeaders(extra: Record<string, string> = {}): Record<string, string> {
  const headers: Record<string, string> = {
    'X-Requested-With': 'ZyntraStore',
    ...extra,
  };
  if (memoryAuthToken) {
    headers.Authorization = `Bearer ${memoryAuthToken}`;
  }
  return headers;
}
