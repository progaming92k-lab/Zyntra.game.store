import fs from 'node:fs';
import path from 'node:path';
import AdmZip from 'adm-zip';
import { GoogleGenAI, Type } from '@google/genai';
import {
  COVERS_DIR,
  FILES_DIR,
  ICONS_DIR,
  PLAYABLE_DIR,
  SCREENSHOTS_DIR,
  listCategories,
} from './db';
import {
  buildHeuristicAnalysis,
  detectFileFormat,
  extractVersionFromFilename,
  inferPlatformAndPlayability,
  normalizeCategory,
  sanitizeFilename,
} from './game-logic';
import { isPathInside } from './path-utils';
import { generateGameArtAssets } from './cover-generator';
import type { AnalyzedGameDraft, GameLifecycleStatus, GamePlatform } from './types';

export interface ProcessedGameUpload {
  fileSize: number;
  fileFormat: string;
  originalFilename: string;
  storedFilePath: string;
  extractedDir: string | null;
  entryFile: string | null;
  isBrowserPlayable: boolean;
  isDownloadable: boolean;
  platform: GamePlatform;
  coverImage: string;
  iconImage: string;
  screenshots: string[];
  draft: AnalyzedGameDraft;
}

const IMAGE_EXTENSIONS = new Set(['.png', '.jpg', '.jpeg', '.webp', '.svg']);

function extractZipSafely(zip: AdmZip, targetDir: string): string[] {
  fs.mkdirSync(targetDir, { recursive: true });
  const entries = zip.getEntries();
  const extractedNames: string[] = [];

  for (const entry of entries) {
    const entryName = entry.entryName.replace(/\\/g, '/');
    if (!entryName || entryName.startsWith('__MACOSX/')) continue;

    const destPath = path.resolve(targetDir, entryName);
    if (!isPathInside(targetDir, destPath)) {
      throw new Error(`Blocked unsafe archive entry path: ${entryName}`);
    }

    if (entry.isDirectory) {
      fs.mkdirSync(destPath, { recursive: true });
    } else {
      fs.mkdirSync(path.dirname(destPath), { recursive: true });
      fs.writeFileSync(destPath, entry.getData());
      extractedNames.push(entryName);
    }
  }
  return extractedNames;
}

function selectPackageImages(params: {
  gameId: string;
  zip: AdmZip | null;
  entries: string[];
}): {
  coverImage: string | null;
  iconImage: string | null;
  screenshots: string[];
  coverBufferForAi?: { data: string; mimeType: string };
} {
  const { gameId, zip, entries } = params;
  if (!zip) return { coverImage: null, iconImage: null, screenshots: [] };

  const imageEntries = entries.filter((name) => {
    const ext = path.extname(name).toLowerCase();
    return IMAGE_EXTENSIONS.has(ext) && !name.toLowerCase().includes('__macosx');
  });

  if (imageEntries.length === 0) {
    return { coverImage: null, iconImage: null, screenshots: [] };
  }

  let coverEntry: string | null = null;
  let iconEntry: string | null = null;
  const screenshotEntries: string[] = [];

  for (const name of imageEntries) {
    const lower = path.basename(name).toLowerCase();
    const fullLower = name.toLowerCase();
    if (!coverEntry && /(cover|banner|poster|thumb|thumbnail|splash|title)/.test(lower)) {
      coverEntry = name;
    } else if (!iconEntry && /(icon|ic_launcher|logo|favicon|badge)/.test(lower)) {
      iconEntry = name;
    } else if (/(screen|shot|preview|promo|level)/.test(fullLower) || screenshotEntries.length < 4) {
      screenshotEntries.push(name);
    }
  }

  const saveAsset = (
    entryName: string,
    destDir: string,
    prefix: string,
    urlPrefix: string
  ): { url: string; buf: Buffer; mime: string } | null => {
    const zipEntry = zip.getEntry(entryName);
    if (!zipEntry) return null;
    const buf = zipEntry.getData();
    if (buf.length < 128 || buf.length > 10 * 1024 * 1024) return null;
    const ext = path.extname(entryName).toLowerCase() || '.png';
    const outName = `${gameId}-${prefix}${ext}`;
    fs.mkdirSync(destDir, { recursive: true });
    fs.writeFileSync(path.join(destDir, outName), buf);
    const mime =
      ext === '.jpg' || ext === '.jpeg'
        ? 'image/jpeg'
        : ext === '.webp'
          ? 'image/webp'
          : ext === '.svg'
            ? 'image/svg+xml'
            : 'image/png';
    return { url: `${urlPrefix}/${outName}`, buf, mime };
  };

  let coverImage: string | null = null;
  let iconImage: string | null = null;
  let coverBufferForAi: { data: string; mimeType: string } | undefined;
  const screenshots: string[] = [];

  if (coverEntry) {
    const saved = saveAsset(coverEntry, COVERS_DIR, 'cover', '/api/media/covers');
    if (saved) {
      coverImage = saved.url;
      if (saved.mime !== 'image/svg+xml' && saved.buf.length < 2 * 1024 * 1024) {
        coverBufferForAi = { data: saved.buf.toString('base64'), mimeType: saved.mime };
      }
    }
  }

  if (iconEntry) {
    const saved = saveAsset(iconEntry, ICONS_DIR, 'icon', '/api/media/icons');
    if (saved) iconImage = saved.url;
  }

  screenshotEntries.slice(0, 4).forEach((entryName, idx) => {
    const saved = saveAsset(entryName, SCREENSHOTS_DIR, `shot-${idx + 1}`, '/api/media/screenshots');
    if (saved) screenshots.push(saved.url);
  });

  return { coverImage, iconImage, screenshots, coverBufferForAi };
}

async function analyzeWithGemini(params: {
  filename: string;
  fileFormat: string;
  fileSize: number;
  platform: GamePlatform;
  isBrowserPlayable: boolean;
  isDownloadable: boolean;
  entries: string[];
  htmlSnippet: string;
  readmeSnippet: string;
  availableCategories: string[];
  coverBufferForAi?: { data: string; mimeType: string };
}): Promise<Partial<AnalyzedGameDraft> | null> {
  const apiKey = process.env.GEMINI_API_KEY?.trim();
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
    return null;
  }

  try {
    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });

    const promptText = `You are analyzing an uploaded indie game file for Zyntra Game Store.
Inspect the provided file metadata, archive contents, and HTML/README snippets to produce a complete, accurate store listing.
Rules:
- Never invent unverifiable hardware requirements or claim compatibility that contradicts the detected platform (${params.platform}).
- Choose category strictly from: ${params.availableCategories.join(', ')}.
- Keep shortDescription concise (1-2 sentences, max 160 chars).
- Keep fullDescription rich and informative (2-3 short paragraphs).
- Provide realistic defaults for languages, playerMode, internetRequirement, permissions, contentRating, minRequirements, recRequirements, privacyPolicy, termsConditions, copyrightInfo, and gameStatus ('Released', 'Beta', 'Early Access', or 'Alpha').

Uploaded File: ${params.filename}
Format: ${params.fileFormat}
Size Bytes: ${params.fileSize}
Detected Platform: ${params.platform}
Browser Playable: ${params.isBrowserPlayable}
Archive Entries (sample): ${params.entries.slice(0, 40).join(', ')}

HTML Snippet:
${params.htmlSnippet.slice(0, 4500)}

README / Manifest Snippet:
${params.readmeSnippet.slice(0, 2500)}
`;

    const parts: Array<{ text: string } | { inlineData: { mimeType: string; data: string } }> = [
      { text: promptText },
    ];
    if (params.coverBufferForAi) {
      parts.unshift({
        inlineData: {
          mimeType: params.coverBufferForAi.mimeType,
          data: params.coverBufferForAi.data,
        },
      });
    }

    const response = await ai.models.generateContent({
      model: 'gemini-4-hydrogen',
      contents: { parts },
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            shortTitle: { type: Type.STRING },
            shortDescription: { type: Type.STRING },
            fullDescription: { type: Type.STRING },
            category: { type: Type.STRING },
            genre: { type: Type.STRING },
            version: { type: Type.STRING },
            developer: { type: Type.STRING },
            publisher: { type: Type.STRING },
            tags: { type: Type.ARRAY, items: { type: Type.STRING } },
            ageRating: { type: Type.STRING },
            contentRating: { type: Type.STRING },
            languages: { type: Type.STRING },
            playerMode: { type: Type.STRING },
            internetRequirement: { type: Type.STRING },
            controls: { type: Type.STRING },
            instructions: { type: Type.STRING },
            minRequirements: { type: Type.STRING },
            recRequirements: { type: Type.STRING },
            permissions: { type: Type.STRING },
            gameStatus: { type: Type.STRING },
            releaseDate: { type: Type.STRING },
            coverMotif: { type: Type.STRING },
            accentPrimary: { type: Type.STRING },
            accentSecondary: { type: Type.STRING },
            aiSummaryNotes: { type: Type.STRING },
          },
          required: ['title', 'shortDescription', 'fullDescription', 'category', 'genre', 'controls', 'instructions'],
        },
      },
    });

    const text = response.text?.trim();
    if (!text) return null;
    const parsed = JSON.parse(text) as Partial<AnalyzedGameDraft>;
    return parsed;
  } catch (err) {
    console.warn('Gemini analysis unavailable, falling back to automatic local detection:', err instanceof Error ? err.message : err);
    return null;
  }
}

function normalizeGameStatus(val: string | undefined, fallback: GameLifecycleStatus): GameLifecycleStatus {
  if (val === 'Beta' || val === 'Early Access' || val === 'Alpha' || val === 'Released') return val;
  return fallback;
}

export async function processAndAnalyzeUpload(params: {
  gameId: string;
  originalFilename: string;
  buffer: Buffer;
  creatorName?: string;
}): Promise<ProcessedGameUpload> {
  const { gameId, originalFilename, buffer, creatorName } = params;
  const safeName = sanitizeFilename(originalFilename);
  const fileFormat = detectFileFormat(safeName);
  const fileSize = buffer.length;

  // Persist original uploaded archive/file
  const gameFileDir = path.join(FILES_DIR, gameId);
  fs.mkdirSync(gameFileDir, { recursive: true });
  const storedFileRel = path.join(gameId, safeName);
  const storedFileAbs = path.join(FILES_DIR, storedFileRel);
  fs.writeFileSync(storedFileAbs, buffer);

  let entries: string[] = [];
  let htmlSnippet = '';
  let readmeSnippet = '';
  let extractedDir: string | null = null;
  let zipInstance: AdmZip | null = null;

  if (fileFormat === '.html' || fileFormat === '.htm') {
    entries = [safeName];
    const playTarget = path.join(PLAYABLE_DIR, gameId);
    fs.mkdirSync(playTarget, { recursive: true });
    fs.writeFileSync(path.join(playTarget, safeName), buffer);
    extractedDir = gameId;
    htmlSnippet = buffer.toString('utf8', 0, Math.min(buffer.length, 25000));
  } else if (fileFormat === '.zip' || fileFormat === '.apk' || fileFormat === '.aab') {
    try {
      zipInstance = new AdmZip(buffer);
      entries = zipInstance
        .getEntries()
        .filter((e) => !e.isDirectory && !e.entryName.startsWith('__MACOSX/'))
        .map((e) => e.entryName.replace(/\\/g, '/'));
    } catch {
      entries = [];
    }
  }

  const detection = inferPlatformAndPlayability({ fileFormat, entries });

  if (zipInstance && detection.isBrowserPlayable) {
    const playTarget = path.join(PLAYABLE_DIR, gameId);
    extractZipSafely(zipInstance, playTarget);
    extractedDir = gameId;
  }

  if (zipInstance) {
    if (detection.entryFile) {
      const htmlEntry = zipInstance.getEntry(detection.entryFile);
      if (htmlEntry) {
        htmlSnippet = htmlEntry.getData().toString('utf8', 0, 20000);
      }
    }
    const textCandidate = entries.find((e) =>
      /(readme|manifest\.json|package\.json|version\.txt|info\.txt|androidmanifest\.xml)/i.test(e)
    );
    if (textCandidate) {
      const txtEntry = zipInstance.getEntry(textCandidate);
      if (txtEntry) {
        readmeSnippet = txtEntry.getData().toString('utf8', 0, 8000);
      }
    }
    if (htmlSnippet.length < 4000) {
      const jsCandidate = entries.find((e) => /\.js$/i.test(e) && !/min\.js$/i.test(e));
      if (jsCandidate) {
        const jsEntry = zipInstance.getEntry(jsCandidate);
        if (jsEntry) {
          htmlSnippet += '\n' + jsEntry.getData().toString('utf8', 0, 8000);
        }
      }
    }
  }

  const availableCategories = listCategories(false).map((c) => c.name);
  const extractedImages = selectPackageImages({ gameId, zip: zipInstance, entries });

  const heuristic = buildHeuristicAnalysis({
    filename: originalFilename,
    fileFormat,
    platform: detection.platform,
    isBrowserPlayable: detection.isBrowserPlayable,
    isDownloadable: detection.isDownloadable,
    htmlSnippet,
    readmeSnippet,
    entries,
    creatorName,
  });

  const aiResult = await analyzeWithGemini({
    filename: originalFilename,
    fileFormat,
    fileSize,
    platform: detection.platform,
    isBrowserPlayable: detection.isBrowserPlayable,
    isDownloadable: detection.isDownloadable,
    entries,
    htmlSnippet,
    readmeSnippet,
    availableCategories,
    coverBufferForAi: extractedImages.coverBufferForAi,
  });

  const today = new Date().toISOString().slice(0, 10);
  const mergedCategory = normalizeCategory(aiResult?.category || heuristic.category, availableCategories);
  const mergedTitle = (aiResult?.title || heuristic.title).trim().slice(0, 80);
  const mergedShortTitle = (
    aiResult?.shortTitle || (mergedTitle.length > 26 ? mergedTitle.slice(0, 23).trim() + '...' : mergedTitle)
  ).trim();
  const mergedVersion = (aiResult?.version || extractVersionFromFilename(originalFilename) || heuristic.version).trim();
  const mergedDeveloper = (
    creatorName && creatorName !== 'Creator Access'
      ? creatorName
      : aiResult?.developer || heuristic.developer
  ).trim();

  const generatedArt = generateGameArtAssets({
    gameId,
    title: mergedTitle,
    category: mergedCategory,
    platform: detection.platform,
    motif: aiResult?.coverMotif || heuristic.coverMotif,
    accentPrimary: aiResult?.accentPrimary || heuristic.accentPrimary,
    accentSecondary: aiResult?.accentSecondary || heuristic.accentSecondary,
  });

  const finalCover = extractedImages.coverImage || generatedArt.coverUrl;
  const finalIcon = extractedImages.iconImage || generatedArt.iconUrl;

  const draft: AnalyzedGameDraft = {
    title: mergedTitle,
    shortTitle: mergedShortTitle,
    shortDescription: (aiResult?.shortDescription || heuristic.shortDescription).trim().slice(0, 200),
    fullDescription: (aiResult?.fullDescription || heuristic.fullDescription).trim(),
    category: mergedCategory,
    genre: (aiResult?.genre || heuristic.genre).trim(),
    platform: detection.platform,
    version: mergedVersion,
    developer: mergedDeveloper,
    publisher: (aiResult?.publisher || heuristic.publisher).trim(),
    tags: Array.isArray(aiResult?.tags) && aiResult.tags.length > 0 ? aiResult.tags.slice(0, 6) : heuristic.tags,
    ageRating: (aiResult?.ageRating || heuristic.ageRating).trim(),
    contentRating: (aiResult?.contentRating || heuristic.contentRating).trim(),
    languages: (aiResult?.languages || heuristic.languages).trim(),
    playerMode: (aiResult?.playerMode || heuristic.playerMode).trim(),
    internetRequirement: (aiResult?.internetRequirement || heuristic.internetRequirement).trim(),
    controls: (aiResult?.controls || heuristic.controls).trim(),
    instructions: (aiResult?.instructions || heuristic.instructions).trim(),
    minRequirements: (aiResult?.minRequirements || heuristic.minRequirements).trim(),
    recRequirements: (aiResult?.recRequirements || heuristic.recRequirements).trim(),
    privacyPolicy: heuristic.privacyPolicy,
    termsConditions: heuristic.termsConditions,
    copyrightInfo: heuristic.copyrightInfo,
    permissions: (aiResult?.permissions || heuristic.permissions).trim(),
    releaseDate:
      aiResult?.releaseDate && /^\d{4}-\d{2}-\d{2}/.test(aiResult.releaseDate)
        ? aiResult.releaseDate.slice(0, 10)
        : today,
    gameStatus: normalizeGameStatus(aiResult?.gameStatus, heuristic.gameStatus),
    isBrowserPlayable: detection.isBrowserPlayable,
    isDownloadable: detection.isDownloadable,
    coverMotif: aiResult?.coverMotif || heuristic.coverMotif,
    accentPrimary: aiResult?.accentPrimary || heuristic.accentPrimary,
    accentSecondary: aiResult?.accentSecondary || heuristic.accentSecondary,
    aiSummaryNotes:
      aiResult?.aiSummaryNotes ||
      (aiResult
        ? 'Analyzed automatically via Gemini AI file inspection.'
        : 'Analyzed automatically via Zyntra built-in file inspector.'),
  };

  return {
    fileSize,
    fileFormat,
    originalFilename,
    storedFilePath: storedFileRel,
    extractedDir,
    entryFile: detection.entryFile,
    isBrowserPlayable: detection.isBrowserPlayable,
    isDownloadable: detection.isDownloadable,
    platform: detection.platform,
    coverImage: finalCover,
    iconImage: finalIcon,
    screenshots: extractedImages.screenshots,
    draft,
  };
}
