import fs from 'node:fs';
import path from 'node:path';
import { COVERS_DIR, ICONS_DIR } from './db';

function escapeXml(str: string): string {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

function getMotifGraphic(motif: string, primary: string, secondary: string): string {
  const lower = motif.toLowerCase();
  if (lower.includes('rac')) {
    return `
      <g opacity="0.9">
        <path d="M120 560 L480 280 L720 280 L1080 560" fill="none" stroke="${secondary}" stroke-width="4" opacity="0.5"/>
        <path d="M240 560 L530 280 M960 560 L670 280" stroke="${primary}" stroke-width="3" stroke-dasharray="18 14" opacity="0.65"/>
        <polygon points="600,220 710,380 490,380" fill="none" stroke="${secondary}" stroke-width="3" opacity="0.7"/>
        <circle cx="600" cy="240" r="88" fill="none" stroke="${primary}" stroke-width="2" opacity="0.35"/>
        <path d="M80 440 L340 440 M860 440 L1120 440" stroke="${secondary}" stroke-width="3" opacity="0.45"/>
      </g>`;
  }
  if (lower.includes('hor')) {
    return `
      <g opacity="0.9">
        <circle cx="880" cy="190" r="95" fill="${primary}" opacity="0.18"/>
        <circle cx="880" cy="190" r="65" fill="none" stroke="${secondary}" stroke-width="2" opacity="0.65"/>
        <path d="M180 540 L260 320 L330 410 L420 230 L520 430 L640 270 L760 540 Z" fill="#0B0B12" stroke="${primary}" stroke-width="2.5" opacity="0.85"/>
        <path d="M0 540 Q320 480 620 530 T1200 500" fill="none" stroke="${secondary}" stroke-width="2" opacity="0.45"/>
      </g>`;
  }
  if (lower.includes('shoot') || lower.includes('act')) {
    return `
      <g opacity="0.9">
        <circle cx="840" cy="310" r="145" fill="none" stroke="${secondary}" stroke-width="2" stroke-dasharray="14 10" opacity="0.55"/>
        <circle cx="840" cy="310" r="95" fill="none" stroke="${primary}" stroke-width="3" opacity="0.7"/>
        <line x1="650" y1="310" x2="1030" y2="310" stroke="${secondary}" stroke-width="2" opacity="0.45"/>
        <line x1="840" y1="120" x2="840" y2="500" stroke="${secondary}" stroke-width="2" opacity="0.45"/>
        <polygon points="840,245 895,310 840,375 785,310" fill="${primary}" opacity="0.22" stroke="${secondary}" stroke-width="2"/>
      </g>`;
  }
  if (lower.includes('cart')) {
    return `
      <g opacity="0.92">
        <circle cx="850" cy="270" r="130" fill="${primary}" opacity="0.2"/>
        <circle cx="910" cy="230" r="80" fill="${secondary}" opacity="0.22"/>
        <rect x="740" y="210" width="210" height="210" rx="52" transform="rotate(14 845 315)" fill="none" stroke="${secondary}" stroke-width="4" opacity="0.75"/>
        <circle cx="805" cy="285" r="14" fill="#FFFFFF" opacity="0.9"/>
        <circle cx="885" cy="285" r="14" fill="#FFFFFF" opacity="0.9"/>
        <path d="M800 345 Q845 385 890 345" fill="none" stroke="#FFFFFF" stroke-width="6" stroke-linecap="round" opacity="0.9"/>
      </g>`;
  }
  if (lower.includes('puz') || lower.includes('3d')) {
    return `
      <g opacity="0.9">
        <polygon points="840,140 990,225 990,395 840,480 690,395 690,225" fill="${primary}" opacity="0.16" stroke="${secondary}" stroke-width="3"/>
        <polyline points="690,225 840,310 990,225" fill="none" stroke="${secondary}" stroke-width="2.5"/>
        <line x1="840" y1="310" x2="840" y2="480" stroke="${primary}" stroke-width="2.5"/>
        <polygon points="840,205 920,250 840,295 760,250" fill="${secondary}" opacity="0.25"/>
      </g>`;
  }
  return `
    <g opacity="0.9">
      <rect x="690" y="160" width="300" height="300" rx="44" transform="rotate(-8 840 310)" fill="${primary}" opacity="0.15" stroke="${primary}" stroke-width="3"/>
      <rect x="740" y="210" width="200" height="200" rx="28" transform="rotate(10 840 310)" fill="none" stroke="${secondary}" stroke-width="3"/>
      <polygon points="840,240 905,355 775,355" fill="${secondary}" opacity="0.3" stroke="#FFFFFF" stroke-width="2"/>
    </g>`;
}

export function generateGameArtAssets(params: {
  gameId: string;
  title: string;
  category: string;
  platform: string;
  motif: string;
  accentPrimary?: string;
  accentSecondary?: string;
}): { coverUrl: string; iconUrl: string } {
  const primary = /^#[0-9a-fA-F]{6}$/.test(params.accentPrimary || '') ? params.accentPrimary! : '#8B5CF6';
  const secondary = /^#[0-9a-fA-F]{6}$/.test(params.accentSecondary || '') ? params.accentSecondary! : '#38BDF8';
  const safeTitle = escapeXml(params.title.slice(0, 34));
  const safeCategory = escapeXml(params.category.toUpperCase());
  const safePlatform = escapeXml(params.platform.toUpperCase());
  const motifGraphic = getMotifGraphic(params.motif || params.category, primary, secondary);

  const initials = params.title
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((w) => w[0]?.toUpperCase() || '')
    .join('') || 'ZG';

  const coverSvg = `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 675" width="1200" height="675">
  <defs>
    <linearGradient id="bgGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#07070B"/>
      <stop offset="55%" stop-color="#11121B"/>
      <stop offset="100%" stop-color="#0A0B12"/>
    </linearGradient>
    <radialGradient id="glow1" cx="76%" cy="42%" r="45%">
      <stop offset="0%" stop-color="${primary}" stop-opacity="0.34"/>
      <stop offset="100%" stop-color="${primary}" stop-opacity="0"/>
    </radialGradient>
    <radialGradient id="glow2" cx="25%" cy="80%" r="48%">
      <stop offset="0%" stop-color="${secondary}" stop-opacity="0.24"/>
      <stop offset="100%" stop-color="${secondary}" stop-opacity="0"/>
    </radialGradient>
    <pattern id="grid" width="48" height="48" patternUnits="userSpaceOnUse">
      <path d="M 48 0 L 0 0 0 48" fill="none" stroke="#FFFFFF" stroke-opacity="0.04" stroke-width="1"/>
    </pattern>
  </defs>
  <rect width="1200" height="675" fill="url(#bgGrad)"/>
  <rect width="1200" height="675" fill="url(#grid)"/>
  <rect width="1200" height="675" fill="url(#glow1)"/>
  <rect width="1200" height="675" fill="url(#glow2)"/>
  ${motifGraphic}
  <rect x="64" y="64" width="1072" height="547" rx="20" fill="none" stroke="#FFFFFF" stroke-opacity="0.08" stroke-width="1.5"/>
  <text x="96" y="138" fill="${secondary}" font-family="system-ui, -apple-system, sans-serif" font-size="18" font-weight="700" letter-spacing="4">${safeCategory} · ${safePlatform}</text>
  <text x="96" y="340" fill="#F8FAFC" font-family="system-ui, -apple-system, sans-serif" font-size="56" font-weight="800" letter-spacing="-1">${safeTitle}</text>
  <line x1="96" y1="382" x2="240" y2="382" stroke="${primary}" stroke-width="4" stroke-linecap="round"/>
  <text x="96" y="555" fill="#94A3B8" font-family="system-ui, -apple-system, sans-serif" font-size="20" font-weight="600" letter-spacing="2">ZYNTRA GAME STORE EDITION</text>
</svg>`;

  const iconSvg = `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="512" height="512">
  <defs>
    <linearGradient id="iconBg" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#0E0F17"/>
      <stop offset="100%" stop-color="#191B29"/>
    </linearGradient>
    <linearGradient id="accentStroke" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="${primary}"/>
      <stop offset="100%" stop-color="${secondary}"/>
    </linearGradient>
  </defs>
  <rect width="512" height="512" rx="112" fill="url(#iconBg)"/>
  <rect x="20" y="20" width="472" height="472" rx="96" fill="none" stroke="url(#accentStroke)" stroke-width="8" opacity="0.8"/>
  <circle cx="256" cy="256" r="156" fill="${primary}" opacity="0.14"/>
  <text x="256" y="292" text-anchor="middle" fill="#F8FAFC" font-family="system-ui, -apple-system, sans-serif" font-size="148" font-weight="800" letter-spacing="-4">${escapeXml(initials)}</text>
</svg>`;

  const coverFilename = `${params.gameId}-cover.svg`;
  const iconFilename = `${params.gameId}-icon.svg`;

  fs.mkdirSync(COVERS_DIR, { recursive: true });
  fs.mkdirSync(ICONS_DIR, { recursive: true });

  fs.writeFileSync(path.join(COVERS_DIR, coverFilename), coverSvg, 'utf8');
  fs.writeFileSync(path.join(ICONS_DIR, iconFilename), iconSvg, 'utf8');

  return {
    coverUrl: `/api/media/covers/${coverFilename}`,
    iconUrl: `/api/media/icons/${iconFilename}`,
  };
}
