export type GameStatus = 'published' | 'draft' | 'scheduled' | 'unpublished';

export type GameLifecycleStatus = 'Released' | 'Beta' | 'Early Access' | 'Alpha';

export type GameVisibility = 'public' | 'private';

export type PricingType = 'free' | 'paid';

export type GamePlatform =
  | 'HTML5'
  | 'Web'
  | 'Android'
  | 'Windows'
  | 'iOS'
  | 'PC'
  | 'Mac'
  | 'Linux'
  | 'Unity WebGL'
  | 'Cross-Platform'
  | 'Other';

export interface GameRecord {
  id: string;
  slug: string;
  title: string;
  shortTitle: string;
  shortDescription: string;
  fullDescription: string;
  category: string;
  genre: string;
  platform: GamePlatform;
  version: string;
  developer: string;
  publisher: string;
  creatorUsername: string;
  fileSize: number;
  fileFormat: string;
  originalFilename: string;
  storedFilePath: string;
  extractedDir: string | null;
  entryFile: string | null;
  isBrowserPlayable: boolean;
  isDownloadable: boolean;
  coverImage: string;
  iconImage: string;
  screenshots: string[];
  tags: string[];
  ageRating: string;
  contentRating: string;
  languages: string;
  playerMode: string;
  internetRequirement: string;
  controls: string;
  instructions: string;
  minRequirements: string;
  recRequirements: string;
  privacyPolicy: string;
  termsConditions: string;
  copyrightInfo: string;
  permissions: string;
  releaseDate: string;
  uploadDate: string;
  updatedAt: string;
  scheduledReleaseAt: string | null;
  gameStatus: GameLifecycleStatus;
  status: GameStatus;
  visibility: GameVisibility;
  featured: boolean;
  trending: boolean;
  pricingType: PricingType;
  priceLabel: string;
  collectionName: string;
  downloadCount: number;
  playCount: number;
  viewCount: number;
  likeCount: number;
  aiSummaryNotes: string;
}

export interface CategoryRecord {
  id: string;
  name: string;
  slug: string;
  description: string;
  sortOrder: number;
  gameCount?: number;
}

export interface StoreStats {
  totalUploads: number;
  totalPublished: number;
  totalDrafts: number;
  totalDownloads: number;
  totalPlays: number;
  totalViews: number;
  totalLikes: number;
  storageUsedBytes: number;
}

export interface CreatorAccount {
  id: string;
  username: string;
  displayName: string;
  bio: string;
  createdAt: string;
}

export interface GameReview {
  id: string;
  gameId: string;
  authorName: string;
  rating: number;
  comment: string;
  createdAt: string;
}

export interface GameReport {
  id: string;
  gameId: string;
  gameTitle?: string;
  reason: string;
  details: string;
  createdAt: string;
}

export interface AnalyzedGameDraft {
  title: string;
  shortTitle: string;
  shortDescription: string;
  fullDescription: string;
  category: string;
  genre: string;
  platform: GamePlatform;
  version: string;
  developer: string;
  publisher: string;
  tags: string[];
  ageRating: string;
  contentRating: string;
  languages: string;
  playerMode: string;
  internetRequirement: string;
  controls: string;
  instructions: string;
  minRequirements: string;
  recRequirements: string;
  privacyPolicy: string;
  termsConditions: string;
  copyrightInfo: string;
  permissions: string;
  releaseDate: string;
  gameStatus: GameLifecycleStatus;
  isBrowserPlayable: boolean;
  isDownloadable: boolean;
  coverMotif: string;
  accentPrimary: string;
  accentSecondary: string;
  aiSummaryNotes: string;
}
