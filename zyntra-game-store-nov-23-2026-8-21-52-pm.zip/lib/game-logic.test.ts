import test from 'node:test';
import assert from 'node:assert/strict';
import path from 'node:path';
import {
  slugify,
  sanitizeUsername,
  ensureUniqueSlug,
  formatBytes,
  cleanTitleFromFilename,
  extractVersionFromFilename,
  normalizeCategory,
  inferPlatformAndPlayability,
  buildHeuristicAnalysis,
  filterAndSortGames,
  isGamePubliclyVisible,
} from './game-logic';
import { isPathInside } from './path-utils';
import type { GameRecord } from './types';

function makeBaseGame(overrides: Partial<GameRecord> = {}): GameRecord {
  return {
    id: '1',
    slug: 'cartoon-hop',
    title: 'Cartoon Hop',
    shortTitle: 'Cartoon Hop',
    shortDescription: 'Jump across clouds',
    fullDescription: 'Full description',
    category: 'Cartoon',
    genre: 'Platformer',
    platform: 'HTML5',
    version: '1.0.0',
    developer: 'JSR Studio',
    publisher: 'Zyntra Indie Publishing',
    creatorUsername: 'jsr_studio',
    fileSize: 1024,
    fileFormat: '.zip',
    originalFilename: 'cartoon-hop.zip',
    storedFilePath: '1/cartoon-hop.zip',
    extractedDir: '1',
    entryFile: 'index.html',
    isBrowserPlayable: true,
    isDownloadable: true,
    coverImage: '/c1.svg',
    iconImage: '/i1.svg',
    screenshots: [],
    tags: ['Cartoon', 'Platformer'],
    ageRating: 'Everyone',
    contentRating: 'Family Friendly',
    languages: 'English',
    playerMode: 'Single Player',
    internetRequirement: 'Offline Supported',
    controls: 'WASD',
    instructions: 'Play',
    minRequirements: 'Browser',
    recRequirements: 'Chrome',
    privacyPolicy: 'Standard',
    termsConditions: 'Standard',
    copyrightInfo: 'Copyright 2026',
    permissions: 'Audio Playback',
    releaseDate: '2026-01-01',
    uploadDate: '2026-01-02T00:00:00Z',
    updatedAt: '2026-01-02T00:00:00Z',
    scheduledReleaseAt: null,
    gameStatus: 'Released',
    status: 'published',
    visibility: 'public',
    featured: true,
    trending: false,
    pricingType: 'free',
    priceLabel: 'Free',
    collectionName: 'Creator Picks',
    downloadCount: 15,
    playCount: 40,
    viewCount: 120,
    likeCount: 18,
    aiSummaryNotes: '',
    ...overrides,
  };
}

test('slugify, sanitizeUsername, and ensureUniqueSlug work cleanly', () => {
  assert.equal(slugify('Cartoon Adventure: Turbo!'), 'cartoon-adventure-turbo');
  assert.equal(slugify('   '), 'untitled-game');
  const used = new Set(['neon-drift', 'neon-drift-2']);
  assert.equal(ensureUniqueSlug('Neon Drift', used), 'neon-drift-3');
  assert.equal(sanitizeUsername('JSR_Creator01'), 'jsr_creator01');
  assert.equal(sanitizeUsername('ab'), '');
  assert.equal(sanitizeUsername('bad user!'), '');
});

test('formatBytes formats byte sizes cleanly', () => {
  assert.equal(formatBytes(0), '0 B');
  assert.equal(formatBytes(512), '512 B');
  assert.equal(formatBytes(1536), '1.5 KB');
  assert.equal(formatBytes(12 * 1024 * 1024), '12 MB');
});

test('isPathInside prevents zip-slip directory traversal', () => {
  const base = path.resolve('/tmp/zyntra-playable/game1');
  assert.equal(isPathInside(base, path.join(base, 'index.html')), true);
  assert.equal(isPathInside(base, path.join(base, 'assets/sprite.png')), true);
  assert.equal(isPathInside(base, path.join(base, '../secret.txt')), false);
  assert.equal(isPathInside(base, '/etc/passwd'), false);
});

test('cleanTitleFromFilename and extractVersionFromFilename parse releases accurately', () => {
  assert.equal(cleanTitleFromFilename('cyber_drift_racing_v2.1.0.zip'), 'Cyber Drift Racing');
  assert.equal(extractVersionFromFilename('cyber_drift_racing_v2.1.0.zip'), '2.1.0');
  assert.equal(extractVersionFromFilename('puzzle_box.html'), '1.0.0');
});

test('inferPlatformAndPlayability detects HTML5 ZIP, Unity WebGL, APK, Windows, and iOS builds', () => {
  const htmlZip = inferPlatformAndPlayability({
    fileFormat: '.zip',
    entries: ['dist/index.html', 'dist/main.js', 'dist/assets/hero.png'],
  });
  assert.equal(htmlZip.platform, 'HTML5');
  assert.equal(htmlZip.isBrowserPlayable, true);
  assert.equal(htmlZip.entryFile, 'dist/index.html');

  const unityZip = inferPlatformAndPlayability({
    fileFormat: '.zip',
    entries: ['index.html', 'Build/game.framework.js', 'Build/game.wasm'],
  });
  assert.equal(unityZip.platform, 'Unity WebGL');
  assert.equal(unityZip.isBrowserPlayable, true);

  const apk = inferPlatformAndPlayability({
    fileFormat: '.apk',
    entries: ['AndroidManifest.xml'],
  });
  assert.equal(apk.platform, 'Android');
  assert.equal(apk.isBrowserPlayable, false);
  assert.equal(apk.isDownloadable, true);

  const win = inferPlatformAndPlayability({
    fileFormat: '.exe',
    entries: [],
  });
  assert.equal(win.platform, 'Windows');
  assert.equal(win.isBrowserPlayable, false);

  const ios = inferPlatformAndPlayability({
    fileFormat: '.ipa',
    entries: [],
  });
  assert.equal(ios.platform, 'iOS');
  assert.equal(ios.isBrowserPlayable, false);
});

test('normalizeCategory maps synonyms to standard Zyntra categories', () => {
  assert.equal(normalizeCategory('Racing'), 'Racing');
  assert.equal(normalizeCategory('FPS Shooter'), 'Shooting');
  assert.equal(normalizeCategory('UnknownGenre'), 'Other');
});

test('buildHeuristicAnalysis extracts controls, permissions, genre, and legal defaults', () => {
  const res = buildHeuristicAnalysis({
    filename: 'spooky_crypt_beta_v1.2.zip',
    fileFormat: '.zip',
    platform: 'HTML5',
    isBrowserPlayable: true,
    isDownloadable: true,
    htmlSnippet: '<title>Spooky Crypt Survival</title><script>localStorage.setItem("k","1");window.addEventListener("keydown", e => { if (e.code === "Space") jump(); });</script>',
    readmeSnippet: '',
    entries: ['index.html', 'game.js'],
    creatorName: 'ghostdev',
  });
  assert.equal(res.title, 'Spooky Crypt Survival');
  assert.equal(res.category, 'Horror');
  assert.equal(res.version, '1.2');
  assert.equal(res.developer, 'ghostdev');
  assert.equal(res.gameStatus, 'Beta');
  assert.match(res.controls, /Spacebar/i);
  assert.match(res.permissions, /Local Save Storage/i);
  assert.ok(res.privacyPolicy.length > 10);
  assert.ok(res.copyrightInfo.includes('ghostdev'));
});

test('isGamePubliclyVisible respects visibility and scheduled release times', () => {
  const now = Date.parse('2026-06-01T12:00:00Z');
  assert.equal(isGamePubliclyVisible(makeBaseGame({ status: 'published', visibility: 'public' }), now), true);
  assert.equal(isGamePubliclyVisible(makeBaseGame({ status: 'published', visibility: 'private' }), now), false);
  assert.equal(isGamePubliclyVisible(makeBaseGame({ status: 'unpublished', visibility: 'public' }), now), false);
  assert.equal(
    isGamePubliclyVisible(
      makeBaseGame({ status: 'scheduled', visibility: 'public', scheduledReleaseAt: '2026-06-01T10:00:00Z' }),
      now
    ),
    true
  );
  assert.equal(
    isGamePubliclyVisible(
      makeBaseGame({ status: 'scheduled', visibility: 'public', scheduledReleaseAt: '2026-06-02T10:00:00Z' }),
      now
    ),
    false
  );
});

test('filterAndSortGames filters by query, category, platform, status, and publicOnly', () => {
  const sample: GameRecord[] = [
    makeBaseGame(),
    makeBaseGame({
      id: '2',
      slug: 'drift-x',
      title: 'Drift X',
      shortTitle: 'Drift X',
      shortDescription: 'Street racing',
      category: 'Racing',
      genre: 'Racing',
      platform: 'Android',
      version: '2.0.0',
      developer: 'Team JSR',
      fileSize: 2048,
      fileFormat: '.apk',
      originalFilename: 'drift-x.apk',
      storedFilePath: '2/drift-x.apk',
      extractedDir: null,
      entryFile: null,
      isBrowserPlayable: false,
      uploadDate: '2026-01-06T00:00:00Z',
      updatedAt: '2026-01-06T00:00:00Z',
      status: 'draft',
      featured: false,
      downloadCount: 2,
      playCount: 0,
      likeCount: 0,
    }),
    makeBaseGame({
      id: '3',
      slug: 'hidden-gem',
      title: 'Hidden Gem',
      status: 'published',
      visibility: 'private',
    }),
  ];

  assert.equal(filterAndSortGames(sample, { publicOnly: true }).length, 1);
  assert.equal(filterAndSortGames(sample, { status: 'all', query: 'team jsr' })[0].slug, 'drift-x');
  assert.equal(filterAndSortGames(sample, { status: 'all', category: 'Cartoon' }).length, 2);
  assert.equal(filterAndSortGames(sample, { status: 'all', sort: 'popular' })[0].slug, 'cartoon-hop');
});
