import type { GameLifecycleStatus, GamePlatform, GameRecord } from './types';

export const DEFAULT_CATEGORIES = [
  { name: 'Cartoon', slug: 'cartoon', description: 'Stylized, hand-drawn, and animated character adventures.' },
  { name: 'Action', slug: 'action', description: 'Fast-paced combat, reflexes, and high-energy encounters.' },
  { name: 'Adventure', slug: 'adventure', description: 'Exploration, story-driven quests, and world discovery.' },
  { name: 'Racing', slug: 'racing', description: 'High-speed tracks, time trials, and vehicle physics.' },
  { name: 'Arcade', slug: 'arcade', description: 'Score-chasing classics, retro loops, and instant pick-up play.' },
  { name: 'Horror', slug: 'horror', description: 'Atmospheric suspense, survival tension, and dark mysteries.' },
  { name: 'Puzzle', slug: 'puzzle', description: 'Logic challenges, spatial reasoning, and clever mechanics.' },
  { name: 'Casual', slug: 'casual', description: 'Relaxed, accessible sessions designed for any pace.' },
  { name: 'Shooting', slug: 'shooting', description: 'Precision aim, bullet-hell arenas, and tactical firefights.' },
  { name: 'Simulation', slug: 'simulation', description: 'Systems modeling, builders, sandboxes, and management.' },
  { name: 'Platformer', slug: 'platformer', description: 'Precision jumping, traversal hazards, and level mastery.' },
  { name: '2D', slug: '2d', description: 'Crisp sprite art, side-scrollers, and top-down experiences.' },
  { name: '3D', slug: '3d', description: 'Polygonal worlds, depth-rich arenas, and spatial cameras.' },
  { name: 'Other', slug: 'other', description: 'Experimental builds, prototypes, and genre-bending releases.' },
] as const;

export function slugify(input: string): string {
  const cleaned = input
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
  return cleaned || 'untitled-game';
}

export function sanitizeUsername(input: string): string {
  const cleaned = input.trim().replace(/\s+/g, '');
  if (!/^[a-zA-Z0-9_.-]{3,32}$/.test(cleaned)) {
    return '';
  }
  return cleaned.toLowerCase();
}

export function ensureUniqueSlug(baseTitle: string, existingSlugs: Set<string>): string {
  const base = slugify(baseTitle);
  if (!existingSlugs.has(base)) return base;
  let counter = 2;
  while (existingSlugs.has(`${base}-${counter}`)) {
    counter += 1;
  }
  return `${base}-${counter}`;
}

export function formatBytes(bytes: number): string {
  if (!Number.isFinite(bytes) || bytes <= 0) return '0 B';
  const units = ['B', 'KB', 'MB', 'GB', 'TB'];
  const idx = Math.min(Math.floor(Math.log(bytes) / Math.log(1024)), units.length - 1);
  const value = bytes / Math.pow(1024, idx);
  return `${value >= 10 || idx === 0 ? value.toFixed(0) : value.toFixed(1)} ${units[idx]}`;
}

export function sanitizeFilename(filename: string): string {
  const base = filename.split(/[/\\]/).pop() || '';
  const cleaned = base.replace(/[^a-zA-Z0-9._-]/g, '_');
  return cleaned || 'game-package.bin';
}

export function detectFileFormat(filename: string): string {
  const lower = filename.toLowerCase();
  if (lower.endsWith('.tar.gz')) return '.tar.gz';
  const base = lower.split(/[/\\]/).pop() || '';
  const dotIdx = base.lastIndexOf('.');
  return dotIdx > 0 ? base.slice(dotIdx) : '.bin';
}

export function cleanTitleFromFilename(filename: string): string {
  const baseOnly = filename.split(/[/\\]/).pop() || filename;
  const base = baseOnly.replace(/\.(tar\.gz|zip|html|htm|apk|aab|exe|msi|dmg|appimage|ipa|rar|7z|unitypackage)$/i, '');
  const withoutVersion = base.replace(/[-_.\s]+v?\d+(\.\d+){0,3}([-_.]?(alpha|beta|rc\d*|build\d*|final|release))?$/i, '');
  const spaced = withoutVersion
    .replace(/([a-z])([A-Z])/g, '$1 $2')
    .replace(/[-_]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
  if (!spaced) return 'Untitled Zyntra Release';
  return spaced
    .split(' ')
    .map((word) => (word.length > 0 ? word[0].toUpperCase() + word.slice(1) : ''))
    .join(' ');
}

export function extractVersionFromFilename(filename: string): string {
  const match = filename.match(/(?:^|[-_.\s])v?(\d+\.\d+(?:\.\d+)?)/i);
  if (match && match[1]) return match[1];
  return '1.0.0';
}

export function normalizeCategory(input: string | undefined, availableCategories: string[] = DEFAULT_CATEGORIES.map((c) => c.name)): string {
  if (!input) return 'Other';
  const lower = input.trim().toLowerCase();
  const direct = availableCategories.find((c) => c.toLowerCase() === lower);
  if (direct) return direct;

  const synonymMap: Record<string, string> = {
    shooter: 'Shooting',
    fps: 'Shooting',
    tps: 'Shooting',
    platform: 'Platformer',
    jump: 'Platformer',
    race: 'Racing',
    driving: 'Racing',
    drift: 'Racing',
    car: 'Racing',
    scary: 'Horror',
    spooky: 'Horror',
    survival: 'Horror',
    toon: 'Cartoon',
    anime: 'Cartoon',
    comic: 'Cartoon',
    logic: 'Puzzle',
    brain: 'Puzzle',
    match: 'Puzzle',
    sim: 'Simulation',
    sandbox: 'Simulation',
    retro: 'Arcade',
    pixel: '2D',
    webgl: '3D',
  };

  for (const [key, mapped] of Object.entries(synonymMap)) {
    if (lower.includes(key) && availableCategories.includes(mapped)) {
      return mapped;
    }
  }
  return availableCategories.includes('Other') ? 'Other' : availableCategories[0] || 'Other';
}

export function inferPlatformAndPlayability(params: {
  fileFormat: string;
  entries: string[];
}): {
  platform: GamePlatform;
  isBrowserPlayable: boolean;
  isDownloadable: boolean;
  entryFile: string | null;
} {
  const { fileFormat, entries } = params;
  const lowerEntries = entries.map((e) => e.toLowerCase());

  if (fileFormat === '.html' || fileFormat === '.htm') {
    return {
      platform: 'HTML5',
      isBrowserPlayable: true,
      isDownloadable: true,
      entryFile: entries[0] || 'index.html',
    };
  }

  if (fileFormat === '.apk' || fileFormat === '.aab') {
    return {
      platform: 'Android',
      isBrowserPlayable: false,
      isDownloadable: true,
      entryFile: null,
    };
  }

  if (fileFormat === '.ipa') {
    return {
      platform: 'iOS',
      isBrowserPlayable: false,
      isDownloadable: true,
      entryFile: null,
    };
  }

  if (fileFormat === '.exe' || fileFormat === '.msi') {
    return {
      platform: 'Windows',
      isBrowserPlayable: false,
      isDownloadable: true,
      entryFile: null,
    };
  }

  if (fileFormat === '.dmg') {
    return {
      platform: 'Mac',
      isBrowserPlayable: false,
      isDownloadable: true,
      entryFile: null,
    };
  }

  if (['.appimage', '.deb'].includes(fileFormat)) {
    return {
      platform: 'Linux',
      isBrowserPlayable: false,
      isDownloadable: true,
      entryFile: null,
    };
  }

  if (fileFormat === '.zip') {
    const htmlCandidates = entries
      .filter((entry) => {
        const norm = entry.replace(/\\/g, '/').toLowerCase();
        return !norm.startsWith('__macosx/') && (norm === 'index.html' || norm.endsWith('/index.html'));
      })
      .sort((a, b) => a.split('/').length - b.split('/').length);

    if (htmlCandidates.length > 0) {
      const hasUnityWebGL = lowerEntries.some(
        (e) => e.includes('unityprogress') || e.endsWith('.framework.js') || e.endsWith('.framework.js.gz') || e.endsWith('.wasm')
      );
      return {
        platform: hasUnityWebGL ? 'Unity WebGL' : 'HTML5',
        isBrowserPlayable: true,
        isDownloadable: true,
        entryFile: htmlCandidates[0].replace(/\\/g, '/'),
      };
    }

    const anyRootHtml = entries.find((e) => !e.includes('/') && /\.html?$/i.test(e));
    if (anyRootHtml) {
      return {
        platform: 'HTML5',
        isBrowserPlayable: true,
        isDownloadable: true,
        entryFile: anyRootHtml,
      };
    }

    if (lowerEntries.some((e) => e.endsWith('.apk') || e.endsWith('.aab'))) {
      return { platform: 'Android', isBrowserPlayable: false, isDownloadable: true, entryFile: null };
    }

    if (lowerEntries.some((e) => e.endsWith('.exe') || e.endsWith('.msi'))) {
      return { platform: 'Windows', isBrowserPlayable: false, isDownloadable: true, entryFile: null };
    }

    if (lowerEntries.some((e) => e.endsWith('.x86_64') || e.endsWith('.app/'))) {
      return { platform: 'PC', isBrowserPlayable: false, isDownloadable: true, entryFile: null };
    }
  }

  return {
    platform: 'Other',
    isBrowserPlayable: false,
    isDownloadable: true,
    entryFile: null,
  };
}

export function buildHeuristicAnalysis(params: {
  filename: string;
  fileFormat: string;
  platform: GamePlatform;
  isBrowserPlayable: boolean;
  isDownloadable: boolean;
  htmlSnippet: string;
  readmeSnippet: string;
  entries: string[];
  creatorName?: string;
}): {
  title: string;
  shortTitle: string;
  shortDescription: string;
  fullDescription: string;
  category: string;
  genre: string;
  version: string;
  developer: string;
  publisher: string;
  tags: string[];
  ageRating: string;
  contentRating: string;
  languages: string;
  playerMode: string;
  internetRequirement: string;
  controls: string;
  instructions: string;
  minRequirements: string;
  recRequirements: string;
  privacyPolicy: string;
  termsConditions: string;
  copyrightInfo: string;
  permissions: string;
  gameStatus: GameLifecycleStatus;
  coverMotif: string;
  accentPrimary: string;
  accentSecondary: string;
} {
  const { filename, platform, isBrowserPlayable, htmlSnippet, readmeSnippet, entries, creatorName } = params;
  const titleMatch = htmlSnippet.match(/<title[^>]*>([^<]{2,80})<\/title>/i);
  const rawTitle = titleMatch?.[1]?.trim() || cleanTitleFromFilename(filename);
  const title = rawTitle.replace(/\s+/g, ' ').slice(0, 64);
  const shortTitle = title.length > 26 ? title.slice(0, 23).trim() + '...' : title;

  const combinedText = `${filename} ${title} ${htmlSnippet} ${readmeSnippet} ${entries.join(' ')}`.toLowerCase();

  let category = 'Arcade';
  let genre = 'Indie Arcade';
  let coverMotif = 'arcade';
  let accentPrimary = '#8B5CF6';
  let accentSecondary = '#38BDF8';

  if (/(race|racing|drift|car|kart|turbo|track|rally|speed)/.test(combinedText)) {
    category = 'Racing';
    genre = 'Arcade Racing';
    coverMotif = 'racing';
    accentPrimary = '#38BDF8';
    accentSecondary = '#8B5CF6';
  } else if (/(horror|ghost|haunt|scary|zombie|darkness|nightmare|crypt|terror)/.test(combinedText)) {
    category = 'Horror';
    genre = 'Survival Horror';
    coverMotif = 'horror';
    accentPrimary = '#9333EA';
    accentSecondary = '#F43F5E';
  } else if (/(cartoon|toon|bunny|slime|adventure|quest|dragon|bouncy|buddy)/.test(combinedText)) {
    category = 'Cartoon';
    genre = 'Cartoon Adventure';
    coverMotif = 'cartoon';
    accentPrimary = '#A855F7';
    accentSecondary = '#38BDF8';
  } else if (/(shoot|shooter|laser|bullet|blaster|arena|sniper|space|invader)/.test(combinedText)) {
    category = 'Shooting';
    genre = 'Action Shooter';
    coverMotif = 'shooting';
    accentPrimary = '#38BDF8';
    accentSecondary = '#A855F7';
  } else if (/(puzzle|sudoku|match|chess|tile|maze|logic|tetris|block)/.test(combinedText)) {
    category = 'Puzzle';
    genre = 'Logic Puzzle';
    coverMotif = 'puzzle';
    accentPrimary = '#6366F1';
    accentSecondary = '#38BDF8';
  } else if (/(platform|jump|runner|mario|hop|climb)/.test(combinedText)) {
    category = 'Platformer';
    genre = '2D Platformer';
    coverMotif = 'platformer';
    accentPrimary = '#8B5CF6';
    accentSecondary = '#22D3EE';
  } else if (/(sim|tycoon|farm|city|builder|craft|manage)/.test(combinedText)) {
    category = 'Simulation';
    genre = 'Systems Simulation';
    coverMotif = 'simulation';
    accentPrimary = '#0EA5E9';
    accentSecondary = '#8B5CF6';
  } else if (/(action|fight|combat|sword|ninja|battle|boss)/.test(combinedText)) {
    category = 'Action';
    genre = 'Indie Action';
    coverMotif = 'action';
    accentPrimary = '#8B5CF6';
    accentSecondary = '#38BDF8';
  } else if (/(three\.js|webgl|3d|babylon)/.test(combinedText)) {
    category = '3D';
    genre = '3D Interactive';
    coverMotif = '3d';
  }

  const detectedControls: string[] = [];
  if (/(arrowup|arrowleft|arrowright|arrowdown|keydown)/i.test(combinedText)) {
    detectedControls.push('Arrow Keys to move or steer');
  }
  if (/(keyw|keya|keys|keyd|\bwasd\b)/i.test(combinedText)) {
    detectedControls.push('WASD keys for movement');
  }
  if (/(space|" "|' '|jump|fire|shoot)/i.test(combinedText)) {
    detectedControls.push('Spacebar for primary action');
  }
  if (/(mousedown|mousemove|pointerdown|click|canvas)/i.test(combinedText)) {
    detectedControls.push('Mouse / pointer click & aim');
  }
  if (/(touchstart|touchmove|touchend)/i.test(combinedText)) {
    detectedControls.push('Touch gestures supported');
  }
  if (detectedControls.length === 0) {
    detectedControls.push(
      platform === 'Android' || platform === 'iOS'
        ? 'On-screen touch controls'
        : isBrowserPlayable
          ? 'Keyboard & Mouse controls'
          : 'Standard keyboard, mouse, or controller input'
    );
  }

  const detectedPermissions: string[] = [];
  if (/localstorage|indexeddb|save/i.test(combinedText)) detectedPermissions.push('Local Save Storage');
  if (/audiocontext|audio|sound|webaudio/i.test(combinedText)) detectedPermissions.push('Audio Playback');
  if (/gamepad/i.test(combinedText)) detectedPermissions.push('Gamepad / Controller Input');
  if (/websocket|fetch\(|xmlhttprequest|internet|multiplayer/i.test(combinedText)) {
    detectedPermissions.push('Network Access');
  }
  if (platform === 'Android' && detectedPermissions.length === 0) {
    detectedPermissions.push('Standard App Storage & Audio');
  }
  if (detectedPermissions.length === 0) {
    detectedPermissions.push('No special device permissions required');
  }

  const hasMultiplayer = /(multiplayer|co-op|coop|pvp|online match|websocket|room code)/i.test(combinedText);
  const needsOnline = /(websocket|firebase|multiplayer|leaderboard api|matchmaking)/i.test(combinedText);
  const version = extractVersionFromFilename(filename);
  const lowerFilename = filename.toLowerCase();
  const gameStatus: GameLifecycleStatus = lowerFilename.includes('alpha')
    ? 'Alpha'
    : lowerFilename.includes('beta')
      ? 'Beta'
      : lowerFilename.includes('early')
        ? 'Early Access'
        : 'Released';

  const devName = creatorName && creatorName !== 'Creator Access' ? creatorName : 'Zyntra Creator Studio';
  const year = new Date().getFullYear();

  const shortDescription = `${title} is a custom ${genre.toLowerCase()} release built for ${platform}${isBrowserPlayable ? ' with instant browser play' : ' ready for direct download'}.`;
  const fullDescription =
    readmeSnippet.trim().length > 40
      ? readmeSnippet.trim().slice(0, 800)
      : `${title} is an original indie ${genre.toLowerCase()} experience published on Zyntra Game Store. Packaged as ${platform} (${params.fileFormat.toUpperCase()}), it delivers focused gameplay built directly by its creator.\n\n${isBrowserPlayable ? 'Launch directly inside the Zyntra web player with fullscreen support and instant restart, or download the build archive to keep locally.' : 'Download the verified package directly from Zyntra Game Store and install on your target device.'}`;

  const instructions = isBrowserPlayable
    ? 'Click Play Game to launch inside the Zyntra browser arcade. Use Fullscreen mode for an uninterrupted viewport, or toggle on-screen touch controls on mobile devices.'
    : platform === 'Android'
      ? 'Download the APK package to your Android device, allow installation from trusted sources if prompted, and launch from your app drawer.'
      : 'Download and extract the package on your target device, then run the main executable to start playing.';

  const minRequirements =
    platform === 'Android'
      ? 'Android 8.0+ · 2 GB RAM · 150 MB free storage'
      : platform === 'iOS'
        ? 'iOS 14.0+ · iPhone/iPad with 2 GB RAM'
        : isBrowserPlayable
          ? 'Modern browser (Chrome, Edge, Firefox, or Safari) with HTML5 Canvas / WebGL enabled'
          : '64-bit Desktop OS · Dual-core CPU · 4 GB RAM';

  const recRequirements =
    platform === 'Android'
      ? 'Android 11+ · 4 GB RAM · Snapdragon / Helio G-series or equivalent'
      : platform === 'iOS'
        ? 'iOS 16+ · A13 Bionic or newer'
        : isBrowserPlayable
          ? 'Updated Chrome / Firefox / Edge with hardware acceleration enabled'
          : '64-bit OS · Quad-core CPU · 8 GB RAM · Dedicated or modern integrated GPU';

  const ageRating = category === 'Horror' ? '13+' : 'Everyone';
  const contentRating =
    category === 'Horror'
      ? 'Mild Horror & Suspense'
      : category === 'Shooting' || category === 'Action'
        ? 'Mild Fantasy Action'
        : 'All Ages · Family Friendly';

  const tags = Array.from(new Set([category, platform, genre.split(' ')[0], isBrowserPlayable ? 'Play in Browser' : 'Downloadable', 'Indie'])).slice(0, 6);

  return {
    title,
    shortTitle,
    shortDescription,
    fullDescription,
    category,
    genre,
    version,
    developer: devName,
    publisher: 'Zyntra Indie Publishing',
    tags,
    ageRating,
    contentRating,
    languages: 'English',
    playerMode: hasMultiplayer ? 'Single Player & Multiplayer' : 'Single Player',
    internetRequirement: needsOnline ? 'Online Required' : 'Offline Supported',
    controls: detectedControls.join(' · '),
    instructions,
    minRequirements,
    recRequirements,
    privacyPolicy: 'Follows Zyntra Game Store standard privacy policy (teamjsrofficial517@gmail.com). No unauthorized background tracking.',
    termsConditions: 'Provided for personal entertainment. Redistribution or unauthorized commercial repackaging without creator permission is prohibited.',
    copyrightInfo: `© ${year} ${devName}. Published on Zyntra Game Store.`,
    permissions: detectedPermissions.join(', '),
    gameStatus,
    coverMotif,
    accentPrimary,
    accentSecondary,
  };
}

export function isGamePubliclyVisible(game: GameRecord, nowMs = Date.now()): boolean {
  if (game.visibility === 'private') return false;
  if (game.status === 'published') return true;
  if (game.status === 'scheduled' && game.scheduledReleaseAt) {
    const t = Date.parse(game.scheduledReleaseAt);
    return Number.isFinite(t) && t <= nowMs;
  }
  return false;
}

export function filterAndSortGames(
  games: GameRecord[],
  options: {
    query?: string;
    category?: string;
    platform?: string;
    sort?: 'newest' | 'popular' | 'downloads' | 'title';
    status?: 'published' | 'draft' | 'scheduled' | 'unpublished' | 'all';
    publicOnly?: boolean;
  }
): GameRecord[] {
  const { query = '', category = '', platform = '', sort = 'newest', status = 'published', publicOnly = false } = options;
  const q = query.trim().toLowerCase();
  const cat = category.trim().toLowerCase();
  const plat = platform.trim().toLowerCase();
  const nowMs = Date.now();

  const filtered = games.filter((g) => {
    if (publicOnly && !isGamePubliclyVisible(g, nowMs)) return false;
    if (!publicOnly && status !== 'all' && g.status !== status) return false;
    if (cat && cat !== 'all' && g.category.toLowerCase() !== cat) return false;
    if (plat && plat !== 'all' && g.platform.toLowerCase() !== plat) return false;
    if (q) {
      const haystack = [
        g.title,
        g.shortDescription,
        g.category,
        g.genre,
        g.developer,
        g.publisher,
        g.platform,
        ...g.tags,
      ]
        .join(' ')
        .toLowerCase();
      if (!haystack.includes(q)) return false;
    }
    return true;
  });

  return filtered.sort((a, b) => {
    if (sort === 'popular') {
      return b.playCount + b.downloadCount + b.likeCount * 2 - (a.playCount + a.downloadCount + a.likeCount * 2);
    }
    if (sort === 'downloads') {
      return b.downloadCount - a.downloadCount;
    }
    if (sort === 'title') {
      return a.title.localeCompare(b.title);
    }
    return new Date(b.uploadDate).getTime() - new Date(a.uploadDate).getTime();
  });
}
