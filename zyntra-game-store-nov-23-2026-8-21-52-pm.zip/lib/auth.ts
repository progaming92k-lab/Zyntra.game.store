import crypto from 'node:crypto';
import { cookies } from 'next/headers';
import { NextRequest, NextResponse } from 'next/server';
import { getConfig, setConfig } from './db';

const SESSION_COOKIE_NAME = 'zyntra_owner_session';
const SESSION_TTL_SECONDS = 60 * 60 * 24 * 7; // 7 days

// Pre-configured owner identity and salted scrypt verification hash (server-only)
const DEFAULT_OWNER_EMAIL = 'teamjsrofficial517@gmail.com';
const PRECONFIGURED_CODE_SALT = 'c105dccbecf4517812c443691c9ff72e';
const PRECONFIGURED_CODE_HASH =
  'c8a43b72246d84d30294df389837f37b57f778dbb56eba1cfd85e2931cf8ea6dc358251aaefb68c69bed8a52971ed0ec50de628351968c3ab61914014b05deb6';

function getSessionSecret(): string {
  if (process.env.ZYNTRA_SESSION_SECRET && process.env.ZYNTRA_SESSION_SECRET.length >= 16) {
    return process.env.ZYNTRA_SESSION_SECRET;
  }
  const existing = getConfig('session_secret');
  if (existing) return existing;
  const generated = crypto.randomBytes(32).toString('hex');
  setConfig('session_secret', generated);
  return generated;
}

export function getExpectedOwnerEmail(): string {
  return (process.env.ZYNTRA_OWNER_EMAIL || DEFAULT_OWNER_EMAIL).trim().toLowerCase();
}

export function verifyAccessCode(codeInput: string): boolean {
  const code = codeInput.trim();
  if (!code) return false;

  const derived = crypto.scryptSync(code, PRECONFIGURED_CODE_SALT, 64);
  const expected = Buffer.from(PRECONFIGURED_CODE_HASH, 'hex');
  return derived.length === expected.length && crypto.timingSafeEqual(derived, expected);
}

export function verifyOwnerCredentials(_emailInput: string, codeInput: string): boolean {
  return verifyAccessCode(codeInput);
}

export function hashCreatorPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${hash}`;
}

export function verifyCreatorPassword(password: string, stored: string): boolean {
  const parts = stored.split(':');
  if (parts.length !== 2) return false;
  const [salt, hexHash] = parts;
  if (!salt || !hexHash) return false;
  try {
    const derived = crypto.scryptSync(password, salt, 64);
    const expected = Buffer.from(hexHash, 'hex');
    return derived.length === expected.length && crypto.timingSafeEqual(derived, expected);
  } catch {
    return false;
  }
}

export interface OwnerSessionPayload {
  email: string;
  username: string;
  creatorId: string | null;
  role: 'owner';
  exp: number;
}

export function signSessionToken(
  labelOrEmail: string,
  meta: { username?: string; creatorId?: string | null } = {}
): string {
  const username = meta.username || labelOrEmail;
  const payload: OwnerSessionPayload = {
    email: labelOrEmail,
    username,
    creatorId: meta.creatorId ?? null,
    role: 'owner',
    exp: Math.floor(Date.now() / 1000) + SESSION_TTL_SECONDS,
  };
  const encoded = Buffer.from(JSON.stringify(payload), 'utf8').toString('base64url');
  const sig = crypto.createHmac('sha256', getSessionSecret()).update(encoded).digest('base64url');
  return `${encoded}.${sig}`;
}

export function verifySessionToken(token: string | undefined | null): OwnerSessionPayload | null {
  if (!token || !token.includes('.')) return null;
  const [encoded, sig] = token.split('.');
  if (!encoded || !sig) return null;

  try {
    const expectedSig = crypto.createHmac('sha256', getSessionSecret()).update(encoded).digest('base64url');
    const sigBuf = Buffer.from(sig, 'utf8');
    const expectedBuf = Buffer.from(expectedSig, 'utf8');
    if (sigBuf.length !== expectedBuf.length || !crypto.timingSafeEqual(sigBuf, expectedBuf)) {
      return null;
    }
    const decoded = JSON.parse(Buffer.from(encoded, 'base64url').toString('utf8')) as OwnerSessionPayload;
    if (!decoded || decoded.role !== 'owner' || typeof decoded.exp !== 'number') {
      return null;
    }
    if (decoded.exp < Math.floor(Date.now() / 1000)) {
      return null;
    }
    return {
      email: decoded.email || decoded.username || 'Creator Access',
      username: decoded.username || decoded.email || 'Creator Access',
      creatorId: decoded.creatorId ?? null,
      role: 'owner',
      exp: decoded.exp,
    };
  } catch {
    return null;
  }
}

export function getBearerTokenFromRequest(req: NextRequest): string | null {
  const authHeader = req.headers.get('authorization');
  if (authHeader && authHeader.toLowerCase().startsWith('bearer ')) {
    const token = authHeader.slice(7).trim();
    if (token) return token;
  }
  const customToken = req.headers.get('x-zyntra-token');
  return customToken ? customToken.trim() : null;
}

export async function getServerOwnerSession(): Promise<OwnerSessionPayload | null> {
  const cookieStore = await cookies();
  const token = cookieStore.get(SESSION_COOKIE_NAME)?.value;
  return verifySessionToken(token);
}

export function getRequestOwnerSession(req: NextRequest): OwnerSessionPayload | null {
  const bearer = getBearerTokenFromRequest(req);
  if (bearer) {
    const verified = verifySessionToken(bearer);
    if (verified) return verified;
  }
  const cookieToken = req.cookies.get(SESSION_COOKIE_NAME)?.value;
  return verifySessionToken(cookieToken);
}

export function verifyCsrfProtection(req: NextRequest): boolean {
  const method = req.method.toUpperCase();
  if (method === 'GET' || method === 'HEAD' || method === 'OPTIONS') return true;
  if (getBearerTokenFromRequest(req)) return true;
  const customHeader = req.headers.get('x-requested-with');
  if (customHeader === 'ZyntraStore') return true;
  const origin = req.headers.get('origin');
  const host = req.headers.get('x-forwarded-host') || req.headers.get('host');
  if (origin && host) {
    try {
      const originUrl = new URL(origin);
      return originUrl.host === host;
    } catch {
      return false;
    }
  }
  return false;
}

export function attachSessionCookie(res: NextResponse, req: NextRequest, token: string): void {
  const proto = req.headers.get('x-forwarded-proto') || (req.url.startsWith('https://') ? 'https' : 'http');
  const isHttps = proto === 'https';

  const parts = [
    `${SESSION_COOKIE_NAME}=${token}`,
    'Path=/',
    `Max-Age=${SESSION_TTL_SECONDS}`,
    'HttpOnly',
    isHttps ? 'SameSite=None' : 'SameSite=Lax',
  ];
  if (isHttps) {
    parts.push('Secure', 'Partitioned');
  }
  res.headers.append('Set-Cookie', parts.join('; '));
}

export function clearSessionCookie(res: NextResponse, req: NextRequest): void {
  const proto = req.headers.get('x-forwarded-proto') || (req.url.startsWith('https://') ? 'https' : 'http');
  const isHttps = proto === 'https';
  const parts = [
    `${SESSION_COOKIE_NAME}=`,
    'Path=/',
    'Max-Age=0',
    'HttpOnly',
    isHttps ? 'SameSite=None' : 'SameSite=Lax',
  ];
  if (isHttps) {
    parts.push('Secure', 'Partitioned');
  }
  res.headers.append('Set-Cookie', parts.join('; '));
}
