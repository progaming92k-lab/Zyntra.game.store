import type { Metadata } from 'next';
import ImportGameWorkspace from '@/components/ImportGameWorkspace';
import MotionWrapper from '@/components/MotionWrapper';
import { getServerOwnerSession } from '@/lib/auth';
import { getGameById, listCategories } from '@/lib/db';

export const dynamic = 'force-dynamic';

export const metadata: Metadata = {
  title: 'Import Game',
  description: 'Creator upload and 8-stage publishing dashboard for Zyntra Game Store.',
  robots: { index: false, follow: false },
};

export default async function ImportGamePage({
  searchParams,
}: {
  searchParams: Promise<{ edit?: string }>;
}) {
  const sp = await searchParams;
  const session = await getServerOwnerSession();
  const categories = listCategories(false);
  const initialGame = session && sp.edit ? getGameById(sp.edit) : null;

  return (
    <MotionWrapper>
      <ImportGameWorkspace
        initialAuthenticated={Boolean(session)}
        initialEmail={session?.email || null}
        categories={categories}
        initialGame={initialGame}
      />
    </MotionWrapper>
  );
}
