import type { Metadata } from 'next';
import AdminDashboard from '@/components/AdminDashboard';
import MotionWrapper from '@/components/MotionWrapper';
import { getServerOwnerSession } from '@/lib/auth';
import { getStoreStats, listCategories, listGameReports, listGames } from '@/lib/db';

export const dynamic = 'force-dynamic';

export const metadata: Metadata = {
  title: 'Admin Dashboard',
  description: 'Private owner management console for Zyntra Game Store.',
  robots: { index: false, follow: false },
};

export default async function AdminPage() {
  const session = await getServerOwnerSession();
  const categories = listCategories(true);

  const games = session ? listGames({ includeDrafts: true }) : [];
  const stats = session ? getStoreStats() : null;
  const reports = session ? listGameReports() : [];

  return (
    <MotionWrapper>
      <AdminDashboard
        initialAuthenticated={Boolean(session)}
        initialEmail={session?.email || null}
        initialGames={games}
        initialStats={stats}
        initialCategories={categories}
        initialReports={reports}
      />
    </MotionWrapper>
  );
}
