import type { Metadata } from 'next';
import Link from 'next/link';
import { ArrowRight } from 'lucide-react';
import MotionWrapper from '@/components/MotionWrapper';
import { listCategories } from '@/lib/db';

export const dynamic = 'force-dynamic';

export const metadata: Metadata = {
  title: 'Categories',
  description: 'Browse game categories on Zyntra Game Store including Cartoon, Action, Racing, Arcade, Horror, Puzzle, and more.',
};

export default function CategoriesPage() {
  const categories = listCategories(true);

  return (
    <MotionWrapper>
      <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
        <div className="border-b border-[#1D1F2B] pb-8">
          <h1 className="font-display text-3xl font-bold text-[#F4F4F8] sm:text-4xl">Game Categories</h1>
          <p className="mt-2 max-w-2xl text-sm text-[#9CA3B4] sm:text-base">
            Discover games grouped by genre, gameplay mechanics, and visual style.
          </p>
        </div>

        <div className="mt-8 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {categories.map((cat) => (
            <Link
              key={cat.id}
              href={`/categories/${encodeURIComponent(cat.slug)}`}
              className="group flex flex-col justify-between rounded-xl border border-[#222432] bg-[#111218] p-6 transition-all duration-150 hover:-translate-y-0.5 hover:border-[#8B5CF6]/60 hover:bg-[#151722]"
            >
              <div>
                <div className="flex items-center justify-between gap-2">
                  <h2 className="font-display text-xl font-bold text-[#F4F4F8] group-hover:text-[#38BDF8]">
                    {cat.name}
                  </h2>
                  <ArrowRight
                    className="h-4 w-4 text-[#73788C] transition-transform group-hover:translate-x-0.5 group-hover:text-[#38BDF8]"
                    aria-hidden="true"
                  />
                </div>
                <p className="mt-2 text-sm leading-relaxed text-[#9CA3B4]">{cat.description}</p>
              </div>
              <div className="mt-5 pt-3 border-t border-[#1C1E2B] font-mono text-xs text-[#8E94A8] tabular-nums">
                {cat.gameCount || 0} published {cat.gameCount === 1 ? 'game' : 'games'}
              </div>
            </Link>
          ))}
        </div>
      </div>
    </MotionWrapper>
  );
}
