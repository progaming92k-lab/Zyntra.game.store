import type { Metadata } from 'next';
import Link from 'next/link';
import { ArrowLeft } from 'lucide-react';
import GameCard from '@/components/GameCard';
import EmptyStoreState from '@/components/EmptyStoreState';
import MotionWrapper from '@/components/MotionWrapper';
import { listCategories, listGames } from '@/lib/db';
import { filterAndSortGames } from '@/lib/game-logic';

export const dynamic = 'force-dynamic';

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const categories = listCategories(false);
  const found = categories.find((c) => c.slug.toLowerCase() === slug.toLowerCase());
  const name = found ? found.name : slug;
  return {
    title: `${name} Games`,
    description: `Play and download ${name} games on Zyntra Game Store.`,
  };
}

export default async function CategoryDetailPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const categories = listCategories(true);
  const matched = categories.find((c) => c.slug.toLowerCase() === slug.toLowerCase());
  const categoryName = matched ? matched.name : slug;

  const allPublished = listGames({ includeDrafts: false });
  const games = filterAndSortGames(allPublished, {
    category: categoryName,
    status: 'published',
    sort: 'newest',
  });

  return (
    <MotionWrapper>
      <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
        <Link
          href="/categories"
          className="inline-flex items-center gap-2 text-sm font-medium text-[#9CA3B4] hover:text-[#38BDF8]"
        >
          <ArrowLeft className="h-4 w-4" aria-hidden="true" />
          <span>Back to Categories</span>
        </Link>

        <div className="mt-5 border-b border-[#1D1F2B] pb-8">
          <h1 className="font-display text-3xl font-bold text-[#F4F4F8] sm:text-4xl">{categoryName} Games</h1>
          <p className="mt-2 max-w-2xl text-sm text-[#9CA3B4] sm:text-base">
            {matched?.description || `Explore ${categoryName} releases published on Zyntra Game Store.`}
          </p>
        </div>

        <div className="mt-8">
          {games.length === 0 ? (
            <EmptyStoreState
              title={`No ${categoryName} Games Published Yet`}
              description={`Upload a ${categoryName.toLowerCase()} game through Import Game to populate this category automatically.`}
            />
          ) : (
            <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {games.map((game) => (
                <GameCard key={game.id} game={game} />
              ))}
            </div>
          )}
        </div>
      </div>
    </MotionWrapper>
  );
}
