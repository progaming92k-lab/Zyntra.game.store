import type { Metadata } from 'next';
import CatalogExplorer from '@/components/CatalogExplorer';
import MotionWrapper from '@/components/MotionWrapper';
import { listCategories, listGames } from '@/lib/db';

export const dynamic = 'force-dynamic';

export const metadata: Metadata = {
  title: 'Search Games',
  description: 'Search games on Zyntra Game Store by title, category, genre, tags, or developer.',
};

export default async function SearchPage({
  searchParams,
}: {
  searchParams: Promise<{ q?: string; category?: string }>;
}) {
  const sp = await searchParams;
  const games = listGames({ includeDrafts: false });
  const categories = listCategories(true);

  return (
    <MotionWrapper>
      <CatalogExplorer
        initialGames={games}
        categories={categories}
        initialQuery={sp.q || ''}
        initialCategory={sp.category || 'All'}
        heading={sp.q ? `Search Results for “${sp.q}”` : 'Search Zyntra Catalog'}
        subheading="Filter across game titles, genres, developer names, platforms, and tags."
      />
    </MotionWrapper>
  );
}
