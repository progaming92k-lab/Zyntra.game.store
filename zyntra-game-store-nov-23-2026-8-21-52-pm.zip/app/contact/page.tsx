import type { Metadata } from 'next';
import { Mail } from 'lucide-react';
import ContactForm from '@/components/ContactForm';
import MotionWrapper from '@/components/MotionWrapper';

export const metadata: Metadata = {
  title: 'Contact Us',
  description: 'Get in touch with Zyntra Game Store for game support, feedback, or inquiries.',
};

export default function ContactPage() {
  return (
    <MotionWrapper>
      <div className="mx-auto max-w-3xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="border-b border-[#1D1F2B] pb-6">
          <h1 className="font-display text-3xl font-bold text-[#F4F4F8] sm:text-4xl">Contact Us</h1>
          <p className="mt-2 text-sm text-[#9CA3B4] sm:text-base">
            Have feedback about a game, encountered a technical issue, or want to reach the store owner? Send a message below or email us directly.
          </p>
        </div>

        <div className="mt-6 flex flex-wrap items-center justify-between gap-3 rounded-xl border border-[#232634] bg-[#111218]/85 px-5 py-4 backdrop-blur-md">
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg border border-[#38BDF8]/30 bg-[#38BDF8]/10 text-[#38BDF8]">
              <Mail className="h-4 w-4" aria-hidden="true" />
            </div>
            <div>
              <div className="text-xs font-medium text-[#8E94A8]">Direct Support Email</div>
              <a
                href="mailto:teamjsrofficial517@gmail.com"
                className="text-sm font-semibold text-[#F4F4F8] hover:text-[#38BDF8]"
              >
                teamjsrofficial517@gmail.com
              </a>
            </div>
          </div>
          <a
            href="mailto:teamjsrofficial517@gmail.com"
            className="rounded-lg border border-[#282B3E] bg-[#161822] px-3.5 py-2 text-xs font-semibold text-[#D1D5E2] transition-colors hover:border-[#38BDF8]/60 hover:text-white"
          >
            Send Email
          </a>
        </div>

        <div className="mt-6">
          <ContactForm />
        </div>
      </div>
    </MotionWrapper>
  );
}
