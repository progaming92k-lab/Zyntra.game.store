import type { Metadata } from 'next';
import Link from 'next/link';
import MotionWrapper from '@/components/MotionWrapper';

export const metadata: Metadata = {
  title: 'Privacy Policy',
  description: 'Privacy Policy for Zyntra Game Store covering uploaded game files, downloads, aggregate play analytics, and data handling.',
};

export default function PrivacyPage() {
  return (
    <MotionWrapper>
      <article className="mx-auto max-w-4xl px-4 py-12 sm:px-6 lg:px-8">
        <header className="border-b border-[#1D1F2B] pb-6">
          <h1 className="font-display text-3xl font-bold text-[#F4F4F8] sm:text-4xl">Privacy Policy</h1>
          <p className="mt-2 text-sm text-[#8E94A8]">Last updated: November 2026</p>
        </header>

        <div className="mt-8 space-y-8 rounded-2xl border border-[#222434] bg-[#0D0E14]/82 p-6 text-sm leading-relaxed text-[#B6BCCF] backdrop-blur-md sm:p-8 sm:text-base">
          <section>
            <h2 className="font-display text-xl font-bold text-[#F4F4F8]">1. Overview</h2>
            <p className="mt-2">
              Zyntra Game Store (&ldquo;we&rdquo;, &ldquo;our&rdquo;, or &ldquo;the Storefront&rdquo;) respects your privacy and keeps data collection minimal. This policy explains how information is handled when you browse games, play browser-hosted titles, download game builds, submit contact messages, or sign in as the store owner.
            </p>
          </section>

          <section>
            <h2 className="font-display text-xl font-bold text-[#F4F4F8]">2. Downloads &amp; Browser Gameplay Analytics</h2>
            <p className="mt-2">
              To display accurate popularity rankings and provide creator insights inside the private Admin Dashboard, Zyntra Game Store records aggregate numeric counters for game launches (&ldquo;Play Count&rdquo;) and file downloads (&ldquo;Download Count&rdquo;). These counters are strictly aggregate totals per game title and are not tied to personal visitor profiles or third-party ad trackers.
            </p>
          </section>

          <section>
            <h2 className="font-display text-xl font-bold text-[#F4F4F8]">3. Uploaded Files &amp; Automated Analysis</h2>
            <p className="mt-2">
              When the store owner uploads game builds (such as ZIP archives, HTML5 games, Android APKs, or desktop packages) via the protected Import Game studio, files are stored on the server&apos;s persistent storage volume. During import, file manifests, HTML metadata, and bundled artwork may be inspected by our server-side analysis pipeline to automatically populate store descriptions, controls, and cover assets.
            </p>
          </section>

          <section>
            <h2 className="font-display text-xl font-bold text-[#F4F4F8]">4. Authentication Cookies &amp; Contact Messages</h2>
            <p className="mt-2">
              Public visitors can browse, play, and download games without creating accounts. An encrypted, HTTP-only session cookie is set exclusively when the store owner authenticates to access the Import Game studio or Admin Dashboard. If you submit a message through our Contact Us form, your name, email address, subject, and message are stored in the storefront database solely to respond to your inquiry.
            </p>
          </section>

          <section>
            <h2 className="font-display text-xl font-bold text-[#F4F4F8]">5. Data Retention &amp; Security</h2>
            <p className="mt-2">
              Uploaded game packages remain hosted until deleted or replaced by the store owner. We enforce strict server-side path validation on archive extractions, signed session verification on administrative endpoints, and never expose private owner credentials to public client bundles.
            </p>
          </section>

          <section className="rounded-xl border border-[#26293B] bg-[#111218]/90 p-5">
            <h2 className="font-display text-xl font-bold text-[#F4F4F8]">6. Contact &amp; Privacy Inquiries</h2>
            <p className="mt-2">
              If you have any questions about this Privacy Policy, data deletion requests, or content inquiries on Zyntra Game Store, please contact the store owner directly at{' '}
              <a
                href="mailto:teamjsrofficial517@gmail.com"
                className="font-medium text-[#38BDF8] underline underline-offset-4 hover:text-[#7DD3FC]"
              >
                teamjsrofficial517@gmail.com
              </a>{' '}
              or submit a message via our{' '}
              <Link
                href="/contact"
                className="font-medium text-[#C4B5FD] underline underline-offset-4 hover:text-white"
              >
                Contact Us
              </Link>{' '}
              page.
            </p>
          </section>
        </div>
      </article>
    </MotionWrapper>
  );
}
