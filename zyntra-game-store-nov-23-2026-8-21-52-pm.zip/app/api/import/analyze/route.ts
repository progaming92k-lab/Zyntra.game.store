import crypto from 'node:crypto';
import { NextRequest, NextResponse } from 'next/server';
import { getRequestOwnerSession, verifyCsrfProtection } from '@/lib/auth';
import { processAndAnalyzeUpload } from '@/lib/analyzer';
import { getAllSlugs, insertGame } from '@/lib/db';
import { ensureUniqueSlug } from '@/lib/game-logic';
import type { GameRecord } from '@/lib/types';

export async function POST(req: NextRequest) {
  if (!verifyCsrfProtection(req)) {
    return NextResponse.json({ error: 'Invalid request origin.' }, { status: 403 });
  }
  const session = getRequestOwnerSession(req);
  if (!session) {
    return NextResponse.json({ error: 'Owner authentication required.' }, { status: 401 });
  }

  try {
    const formData = await req.formData();
    const file = formData.get('file');
    if (!file || !(file instanceof File)) {
      return NextResponse.json({ error: 'Please select a game file to upload.' }, { status: 400 });
    }

    if (file.size === 0) {
      return NextResponse.json({ error: 'The uploaded file is empty.' }, { status: 400 });
    }

    const arrayBuffer = await file.arrayBuffer();
    const buffer = Buffer.from(arrayBuffer);
    const gameId = crypto.randomUUID();
    const creatorLabel = session.email && session.email !== 'Creator Access' ? session.email : undefined;

    const processed = await processAndAnalyzeUpload({
      gameId,
      originalFilename: file.name,
      buffer,
      creatorName: creatorLabel,
    });

    const existingSlugs = getAllSlugs();
    const slug = ensureUniqueSlug(processed.draft.title, existingSlugs);
    const nowIso = new Date().toISOString();

    const record: GameRecord = {
      id: gameId,
      slug,
      title: processed.draft.title,
      shortTitle: processed.draft.shortTitle,
      shortDescription: processed.draft.shortDescription,
      fullDescription: processed.draft.fullDescription,
      category: processed.draft.category,
      genre: processed.draft.genre,
      platform: processed.platform,
      version: processed.draft.version,
      developer: processed.draft.developer,
      publisher: processed.draft.publisher,
      creatorUsername: session.username || 'creator',
      fileSize: processed.fileSize,
      fileFormat: processed.fileFormat,
      originalFilename: processed.originalFilename,
      storedFilePath: processed.storedFilePath,
      extractedDir: processed.extractedDir,
      entryFile: processed.entryFile,
      isBrowserPlayable: processed.isBrowserPlayable,
      isDownloadable: processed.isDownloadable,
      coverImage: processed.coverImage,
      iconImage: processed.iconImage,
      screenshots: processed.screenshots,
      tags: processed.draft.tags,
      ageRating: processed.draft.ageRating,
      contentRating: processed.draft.contentRating,
      languages: processed.draft.languages,
      playerMode: processed.draft.playerMode,
      internetRequirement: processed.draft.internetRequirement,
      controls: processed.draft.controls,
      instructions: processed.draft.instructions,
      minRequirements: processed.draft.minRequirements,
      recRequirements: processed.draft.recRequirements,
      privacyPolicy: processed.draft.privacyPolicy,
      termsConditions: processed.draft.termsConditions,
      copyrightInfo: processed.draft.copyrightInfo,
      permissions: processed.draft.permissions,
      releaseDate: processed.draft.releaseDate,
      uploadDate: nowIso,
      updatedAt: nowIso,
      scheduledReleaseAt: null,
      gameStatus: processed.draft.gameStatus,
      status: 'draft',
      visibility: 'public',
      featured: false,
      trending: false,
      pricingType: 'free',
      priceLabel: 'Free',
      collectionName: 'Creator Originals',
      downloadCount: 0,
      playCount: 0,
      viewCount: 0,
      likeCount: 0,
      aiSummaryNotes: processed.draft.aiSummaryNotes,
    };

    insertGame(record);
    return NextResponse.json({ game: record }, { status: 201 });
  } catch (err) {
    console.error('Upload analysis failed:', err);
    return NextResponse.json(
      { error: err instanceof Error ? err.message : 'Failed to analyze uploaded game.' },
      { status: 500 }
    );
  }
}
