import { NextRequest, NextResponse } from 'next/server';
import { saveContactMessage } from '@/lib/db';

export async function POST(req: NextRequest) {
  try {
    const body = (await req.json()) as {
      name?: string;
      email?: string;
      subject?: string;
      message?: string;
    };

    const name = (body.name || '').trim();
    const email = (body.email || '').trim();
    const subject = (body.subject || '').trim();
    const message = (body.message || '').trim();

    if (!name || !email || !subject || !message) {
      return NextResponse.json({ error: 'All contact fields are required.' }, { status: 400 });
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return NextResponse.json({ error: 'Please provide a valid email address.' }, { status: 400 });
    }

    const id = saveContactMessage({ name, email, subject, message });
    return NextResponse.json({ id, saved: true }, { status: 201 });
  } catch {
    return NextResponse.json({ error: 'Unable to submit message.' }, { status: 400 });
  }
}
