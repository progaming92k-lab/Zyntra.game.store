import { NextRequest, NextResponse } from 'next/server';
import { getRequestOwnerSession } from '@/lib/auth';
import { getStoreStats, listGameReports } from '@/lib/db';

export async function GET(req: NextRequest) {
  const session = getRequestOwnerSession(req);
  if (!session) {
    return NextResponse.json({ error: 'Owner authentication required.' }, { status: 401 });
  }
  const stats = getStoreStats();
  const reports = listGameReports();
  return NextResponse.json({ stats, reports });
}
