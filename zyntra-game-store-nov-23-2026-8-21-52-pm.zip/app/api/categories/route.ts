import { NextRequest, NextResponse } from 'next/server';
import { getRequestOwnerSession, verifyCsrfProtection } from '@/lib/auth';
import { createCategory, deleteCategoryById, listCategories } from '@/lib/db';

export async function GET() {
  const categories = listCategories(true);
  return NextResponse.json({ categories });
}

export async function POST(req: NextRequest) {
  if (!verifyCsrfProtection(req)) {
    return NextResponse.json({ error: 'Invalid request origin.' }, { status: 403 });
  }
  const session = getRequestOwnerSession(req);
  if (!session) {
    return NextResponse.json({ error: 'Owner authentication required.' }, { status: 401 });
  }

  try {
    const body = (await req.json()) as { name?: string; description?: string };
    const name = (body.name || '').trim();
    if (!name || name.length > 40) {
      return NextResponse.json({ error: 'Category name is required (1-40 characters).' }, { status: 400 });
    }
    const category = createCategory(name, body.description || '');
    return NextResponse.json({ category }, { status: 201 });
  } catch {
    return NextResponse.json({ error: 'Category already exists or invalid.' }, { status: 400 });
  }
}

export async function DELETE(req: NextRequest) {
  if (!verifyCsrfProtection(req)) {
    return NextResponse.json({ error: 'Invalid request origin.' }, { status: 403 });
  }
  const session = getRequestOwnerSession(req);
  if (!session) {
    return NextResponse.json({ error: 'Owner authentication required.' }, { status: 401 });
  }

  const { searchParams } = new URL(req.url);
  const id = searchParams.get('id') || '';
  if (!id) {
    return NextResponse.json({ error: 'Category id is required.' }, { status: 400 });
  }

  const deleted = deleteCategoryById(id);
  if (!deleted) {
    return NextResponse.json({ error: 'Category not found.' }, { status: 404 });
  }
  return NextResponse.json({ deleted: true });
}
