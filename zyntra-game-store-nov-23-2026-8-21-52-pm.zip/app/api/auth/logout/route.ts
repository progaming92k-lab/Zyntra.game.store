import { NextRequest, NextResponse } from 'next/server';
import { clearSessionCookie, verifyCsrfProtection } from '@/lib/auth';

export async function POST(req: NextRequest) {
  if (!verifyCsrfProtection(req)) {
    return NextResponse.json({ error: 'Invalid request origin.' }, { status: 403 });
  }
  const res = NextResponse.json({ authenticated: false });
  clearSessionCookie(res, req);
  return res;
}
