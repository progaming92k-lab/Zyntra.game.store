import { NextRequest, NextResponse } from 'next/server';
import { getRequestOwnerSession } from '@/lib/auth';

export async function GET(req: NextRequest) {
  const session = getRequestOwnerSession(req);
  if (!session) {
    return NextResponse.json({ authenticated: false });
  }
  return NextResponse.json({
    authenticated: true,
    username: session.username,
    email: session.email,
  });
}
