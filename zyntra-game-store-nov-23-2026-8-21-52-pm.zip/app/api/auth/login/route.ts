import { NextRequest, NextResponse } from 'next/server';
import {
  attachSessionCookie,
  signSessionToken,
  verifyAccessCode,
  verifyCreatorPassword,
  verifyCsrfProtection,
} from '@/lib/auth';
import { getCreatorWithHashByUsername } from '@/lib/db';
import { sanitizeUsername } from '@/lib/game-logic';

export async function POST(req: NextRequest) {
  if (!verifyCsrfProtection(req)) {
    return NextResponse.json({ error: 'Invalid request origin.' }, { status: 403 });
  }

  try {
    const body = (await req.json()) as {
      mode?: 'code' | 'account';
      accessCode?: string;
      username?: string;
      password?: string;
    };

    const isAccountMode = body.mode === 'account' || (typeof body.username === 'string' && !body.accessCode);

    if (isAccountMode) {
      const rawUsername = typeof body.username === 'string' ? body.username.trim() : '';
      const username = sanitizeUsername(rawUsername);
      const password = typeof body.password === 'string' ? body.password : '';

      if (!username || !password) {
        return NextResponse.json({ error: 'Username and password are required.' }, { status: 400 });
      }

      const creator = getCreatorWithHashByUsername(username);
      if (!creator || !verifyCreatorPassword(password, creator.passwordHash)) {
        return NextResponse.json({ error: 'Invalid username or password.' }, { status: 401 });
      }

      const token = signSessionToken(creator.displayName, {
        username: creator.username,
        creatorId: creator.id,
      });
      const res = NextResponse.json({
        authenticated: true,
        token,
        username: creator.displayName,
        email: creator.displayName,
      });
      attachSessionCookie(res, req, token);
      return res;
    }

    const accessCode = typeof body.accessCode === 'string' ? body.accessCode : '';
    if (!accessCode.trim()) {
      return NextResponse.json({ error: 'Import access code is required.' }, { status: 400 });
    }

    const valid = verifyAccessCode(accessCode);
    if (!valid) {
      return NextResponse.json({ error: 'Invalid import access code.' }, { status: 401 });
    }

    const sessionLabel = 'Creator Access';
    const token = signSessionToken(sessionLabel, { username: 'creator', creatorId: null });
    const res = NextResponse.json({
      authenticated: true,
      token,
      username: sessionLabel,
      email: sessionLabel,
    });
    attachSessionCookie(res, req, token);
    return res;
  } catch {
    return NextResponse.json({ error: 'Unable to process login request.' }, { status: 400 });
  }
}
