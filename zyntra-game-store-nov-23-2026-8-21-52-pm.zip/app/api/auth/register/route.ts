import { NextRequest, NextResponse } from 'next/server';
import {
  attachSessionCookie,
  hashCreatorPassword,
  signSessionToken,
  verifyCsrfProtection,
} from '@/lib/auth';
import { createCreatorAccount, getCreatorWithHashByUsername } from '@/lib/db';
import { sanitizeUsername } from '@/lib/game-logic';

export async function POST(req: NextRequest) {
  if (!verifyCsrfProtection(req)) {
    return NextResponse.json({ error: 'Invalid request origin.' }, { status: 403 });
  }

  try {
    const body = (await req.json()) as {
      username?: string;
      password?: string;
      bio?: string;
    };

    const rawUsername = typeof body.username === 'string' ? body.username.trim() : '';
    const username = sanitizeUsername(rawUsername);
    const password = typeof body.password === 'string' ? body.password : '';
    const bio = typeof body.bio === 'string' ? body.bio.trim().slice(0, 240) : '';

    if (!username) {
      return NextResponse.json(
        { error: 'Username must be 3-32 characters using letters, numbers, dots, underscores, or hyphens.' },
        { status: 400 }
      );
    }

    if (password.length < 4) {
      return NextResponse.json(
        { error: 'Password must be at least 4 characters long.' },
        { status: 400 }
      );
    }

    const existing = getCreatorWithHashByUsername(username);
    if (existing) {
      return NextResponse.json(
        { error: 'That username is already taken. Please sign in or pick another username.' },
        { status: 409 }
      );
    }

    const passwordHash = hashCreatorPassword(password);
    const creator = createCreatorAccount({
      username,
      displayName: rawUsername,
      passwordHash,
      bio,
    });

    const token = signSessionToken(creator.displayName, {
      username: creator.username,
      creatorId: creator.id,
    });

    const res = NextResponse.json(
      {
        authenticated: true,
        token,
        username: creator.displayName,
        email: creator.displayName,
      },
      { status: 201 }
    );
    attachSessionCookie(res, req, token);
    return res;
  } catch {
    return NextResponse.json({ error: 'Unable to create creator account.' }, { status: 400 });
  }
}
