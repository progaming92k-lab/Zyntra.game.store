import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { NextRequest, NextResponse } from 'next/server';
import { getRequestOwnerSession, verifyCsrfProtection } from '@/lib/auth';
import { COVERS_DIR, ICONS_DIR, SCREENSHOTS_DIR, getGameById, updateGame } from '@/lib/db';

const ALLOWED_IMG_EXT = new Set(['.png', '.jpg', '.jpeg', '.webp', '.svg']);

export async function POST(
  req: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  if (!verifyCsrfProtection(req)) {
    return NextResponse.json({ error: 'Invalid request origin.' }, { status: 403 });
  }
  const session = getRequestOwnerSession(req);
  if (!session) {
    return NextResponse.json({ error: 'Owner authentication required.' }, { status: 401 });
  }

  const { id } = await context.params;
  const existing = getGameById(id);
  if (!existing) {
    return NextResponse.json({ error: 'Game not found.' }, { status: 404 });
  }

  try {
    const formData = await req.formData();
    const kind = String(formData.get('kind') || 'cover');
    const file = formData.get('file');
    if (!file || !(file instanceof File) || file.size === 0) {
      return NextResponse.json({ error: 'Please select an image file.' }, { status: 400 });
    }

    const ext = path.extname(file.name).toLowerCase() || '.png';
    if (!ALLOWED_IMG_EXT.has(ext)) {
      return NextResponse.json({ error: 'Unsupported image format. Use PNG, JPG, WebP, or SVG.' }, { status: 400 });
    }

    const buf = Buffer.from(await file.arrayBuffer());
    const stamp = crypto.randomBytes(4).toString('hex');

    if (kind === 'icon') {
      fs.mkdirSync(ICONS_DIR, { recursive: true });
      const filename = `${existing.id}-icon-${stamp}${ext}`;
      fs.writeFileSync(path.join(ICONS_DIR, filename), buf);
      const updated = updateGame(existing.id, { iconImage: `/api/media/icons/${filename}` });
      return NextResponse.json({ game: updated });
    }

    if (kind === 'screenshot') {
      fs.mkdirSync(SCREENSHOTS_DIR, { recursive: true });
      const filename = `${existing.id}-shot-${stamp}${ext}`;
      fs.writeFileSync(path.join(SCREENSHOTS_DIR, filename), buf);
      const updated = updateGame(existing.id, {
        screenshots: [...existing.screenshots, `/api/media/screenshots/${filename}`],
      });
      return NextResponse.json({ game: updated });
    }

    fs.mkdirSync(COVERS_DIR, { recursive: true });
    const filename = `${existing.id}-cover-${stamp}${ext}`;
    fs.writeFileSync(path.join(COVERS_DIR, filename), buf);
    const updated = updateGame(existing.id, { coverImage: `/api/media/covers/${filename}` });
    return NextResponse.json({ game: updated });
  } catch {
    return NextResponse.json({ error: 'Failed to upload image.' }, { status: 500 });
  }
}
