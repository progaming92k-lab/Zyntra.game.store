import { NextRequest, NextResponse } from 'next/server';
import { getRequestOwnerSession, verifyCsrfProtection } from '@/lib/auth';
import { deleteGameById, getAllSlugs, getGameById, getGameBySlug, updateGame } from '@/lib/db';
import { ensureUniqueSlug } from '@/lib/game-logic';
import type { GameRecord } from '@/lib/types';

export async function GET(
  req: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  const { id } = await context.params;
  const session = getRequestOwnerSession(req);
  const game = getGameById(id) || getGameBySlug(id, Boolean(session));

  if (!game) {
    return NextResponse.json({ error: 'Game not found.' }, { status: 404 });
  }
  if ((game.status !== 'published' || game.visibility === 'private') && !session) {
    return NextResponse.json({ error: 'Game not found.' }, { status: 404 });
  }

  return NextResponse.json({ game });
}

export async function PATCH(
  req: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  if (!verifyCsrfProtection(req)) {
    return NextResponse.json({ error: 'Invalid request origin.' }, { status: 403 });
  }
  const session = getRequestOwnerSession(req);
  if (!session) {
    return NextResponse.json({ error: 'Owner authentication required.' }, { status: 401 });
  }

  const { id } = await context.params;
  const existing = getGameById(id);
  if (!existing) {
    return NextResponse.json({ error: 'Game not found.' }, { status: 404 });
  }

  try {
    const body = (await req.json()) as Partial<GameRecord>;
    const patch: Partial<GameRecord> = {};

    if (typeof body.title === 'string' && body.title.trim()) {
      patch.title = body.title.trim().slice(0, 100);
      if (body.title.trim() !== existing.title && !body.slug) {
        const slugs = getAllSlugs();
        slugs.delete(existing.slug);
        patch.slug = ensureUniqueSlug(patch.title, slugs);
      }
    }
    if (typeof body.slug === 'string' && body.slug.trim()) {
      const slugs = getAllSlugs();
      slugs.delete(existing.slug);
      patch.slug = ensureUniqueSlug(body.slug.trim(), slugs);
    }
    if (typeof body.shortTitle === 'string') patch.shortTitle = body.shortTitle.trim().slice(0, 40);
    if (typeof body.shortDescription === 'string') patch.shortDescription = body.shortDescription.trim().slice(0, 260);
    if (typeof body.fullDescription === 'string') patch.fullDescription = body.fullDescription.trim();
    if (typeof body.category === 'string' && body.category.trim()) patch.category = body.category.trim();
    if (typeof body.genre === 'string' && body.genre.trim()) patch.genre = body.genre.trim();
    if (typeof body.platform === 'string' && body.platform.trim()) patch.platform = body.platform.trim() as GameRecord['platform'];
    if (typeof body.version === 'string' && body.version.trim()) patch.version = body.version.trim();
    if (typeof body.developer === 'string' && body.developer.trim()) patch.developer = body.developer.trim();
    if (typeof body.publisher === 'string' && body.publisher.trim()) patch.publisher = body.publisher.trim();
    if (typeof body.ageRating === 'string') patch.ageRating = body.ageRating.trim();
    if (typeof body.contentRating === 'string') patch.contentRating = body.contentRating.trim();
    if (typeof body.languages === 'string') patch.languages = body.languages.trim();
    if (typeof body.playerMode === 'string') patch.playerMode = body.playerMode.trim();
    if (typeof body.internetRequirement === 'string') patch.internetRequirement = body.internetRequirement.trim();
    if (typeof body.controls === 'string') patch.controls = body.controls.trim();
    if (typeof body.instructions === 'string') patch.instructions = body.instructions.trim();
    if (typeof body.minRequirements === 'string') patch.minRequirements = body.minRequirements.trim();
    if (typeof body.recRequirements === 'string') patch.recRequirements = body.recRequirements.trim();
    if (typeof body.privacyPolicy === 'string') patch.privacyPolicy = body.privacyPolicy.trim();
    if (typeof body.termsConditions === 'string') patch.termsConditions = body.termsConditions.trim();
    if (typeof body.copyrightInfo === 'string') patch.copyrightInfo = body.copyrightInfo.trim();
    if (typeof body.permissions === 'string') patch.permissions = body.permissions.trim();
    if (typeof body.releaseDate === 'string') patch.releaseDate = body.releaseDate.trim();
    if (typeof body.collectionName === 'string') patch.collectionName = body.collectionName.trim();
    if (typeof body.featured === 'boolean') patch.featured = body.featured;
    if (typeof body.trending === 'boolean') patch.trending = body.trending;
    if (typeof body.isBrowserPlayable === 'boolean') patch.isBrowserPlayable = body.isBrowserPlayable;
    if (typeof body.isDownloadable === 'boolean') patch.isDownloadable = body.isDownloadable;

    if (
      body.gameStatus === 'Released' ||
      body.gameStatus === 'Beta' ||
      body.gameStatus === 'Early Access' ||
      body.gameStatus === 'Alpha'
    ) {
      patch.gameStatus = body.gameStatus;
    }

    if (
      body.status === 'published' ||
      body.status === 'draft' ||
      body.status === 'scheduled' ||
      body.status === 'unpublished'
    ) {
      patch.status = body.status;
    }

    if (body.visibility === 'public' || body.visibility === 'private') {
      patch.visibility = body.visibility;
    }

    if (body.pricingType === 'free' || body.pricingType === 'paid') {
      patch.pricingType = body.pricingType;
      patch.priceLabel =
        body.pricingType === 'free'
          ? 'Free'
          : typeof body.priceLabel === 'string' && body.priceLabel.trim()
            ? body.priceLabel.trim().slice(0, 24)
            : '$4.99';
    } else if (typeof body.priceLabel === 'string' && body.priceLabel.trim()) {
      patch.priceLabel = body.priceLabel.trim().slice(0, 24);
    }

    if (body.scheduledReleaseAt === null) {
      patch.scheduledReleaseAt = null;
    } else if (typeof body.scheduledReleaseAt === 'string' && body.scheduledReleaseAt.trim()) {
      patch.scheduledReleaseAt = body.scheduledReleaseAt.trim();
    }

    if (Array.isArray(body.tags)) {
      patch.tags = body.tags.filter((t): t is string => typeof t === 'string' && t.trim().length > 0).map((t) => t.trim());
    }
    if (typeof body.coverImage === 'string' && body.coverImage.startsWith('/api/media/')) {
      patch.coverImage = body.coverImage;
    }
    if (typeof body.iconImage === 'string' && body.iconImage.startsWith('/api/media/')) {
      patch.iconImage = body.iconImage;
    }
    if (Array.isArray(body.screenshots)) {
      patch.screenshots = body.screenshots.filter((s): s is string => typeof s === 'string' && s.startsWith('/api/media/'));
    }

    const updated = updateGame(id, patch);
    return NextResponse.json({ game: updated });
  } catch {
    return NextResponse.json({ error: 'Invalid update payload.' }, { status: 400 });
  }
}

export async function DELETE(
  req: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  if (!verifyCsrfProtection(req)) {
    return NextResponse.json({ error: 'Invalid request origin.' }, { status: 403 });
  }
  const session = getRequestOwnerSession(req);
  if (!session) {
    return NextResponse.json({ error: 'Owner authentication required.' }, { status: 401 });
  }

  const { id } = await context.params;
  const deleted = deleteGameById(id);
  if (!deleted) {
    return NextResponse.json({ error: 'Game not found.' }, { status: 404 });
  }
  return NextResponse.json({ deleted: true });
}
