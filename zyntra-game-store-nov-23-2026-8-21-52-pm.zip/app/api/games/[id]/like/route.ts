import { NextRequest, NextResponse } from 'next/server';
import { getGameById, getGameBySlug, incrementLikeCount } from '@/lib/db';

export async function POST(
  _req: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  const { id } = await context.params;
  const game = getGameById(id) || getGameBySlug(id, true);
  if (!game) {
    return NextResponse.json({ error: 'Game not found.' }, { status: 404 });
  }
  const likeCount = incrementLikeCount(game.id);
  return NextResponse.json({ ok: true, likeCount });
}
