import { NextRequest, NextResponse } from 'next/server';
import { addGameReport, getGameById, getGameBySlug } from '@/lib/db';

export async function POST(
  req: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  const { id } = await context.params;
  const game = getGameById(id) || getGameBySlug(id, true);
  if (!game) {
    return NextResponse.json({ error: 'Game not found.' }, { status: 404 });
  }

  try {
    const body = (await req.json()) as { reason?: string; details?: string };
    const reason = typeof body.reason === 'string' ? body.reason.trim() : '';
    const details = typeof body.details === 'string' ? body.details.trim().slice(0, 600) : '';

    if (!reason) {
      return NextResponse.json({ error: 'Please choose a report reason.' }, { status: 400 });
    }

    const report = addGameReport({
      gameId: game.id,
      reason: reason.slice(0, 120),
      details,
    });
    return NextResponse.json({ ok: true, reportId: report.id }, { status: 201 });
  } catch {
    return NextResponse.json({ error: 'Unable to submit report.' }, { status: 400 });
  }
}
