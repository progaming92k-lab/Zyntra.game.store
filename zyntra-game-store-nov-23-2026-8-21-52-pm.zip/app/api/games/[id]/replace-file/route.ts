import fs from 'node:fs';
import path from 'node:path';
import { NextRequest, NextResponse } from 'next/server';
import { getRequestOwnerSession, verifyCsrfProtection } from '@/lib/auth';
import { processAndAnalyzeUpload } from '@/lib/analyzer';
import { FILES_DIR, PLAYABLE_DIR, getGameById, updateGame } from '@/lib/db';

export async function POST(
  req: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  if (!verifyCsrfProtection(req)) {
    return NextResponse.json({ error: 'Invalid request origin.' }, { status: 403 });
  }
  const session = getRequestOwnerSession(req);
  if (!session) {
    return NextResponse.json({ error: 'Owner authentication required.' }, { status: 401 });
  }

  const { id } = await context.params;
  const existing = getGameById(id);
  if (!existing) {
    return NextResponse.json({ error: 'Game not found.' }, { status: 404 });
  }

  try {
    const formData = await req.formData();
    const file = formData.get('file');
    const newVersion = formData.get('version');

    if (!file || !(file instanceof File) || file.size === 0) {
      return NextResponse.json({ error: 'Valid replacement game file required.' }, { status: 400 });
    }

    // Clean old extracted playable directory and old file directory before writing new build
    const oldFileDir = path.dirname(path.join(FILES_DIR, existing.storedFilePath));
    if (oldFileDir.startsWith(FILES_DIR + path.sep) && fs.existsSync(oldFileDir)) {
      fs.rmSync(oldFileDir, { recursive: true, force: true });
    }
    if (existing.extractedDir) {
      const oldPlayDir = path.join(PLAYABLE_DIR, existing.extractedDir);
      if (oldPlayDir.startsWith(PLAYABLE_DIR + path.sep) && fs.existsSync(oldPlayDir)) {
        fs.rmSync(oldPlayDir, { recursive: true, force: true });
      }
    }

    const buffer = Buffer.from(await file.arrayBuffer());
    const processed = await processAndAnalyzeUpload({
      gameId: existing.id,
      originalFilename: file.name,
      buffer,
    });

    const updated = updateGame(existing.id, {
      fileSize: processed.fileSize,
      fileFormat: processed.fileFormat,
      originalFilename: processed.originalFilename,
      storedFilePath: processed.storedFilePath,
      extractedDir: processed.extractedDir,
      entryFile: processed.entryFile,
      isBrowserPlayable: processed.isBrowserPlayable,
      isDownloadable: processed.isDownloadable,
      platform: processed.platform,
      version: typeof newVersion === 'string' && newVersion.trim() ? newVersion.trim() : processed.draft.version,
    });

    return NextResponse.json({ game: updated });
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : 'Failed to replace game file.' },
      { status: 500 }
    );
  }
}
