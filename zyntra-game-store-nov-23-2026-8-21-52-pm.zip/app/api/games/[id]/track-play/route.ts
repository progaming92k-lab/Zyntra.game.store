import { NextRequest, NextResponse } from 'next/server';
import { getGameById, getGameBySlug, incrementPlayCount } from '@/lib/db';

export async function POST(
  _req: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  const { id } = await context.params;
  const game = getGameById(id) || getGameBySlug(id, true);
  if (!game || !game.isBrowserPlayable) {
    return NextResponse.json({ error: 'Playable game not found.' }, { status: 404 });
  }
  incrementPlayCount(game.id);
  return NextResponse.json({ ok: true, playCount: game.playCount + 1 });
}
