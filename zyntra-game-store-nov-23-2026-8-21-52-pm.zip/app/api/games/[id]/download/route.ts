import fs from 'node:fs';
import path from 'node:path';
import { NextRequest, NextResponse } from 'next/server';
import { getRequestOwnerSession } from '@/lib/auth';
import { FILES_DIR, getGameById, getGameBySlug, incrementDownloadCount } from '@/lib/db';
import { isPathInside } from '@/lib/path-utils';

export async function GET(
  req: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  const { id } = await context.params;
  const session = getRequestOwnerSession(req);
  const game = getGameById(id) || getGameBySlug(id, Boolean(session));

  if (!game || (game.status !== 'published' && !session)) {
    return NextResponse.json({ error: 'Game not found.' }, { status: 404 });
  }

  if (!game.isDownloadable) {
    return NextResponse.json({ error: 'This game is not marked as downloadable.' }, { status: 403 });
  }

  const filePath = path.resolve(FILES_DIR, game.storedFilePath);
  if (!isPathInside(FILES_DIR, filePath) || !fs.existsSync(filePath)) {
    return NextResponse.json({ error: 'Game file not found on server storage.' }, { status: 404 });
  }

  const stat = fs.statSync(filePath);
  const fileBuffer = fs.readFileSync(filePath);
  incrementDownloadCount(game.id);

  const safeDownloadName = game.originalFilename.replace(/[^a-zA-Z0-9._-]/g, '_');

  return new NextResponse(fileBuffer, {
    status: 200,
    headers: {
      'Content-Type': 'application/octet-stream',
      'Content-Length': String(stat.size),
      'Content-Disposition': `attachment; filename="${safeDownloadName}"`,
      'Cache-Control': 'no-store',
    },
  });
}
