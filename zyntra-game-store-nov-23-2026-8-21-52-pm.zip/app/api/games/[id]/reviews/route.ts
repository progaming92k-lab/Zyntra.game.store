import { NextRequest, NextResponse } from 'next/server';
import { addGameReview, getGameById, getGameBySlug, listGameReviews } from '@/lib/db';

export async function GET(
  _req: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  const { id } = await context.params;
  const game = getGameById(id) || getGameBySlug(id, true);
  if (!game) {
    return NextResponse.json({ error: 'Game not found.' }, { status: 404 });
  }
  const reviews = listGameReviews(game.id);
  return NextResponse.json({ reviews });
}

export async function POST(
  req: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  const { id } = await context.params;
  const game = getGameById(id) || getGameBySlug(id, true);
  if (!game) {
    return NextResponse.json({ error: 'Game not found.' }, { status: 404 });
  }

  try {
    const body = (await req.json()) as {
      authorName?: string;
      rating?: number;
      comment?: string;
    };

    const authorName = (typeof body.authorName === 'string' ? body.authorName.trim() : '') || 'Zyntra Player';
    const rating = Number(body.rating);
    const comment = typeof body.comment === 'string' ? body.comment.trim() : '';

    if (!Number.isFinite(rating) || rating < 1 || rating > 5) {
      return NextResponse.json({ error: 'Please select a rating between 1 and 5 stars.' }, { status: 400 });
    }
    if (comment.length < 3 || comment.length > 800) {
      return NextResponse.json({ error: 'Review comment must be between 3 and 800 characters.' }, { status: 400 });
    }

    const review = addGameReview({
      gameId: game.id,
      authorName: authorName.slice(0, 48),
      rating,
      comment,
    });

    return NextResponse.json({ review }, { status: 201 });
  } catch {
    return NextResponse.json({ error: 'Unable to save review.' }, { status: 400 });
  }
}
