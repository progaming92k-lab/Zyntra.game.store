import { NextRequest, NextResponse } from 'next/server';
import { getRequestOwnerSession } from '@/lib/auth';
import { listGames } from '@/lib/db';
import { filterAndSortGames } from '@/lib/game-logic';

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const includeDraftsParam = searchParams.get('includeDrafts') === '1';
  const session = includeDraftsParam ? getRequestOwnerSession(req) : null;
  const includeDrafts = Boolean(includeDraftsParam && session);

  const query = searchParams.get('q') || '';
  const category = searchParams.get('category') || '';
  const platform = searchParams.get('platform') || '';
  const sortParam = searchParams.get('sort') || 'newest';
  const statusParam = searchParams.get('status') || (includeDrafts ? 'all' : 'published');

  const sort =
    sortParam === 'popular' || sortParam === 'downloads' || sortParam === 'title' ? sortParam : 'newest';
  const status =
    includeDrafts &&
    (statusParam === 'all' ||
      statusParam === 'draft' ||
      statusParam === 'published' ||
      statusParam === 'scheduled' ||
      statusParam === 'unpublished')
      ? statusParam
      : 'published';

  const allGames = listGames({ includeDrafts });
  const games = filterAndSortGames(allGames, {
    query,
    category,
    platform,
    sort,
    status,
    publicOnly: !includeDrafts,
  });

  return NextResponse.json({ games });
}
