import fs from 'node:fs';
import path from 'node:path';
import { NextRequest, NextResponse } from 'next/server';
import { COVERS_DIR, ICONS_DIR, SCREENSHOTS_DIR } from '@/lib/db';
import { isPathInside } from '@/lib/path-utils';

const DIR_MAP: Record<string, string> = {
  covers: COVERS_DIR,
  icons: ICONS_DIR,
  screenshots: SCREENSHOTS_DIR,
};

const MIME_MAP: Record<string, string> = {
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
};

export async function GET(
  _req: NextRequest,
  context: { params: Promise<{ type: string; filename: string }> }
) {
  const { type, filename } = await context.params;
  const baseDir = DIR_MAP[type];
  if (!baseDir) {
    return new NextResponse('Not found', { status: 404 });
  }

  const safeName = path.basename(filename);
  const fullPath = path.resolve(baseDir, safeName);
  if (!isPathInside(baseDir, fullPath) || !fs.existsSync(fullPath)) {
    return new NextResponse('Not found', { status: 404 });
  }

  const ext = path.extname(safeName).toLowerCase();
  const contentType = MIME_MAP[ext] || 'application/octet-stream';
  const buf = fs.readFileSync(fullPath);

  return new NextResponse(buf, {
    status: 200,
    headers: {
      'Content-Type': contentType,
      'Cache-Control': 'public, max-age=3600',
    },
  });
}
