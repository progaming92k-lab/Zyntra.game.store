import fs from 'node:fs';
import path from 'node:path';
import { NextRequest, NextResponse } from 'next/server';
import { getRequestOwnerSession } from '@/lib/auth';
import { PLAYABLE_DIR, getGameById, getGameBySlug } from '@/lib/db';
import { isPathInside } from '@/lib/path-utils';

const MIME_MAP: Record<string, string> = {
  '.html': 'text/html; charset=utf-8',
  '.htm': 'text/html; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.mjs': 'application/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.wasm': 'application/wasm',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.webp': 'image/webp',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.mp3': 'audio/mpeg',
  '.wav': 'audio/wav',
  '.ogg': 'audio/ogg',
  '.mp4': 'video/mp4',
  '.webm': 'video/webm',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
  '.ttf': 'font/ttf',
  '.txt': 'text/plain; charset=utf-8',
  '.xml': 'application/xml; charset=utf-8',
  '.data': 'application/octet-stream',
  '.pck': 'application/octet-stream',
};

export async function GET(
  req: NextRequest,
  context: { params: Promise<{ slug: string; asset?: string[] }> }
) {
  const { slug, asset } = await context.params;
  const session = getRequestOwnerSession(req);
  const game = getGameBySlug(slug, Boolean(session)) || getGameById(slug);

  if (!game || (game.status !== 'published' && !session)) {
    return new NextResponse('Game not found.', { status: 404 });
  }
  if (!game.isBrowserPlayable || !game.extractedDir || !game.entryFile) {
    return new NextResponse('This game is not configured for browser playback.', { status: 404 });
  }

  const gameRoot = path.resolve(PLAYABLE_DIR, game.extractedDir);
  if (!isPathInside(PLAYABLE_DIR, gameRoot) || !fs.existsSync(gameRoot)) {
    return new NextResponse('Playable game files missing.', { status: 404 });
  }

  const relParts = asset && asset.length > 0 ? asset : null;
  if (!relParts) {
    // Redirect to exact entryFile path so relative URLs resolve inside any nested directory
    const entryClean = game.entryFile.replace(/^\/+/, '');
    return NextResponse.redirect(new URL(`/api/play/${encodeURIComponent(game.slug)}/${entryClean}`, req.url));
  }

  const joined = relParts.join('/');
  const resolved = path.resolve(gameRoot, joined);
  if (!isPathInside(gameRoot, resolved) || !fs.existsSync(resolved) || fs.statSync(resolved).isDirectory()) {
    return new NextResponse('Game asset not found.', { status: 404 });
  }

  const fileBuf = fs.readFileSync(resolved);
  const lower = resolved.toLowerCase();

  let contentEncoding: string | undefined;
  let extForMime = path.extname(lower);
  if (lower.endsWith('.gz')) {
    contentEncoding = 'gzip';
    extForMime = path.extname(lower.slice(0, -3));
  } else if (lower.endsWith('.br')) {
    contentEncoding = 'br';
    extForMime = path.extname(lower.slice(0, -3));
  }

  const contentType = MIME_MAP[extForMime] || 'application/octet-stream';
  const headers: Record<string, string> = {
    'Content-Type': contentType,
    'Cache-Control': 'public, max-age=300',
  };
  if (contentEncoding) {
    headers['Content-Encoding'] = contentEncoding;
  }

  return new NextResponse(fileBuf, { status: 200, headers });
}
