import type { Metadata } from 'next';
import { Outfit, Plus_Jakarta_Sans, JetBrains_Mono } from 'next/font/google';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import AnimatedBackground from '@/components/AnimatedBackground';
import SoundEngine from '@/components/SoundEngine';
import './globals.css';

const outfit = Outfit({
  subsets: ['latin'],
  weight: ['500', '600', '700', '800'],
  variable: '--font-display',
  display: 'swap',
});

const plusJakarta = Plus_Jakarta_Sans({
  subsets: ['latin'],
  weight: ['400', '500', '600', '700'],
  variable: '--font-sans',
  display: 'swap',
});

const jetbrainsMono = JetBrains_Mono({
  subsets: ['latin'],
  weight: ['400', '500', '600'],
  variable: '--font-mono',
  display: 'swap',
});

const appUrl =
  process.env.APP_URL && process.env.APP_URL !== 'MY_APP_URL'
    ? process.env.APP_URL
    : 'https://zyntra-game-store.local';

export const metadata: Metadata = {
  metadataBase: new URL(appUrl),
  title: {
    default: 'Zyntra Game Store – Play & Download Original Indie Games',
    template: '%s | Zyntra Game Store',
  },
  description:
    'Discover, play in-browser, and download custom-built HTML5, WebGL, Android, and desktop games on Zyntra Game Store.',
  openGraph: {
    type: 'website',
    siteName: 'Zyntra Game Store',
    title: 'Zyntra Game Store – Play & Download Original Indie Games',
    description:
      'Discover, play in-browser, and download custom-built HTML5, WebGL, Android, and desktop games on Zyntra Game Store.',
    images: [{ url: '/images/zyntra-hero.jpg', width: 1280, height: 720, alt: 'Zyntra Game Store' }],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Zyntra Game Store – Play & Download Original Indie Games',
    description:
      'Discover, play in-browser, and download custom-built HTML5, WebGL, Android, and desktop games.',
    images: ['/images/zyntra-hero.jpg'],
  },
  robots: {
    index: true,
    follow: true,
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  const jsonLd = {
    '@context': 'https://schema.org',
    '@type': 'WebSite',
    name: 'Zyntra Game Store',
    url: appUrl,
    potentialAction: {
      '@type': 'SearchAction',
      target: `${appUrl}/search?q={search_term_string}`,
      'query-input': 'required name=search_term_string',
    },
  };

  return (
    <html
      lang="en"
      data-scroll-behavior="smooth"
      className={`${outfit.variable} ${plusJakarta.variable} ${jetbrainsMono.variable} dark`}
    >
      <body suppressHydrationWarning className="relative min-h-screen bg-[#07070B] text-[#F4F4F8] antialiased">
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
        />
        <AnimatedBackground />
        <SoundEngine />
        <div className="relative z-10 flex min-h-screen flex-col">
          <Navbar />
          <main className="flex-1">{children}</main>
          <Footer />
        </div>
      </body>
    </html>
  );
}
