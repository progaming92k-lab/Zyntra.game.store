import type { Metadata } from 'next';
import Image from 'next/image';
import Link from 'next/link';
import MotionWrapper from '@/components/MotionWrapper';

export const metadata: Metadata = {
  title: 'About Us',
  description: 'Learn about Zyntra Game Store, an independent digital storefront built for publishing, playing, and downloading original indie games.',
};

export default function AboutPage() {
  return (
    <MotionWrapper>
      <div className="mx-auto max-w-6xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 gap-10 lg:grid-cols-12 items-center">
          <div className="lg:col-span-6">
            <p className="text-xs font-semibold tracking-widest text-[#38BDF8] uppercase">About Zyntra</p>
            <h1 className="mt-3 font-display text-3xl font-extrabold text-[#F4F4F8] sm:text-4xl">
              Built for Independent Creators &amp; Direct Play
            </h1>
            <p className="mt-4 text-base leading-relaxed text-[#A5ABBE]">
              Zyntra Game Store is a dedicated digital storefront engineered to take original games straight from a creator&apos;s workspace to players around the world—without friction, clutter, or bloated intermediaries.
            </p>
            <p className="mt-4 text-sm leading-relaxed text-[#9CA3B4]">
              Whether publishing a lightweight HTML5 arcade release, a Unity WebGL 3D build, an Android APK, or a standalone desktop package, Zyntra automatically inspects uploaded packages, prepares artwork and metadata, and serves playable builds directly in the browser or via verified file downloads.
            </p>

            <div className="mt-7 flex flex-wrap gap-3">
              <Link
                href="/games"
                className="rounded-lg bg-[#8B5CF6] px-5 py-2.5 text-sm font-semibold text-white hover:bg-[#7C3AED]"
              >
                Explore Catalog
              </Link>
              <Link
                href="/contact"
                className="rounded-lg border border-[#282B3B] bg-[#111218] px-5 py-2.5 text-sm font-medium text-[#D1D5E2] hover:text-white"
              >
                Contact Us
              </Link>
            </div>
          </div>

          <div className="relative aspect-[4/3] overflow-hidden rounded-2xl border border-[#232634] bg-[#0B0C11] lg:col-span-6">
            <Image
              src="/images/zyntra-creator-studio.jpg"
              alt="Indie game creator workstation with dual wireframe monitors and controller"
              fill
              sizes="(max-width: 1024px) 100vw, 50vw"
              referrerPolicy="no-referrer"
              className="object-cover"
            />
          </div>
        </div>

        <div className="mt-16 grid grid-cols-1 gap-6 border-t border-[#1D1F2B] pt-12 md:grid-cols-3">
          <div className="rounded-xl border border-[#222432] bg-[#111218] p-6">
            <h2 className="font-display text-lg font-bold text-[#F4F4F8]">Instant Browser Arcade</h2>
            <p className="mt-2 text-sm leading-relaxed text-[#9CA3B4]">
              HTML5 and WebGL ZIP archives extract cleanly on the server so players can launch games in seconds with fullscreen support and optional touch controls.
            </p>
          </div>
          <div className="rounded-xl border border-[#222432] bg-[#111218] p-6">
            <h2 className="font-display text-lg font-bold text-[#F4F4F8]">Verified Direct Downloads</h2>
            <p className="mt-2 text-sm leading-relaxed text-[#9CA3B4]">
              Android APKs and desktop packages are stored permanently with exact file-size reporting and reliable streamed downloads.
            </p>
          </div>
          <div className="rounded-xl border border-[#222432] bg-[#111218] p-6">
            <h2 className="font-display text-lg font-bold text-[#F4F4F8]">Automated Publishing Pipeline</h2>
            <p className="mt-2 text-sm leading-relaxed text-[#9CA3B4]">
              Intelligent file inspection and cover generation prepare complete game listings from a single upload so creators focus on building games.
            </p>
          </div>
        </div>
      </div>
    </MotionWrapper>
  );
}
