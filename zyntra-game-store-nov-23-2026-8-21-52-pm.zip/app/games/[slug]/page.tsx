import { Fragment } from 'react';
import type { Metadata } from 'next';
import Link from 'next/link';
import { notFound } from 'next/navigation';
import {
  ArrowLeft,
  Calendar,
  Cpu,
  Eye,
  FileCode2,
  Gamepad2,
  Globe,
  HardDrive,
  Languages,
  Monitor,
  Play,
  ShieldCheck,
  Tag,
  User,
  Users,
  Wifi,
} from 'lucide-react';
import DownloadButton from '@/components/DownloadButton';
import GameCard from '@/components/GameCard';
import GameInteractions from '@/components/GameInteractions';
import MotionWrapper from '@/components/MotionWrapper';
import ShareButton from '@/components/ShareButton';
import { getServerOwnerSession } from '@/lib/auth';
import { getGameBySlug, incrementViewCount, listGameReviews, listGames } from '@/lib/db';
import { formatBytes } from '@/lib/game-logic';

export const dynamic = 'force-dynamic';

export async function generateMetadata({
  params,
  searchParams,
}: {
  params: Promise<{ slug: string }>;
  searchParams: Promise<{ preview?: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const sp = await searchParams;
  const session = sp.preview === '1' ? await getServerOwnerSession() : null;
  const game = getGameBySlug(slug, Boolean(session));

  if (!game) {
    return { title: 'Game Not Found' };
  }

  return {
    title: `${game.title} – ${game.category} Game`,
    description: game.shortDescription,
    openGraph: {
      title: `${game.title} | Zyntra Game Store`,
      description: game.shortDescription,
      type: 'website',
      images: [{ url: game.coverImage, alt: `${game.title} cover` }],
    },
    twitter: {
      card: 'summary_large_image',
      title: `${game.title} | Zyntra Game Store`,
      description: game.shortDescription,
      images: [game.coverImage],
    },
  };
}

export default async function GameDetailPage({
  params,
  searchParams,
}: {
  params: Promise<{ slug: string }>;
  searchParams: Promise<{ preview?: string }>;
}) {
  const { slug } = await params;
  const sp = await searchParams;
  const session = await getServerOwnerSession();
  const game = getGameBySlug(slug, true);

  if (!game) {
    notFound();
  }

  const isPublicLive = game.status === 'published' && game.visibility === 'public';
  if (!isPublicLive && !session) {
    notFound();
  }

  let currentViews = game.viewCount;
  if (isPublicLive && sp.preview !== '1') {
    currentViews = incrementViewCount(game.id);
  }

  const reviews = listGameReviews(game.id);
  const allPublished = listGames({ includeDrafts: false });
  const similarGames = allPublished
    .filter((g) => g.id !== game.id && (g.category === game.category || g.platform === game.platform))
    .slice(0, 3);

  const creatorSlug = encodeURIComponent(game.creatorUsername || game.developer || 'creator');

  const jsonLd = {
    '@context': 'https://schema.org',
    '@type': 'VideoGame',
    name: game.title,
    description: game.shortDescription,
    genre: game.genre || game.category,
    gamePlatform: game.platform,
    applicationCategory: 'Game',
    operatingSystem:
      game.platform === 'Android' ? 'Android' : game.isBrowserPlayable ? 'Web Browser' : 'Windows / Desktop',
    softwareVersion: game.version,
    datePublished: game.releaseDate,
    author: {
      '@type': 'Organization',
      name: game.developer,
    },
    offers: {
      '@type': 'Offer',
      price: game.pricingType === 'free' ? '0' : game.priceLabel.replace(/[^0-9.]/g, '') || '0',
      priceCurrency: 'USD',
      availability: 'https://schema.org/InStock',
    },
  };

  return (
    <MotionWrapper>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      />

      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <Link
            href="/games"
            className="inline-flex items-center gap-2 text-sm font-medium text-[#9CA3B4] hover:text-[#38BDF8]"
          >
            <ArrowLeft className="h-4 w-4" aria-hidden="true" />
            <span>Back to All Games</span>
          </Link>

          {!isPublicLive && (
            <span className="text-xs font-semibold text-amber-300">
              {game.status.toUpperCase()} ({game.visibility}) · Creator Preview
            </span>
          )}
        </div>

        {/* Top Contiguous Showcase & Action Module */}
        <div className="mt-6 grid grid-cols-1 gap-8 lg:grid-cols-12 items-start">
          {/* Left: Cover, Screenshots, Description, Specs, Reviews */}
          <div className="space-y-6 lg:col-span-8">
            <div className="overflow-hidden rounded-2xl border border-[#232634] bg-[#0B0C11]">
              <img
                src={game.coverImage}
                alt={`${game.title} cover art`}
                referrerPolicy="no-referrer"
                className="aspect-video w-full object-cover"
              />
            </div>

            {game.screenshots.length > 0 && (
              <section aria-labelledby="screenshots-heading">
                <h2 id="screenshots-heading" className="font-display text-xl font-bold text-[#F4F4F8]">
                  Screenshots
                </h2>
                <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2">
                  {game.screenshots.map((shot, idx) => (
                    <div key={shot} className="overflow-hidden rounded-xl border border-[#222432] bg-[#0B0C11]">
                      <img
                        src={shot}
                        alt={`${game.title} screenshot ${idx + 1}`}
                        referrerPolicy="no-referrer"
                        className="aspect-video w-full object-cover"
                      />
                    </div>
                  ))}
                </div>
              </section>
            )}

            {/* About */}
            <section
              aria-labelledby="about-game-heading"
              className="rounded-2xl border border-[#222432] bg-[#111218] p-6 sm:p-8"
            >
              <h2 id="about-game-heading" className="font-display text-xl font-bold text-[#F4F4F8]">
                About {game.title}
              </h2>
              <div className="mt-4 space-y-4 text-sm leading-relaxed text-[#B6BCCF] sm:text-base whitespace-pre-line">
                {game.fullDescription}
              </div>

              {game.tags.length > 0 && (
                <div className="mt-6 border-t border-[#1C1E2B] pt-5 text-xs text-[#8E94A8]">
                  <span className="font-semibold text-[#D1D5E2]">Tags: </span>
                  {game.tags.map((tag, idx) => (
                    <Fragment key={tag}>
                      {idx > 0 && <span aria-hidden="true"> · </span>}
                      <Link href={`/search?q=${encodeURIComponent(tag)}`} className="hover:text-[#38BDF8]">
                        {tag}
                      </Link>
                    </Fragment>
                  ))}
                </div>
              )}
            </section>

            {/* Controls, Instructions & Requirements */}
            <section className="grid grid-cols-1 gap-5 md:grid-cols-2">
              <div className="rounded-2xl border border-[#222432] bg-[#111218] p-6">
                <h2 className="font-display text-lg font-bold text-[#F4F4F8]">Controls</h2>
                <p className="mt-3 text-sm leading-relaxed text-[#A5ABBE]">
                  {game.controls || 'Standard platform input supported.'}
                </p>
              </div>

              <div className="rounded-2xl border border-[#222432] bg-[#111218] p-6">
                <h2 className="font-display text-lg font-bold text-[#F4F4F8]">How to Play</h2>
                <p className="mt-3 text-sm leading-relaxed text-[#A5ABBE]">
                  {game.instructions || 'Launch or download the package to get started.'}
                </p>
              </div>

              <div className="rounded-2xl border border-[#222432] bg-[#111218] p-6">
                <h2 className="font-display text-lg font-bold text-[#F4F4F8]">Minimum Requirements</h2>
                <p className="mt-2 text-sm leading-relaxed text-[#A5ABBE]">
                  {game.minRequirements || 'Compatible modern browser or target platform runtime.'}
                </p>
              </div>

              <div className="rounded-2xl border border-[#222432] bg-[#111218] p-6">
                <h2 className="font-display text-lg font-bold text-[#F4F4F8]">Recommended Requirements</h2>
                <p className="mt-2 text-sm leading-relaxed text-[#A5ABBE]">
                  {game.recRequirements || game.minRequirements || 'Updated browser or target OS build.'}
                </p>
              </div>
            </section>

            {/* Permissions, Copyright & Policies */}
            <section className="rounded-2xl border border-[#222432] bg-[#111218] p-6 space-y-4">
              <h2 className="font-display text-lg font-bold text-[#F4F4F8]">Permissions &amp; Legal Info</h2>
              <div className="grid grid-cols-1 gap-4 text-xs text-[#9CA3B4] sm:grid-cols-2">
                <div>
                  <div className="font-semibold text-[#D1D5E2]">Game Permissions</div>
                  <p className="mt-1 leading-relaxed">{game.permissions || 'Standard platform permissions'}</p>
                </div>
                <div>
                  <div className="font-semibold text-[#D1D5E2]">Copyright Information</div>
                  <p className="mt-1 leading-relaxed">{game.copyrightInfo || `© ${game.developer}`}</p>
                </div>
                <div>
                  <div className="font-semibold text-[#D1D5E2]">Privacy Policy</div>
                  <p className="mt-1 leading-relaxed">
                    {game.privacyPolicy || 'Follows Zyntra Game Store Privacy Policy.'}
                  </p>
                </div>
                <div>
                  <div className="font-semibold text-[#D1D5E2]">Terms &amp; Conditions</div>
                  <p className="mt-1 leading-relaxed">
                    {game.termsConditions || 'Standard personal entertainment license.'}
                  </p>
                </div>
              </div>
            </section>

            {/* Interactive Likes, Ratings, Reviews & Report */}
            <GameInteractions
              gameId={game.id}
              gameTitle={game.title}
              initialLikes={game.likeCount}
              initialReviews={reviews}
            />
          </div>

          {/* Right: Sticky Purchase / Play / Full Technical Spec Sheet */}
          <aside className="lg:col-span-4 lg:sticky lg:top-24">
            <div className="rounded-2xl border border-[#232634] bg-[#111218] p-6">
              <div className="flex items-start gap-4">
                <img
                  src={game.iconImage}
                  alt={`${game.title} icon`}
                  referrerPolicy="no-referrer"
                  className="h-16 w-16 shrink-0 rounded-xl border border-[#262938] bg-[#0B0C11] object-cover"
                />
                <div className="min-w-0">
                  <div className="text-xs font-medium text-[#38BDF8]">
                    {game.category} · {game.genre}
                  </div>
                  <h1 className="mt-1 font-display text-2xl font-bold leading-tight text-[#F4F4F8]">
                    {game.title}
                  </h1>
                  <p className="mt-1 text-xs text-[#9CA3B4]">
                    by{' '}
                    <Link href={`/creators/${creatorSlug}`} className="text-[#38BDF8] hover:underline">
                      {game.developer}
                    </Link>
                  </p>
                </div>
              </div>

              <p className="mt-4 text-sm leading-relaxed text-[#A5ABBE]">{game.shortDescription}</p>

              {/* Primary CTAs */}
              <div className="mt-6 space-y-3">
                {game.isBrowserPlayable && (
                  <Link
                    href={`/games/${game.slug}/play`}
                    className="zyntra-btn-shine inline-flex w-full items-center justify-center gap-2.5 rounded-lg bg-gradient-to-r from-[#7C3AED] to-[#0EA5E9] px-5 py-3 text-sm font-semibold text-white shadow-[0_0_24px_rgba(124,58,237,0.35)] transition-all duration-150 hover:brightness-110 whitespace-nowrap"
                  >
                    <Play className="h-4 w-4 fill-current" aria-hidden="true" />
                    <span>Play Game in Browser</span>
                  </Link>
                )}

                {game.isDownloadable && (
                  <DownloadButton
                    gameId={game.id}
                    filename={game.originalFilename}
                    fileFormat={game.fileFormat}
                    fileSize={game.fileSize}
                    variant={game.isBrowserPlayable ? 'secondary' : 'primary'}
                  />
                )}

                <ShareButton
                  variant="card"
                  label="Share Game"
                  title={game.title}
                  text={game.shortDescription}
                />
              </div>

              {/* Technical Spec Sheet */}
              <dl className="mt-6 divide-y divide-[#1C1E2B] border-t border-[#1C1E2B] text-xs sm:text-sm">
                <div className="flex items-center justify-between py-2.5">
                  <dt className="flex items-center gap-2 text-[#8E94A8]">
                    <Tag className="h-4 w-4" aria-hidden="true" />
                    <span>Price</span>
                  </dt>
                  <dd className="font-semibold text-emerald-400">
                    {game.pricingType === 'paid' ? game.priceLabel || 'Paid' : 'Free'}
                  </dd>
                </div>
                <div className="flex items-center justify-between py-2.5">
                  <dt className="flex items-center gap-2 text-[#8E94A8]">
                    <Monitor className="h-4 w-4" aria-hidden="true" />
                    <span>Platform</span>
                  </dt>
                  <dd className="font-medium text-[#F4F4F8]">{game.platform}</dd>
                </div>
                <div className="flex items-center justify-between py-2.5">
                  <dt className="flex items-center gap-2 text-[#8E94A8]">
                    <FileCode2 className="h-4 w-4" aria-hidden="true" />
                    <span>File Format</span>
                  </dt>
                  <dd className="font-mono text-[#F4F4F8]">{game.fileFormat.toUpperCase()}</dd>
                </div>
                <div className="flex items-center justify-between py-2.5">
                  <dt className="flex items-center gap-2 text-[#8E94A8]">
                    <Cpu className="h-4 w-4" aria-hidden="true" />
                    <span>Version / Status</span>
                  </dt>
                  <dd className="font-mono text-[#F4F4F8] tabular-nums">
                    v{game.version} · {game.gameStatus}
                  </dd>
                </div>
                <div className="flex items-center justify-between py-2.5">
                  <dt className="flex items-center gap-2 text-[#8E94A8]">
                    <HardDrive className="h-4 w-4" aria-hidden="true" />
                    <span>File Size</span>
                  </dt>
                  <dd className="font-mono text-[#F4F4F8] tabular-nums">{formatBytes(game.fileSize)}</dd>
                </div>
                <div className="flex items-center justify-between py-2.5">
                  <dt className="flex items-center gap-2 text-[#8E94A8]">
                    <Users className="h-4 w-4" aria-hidden="true" />
                    <span>Player Mode</span>
                  </dt>
                  <dd className="text-[#F4F4F8] text-right">{game.playerMode}</dd>
                </div>
                <div className="flex items-center justify-between py-2.5">
                  <dt className="flex items-center gap-2 text-[#8E94A8]">
                    <Wifi className="h-4 w-4" aria-hidden="true" />
                    <span>Internet</span>
                  </dt>
                  <dd className="text-[#F4F4F8] text-right">{game.internetRequirement}</dd>
                </div>
                <div className="flex items-center justify-between py-2.5">
                  <dt className="flex items-center gap-2 text-[#8E94A8]">
                    <Languages className="h-4 w-4" aria-hidden="true" />
                    <span>Languages</span>
                  </dt>
                  <dd className="text-[#F4F4F8] text-right">{game.languages}</dd>
                </div>
                <div className="flex items-center justify-between py-2.5">
                  <dt className="flex items-center gap-2 text-[#8E94A8]">
                    <ShieldCheck className="h-4 w-4" aria-hidden="true" />
                    <span>Rating</span>
                  </dt>
                  <dd className="text-[#F4F4F8] text-right">
                    {game.ageRating} · {game.contentRating}
                  </dd>
                </div>
                <div className="flex items-center justify-between py-2.5">
                  <dt className="flex items-center gap-2 text-[#8E94A8]">
                    <User className="h-4 w-4" aria-hidden="true" />
                    <span>Developer</span>
                  </dt>
                  <dd className="text-right">
                    <Link href={`/creators/${creatorSlug}`} className="text-[#38BDF8] hover:underline">
                      {game.developer}
                    </Link>
                  </dd>
                </div>
                <div className="flex items-center justify-between py-2.5">
                  <dt className="flex items-center gap-2 text-[#8E94A8]">
                    <Globe className="h-4 w-4" aria-hidden="true" />
                    <span>Publisher</span>
                  </dt>
                  <dd className="text-[#F4F4F8] text-right">{game.publisher}</dd>
                </div>
                <div className="flex items-center justify-between py-2.5">
                  <dt className="flex items-center gap-2 text-[#8E94A8]">
                    <Calendar className="h-4 w-4" aria-hidden="true" />
                    <span>Release / Updated</span>
                  </dt>
                  <dd className="font-mono text-[#F4F4F8] tabular-nums text-right">
                    {game.releaseDate} / {game.updatedAt.slice(0, 10)}
                  </dd>
                </div>
                <div className="flex items-center justify-between py-2.5">
                  <dt className="flex items-center gap-2 text-[#8E94A8]">
                    <Eye className="h-4 w-4" aria-hidden="true" />
                    <span>Views</span>
                  </dt>
                  <dd className="font-mono text-[#F4F4F8] tabular-nums">{currentViews}</dd>
                </div>
                <div className="flex items-center justify-between py-2.5">
                  <dt className="flex items-center gap-2 text-[#8E94A8]">
                    <Gamepad2 className="h-4 w-4" aria-hidden="true" />
                    <span>Plays / Downloads</span>
                  </dt>
                  <dd className="font-mono text-[#F4F4F8] tabular-nums">
                    {game.playCount} / {game.downloadCount}
                  </dd>
                </div>
                <div className="flex items-center justify-between py-2.5">
                  <dt className="text-[#8E94A8]">Game ID</dt>
                  <dd className="font-mono text-xs text-[#9CA3B4]">{game.id.slice(0, 12)}</dd>
                </div>
              </dl>
            </div>
          </aside>
        </div>

        {/* Similar Games */}
        {similarGames.length > 0 && (
          <section aria-labelledby="similar-heading" className="mt-16 border-t border-[#1D1F2B] pt-12">
            <h2 id="similar-heading" className="font-display text-2xl font-bold text-[#F4F4F8]">
              Similar Games
            </h2>
            <div className="mt-6 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {similarGames.map((sg) => (
                <GameCard key={sg.id} game={sg} />
              ))}
            </div>
          </section>
        )}
      </div>
    </MotionWrapper>
  );
}
