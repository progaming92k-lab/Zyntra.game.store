import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import GamePlayerShell from '@/components/GamePlayerShell';
import { getServerOwnerSession } from '@/lib/auth';
import { getGameBySlug } from '@/lib/db';

export const dynamic = 'force-dynamic';

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const session = await getServerOwnerSession();
  const game = getGameBySlug(slug, Boolean(session));
  if (!game) return { title: 'Game Not Found' };
  return {
    title: `Play ${game.title}`,
    description: `Play ${game.title} directly in your browser on Zyntra Game Store.`,
  };
}

export default async function PlayGamePage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const session = await getServerOwnerSession();
  const game = getGameBySlug(slug, Boolean(session));
  if (!game) {
    notFound();
  }
  return <GamePlayerShell game={game} />;
}
