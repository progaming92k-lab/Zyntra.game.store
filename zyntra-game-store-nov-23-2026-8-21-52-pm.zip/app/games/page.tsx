import type { Metadata } from 'next';
import CatalogExplorer from '@/components/CatalogExplorer';
import MotionWrapper from '@/components/MotionWrapper';
import { listCategories, listGames } from '@/lib/db';

export const dynamic = 'force-dynamic';

export const metadata: Metadata = {
  title: 'All Games',
  description: 'Browse all published HTML5, WebGL, Android, and PC games available on Zyntra Game Store.',
};

export default function AllGamesPage() {
  const games = listGames({ includeDrafts: false });
  const categories = listCategories(true);

  return (
    <MotionWrapper>
      <CatalogExplorer initialGames={games} categories={categories} />
    </MotionWrapper>
  );
}
