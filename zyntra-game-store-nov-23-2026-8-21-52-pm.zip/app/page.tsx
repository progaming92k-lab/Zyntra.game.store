import React from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { ArrowRight, Compass, Cpu, Download, Flame, Gamepad2, ShieldCheck, Upload } from 'lucide-react';
import GameCard from '@/components/GameCard';
import EmptyStoreState from '@/components/EmptyStoreState';
import HeroSearchBar from '@/components/HeroSearchBar';
import MotionWrapper from '@/components/MotionWrapper';
import ShareButton from '@/components/ShareButton';
import { listCategories, listGames } from '@/lib/db';
import { filterAndSortGames } from '@/lib/game-logic';

export const dynamic = 'force-dynamic';

export default function HomePage() {
  const publishedGames = listGames({ includeDrafts: false });
  const categories = listCategories(true);

  const featuredGames = publishedGames.filter((g) => g.featured);
  const trendingGames = publishedGames.filter((g) => g.trending);
  const heroSpotlight = featuredGames[0] || trendingGames[0] || publishedGames[0] || null;
  const recentlyAdded = filterAndSortGames(publishedGames, { sort: 'newest', publicOnly: true }).slice(0, 6);
  const popularGames = filterAndSortGames(publishedGames, { sort: 'popular', publicOnly: true }).slice(0, 3);
  const newReleases = recentlyAdded.slice(0, 3);

  const collectionsMap = new Map<string, typeof publishedGames>();
  for (const g of publishedGames) {
    const col = g.collectionName || 'Creator Originals';
    const arr = collectionsMap.get(col) || [];
    arr.push(g);
    collectionsMap.set(col, arr);
  }

  return (
    <MotionWrapper>
      {/* Hero Banner */}
      <section className="relative overflow-hidden border-b border-[#1C1E2A]/80">
        <div className="relative mx-auto max-w-7xl px-4 py-12 sm:px-6 sm:py-16 lg:px-8">
          <div className="relative overflow-hidden rounded-2xl border border-[#26293B] bg-[#0D0E14]/82 backdrop-blur-md shadow-[0_0_64px_rgba(124,58,237,0.12)]">
            <div className="grid grid-cols-1 lg:grid-cols-12 items-stretch">
              <div className="relative z-10 flex flex-col justify-center p-8 sm:p-12 lg:col-span-7">
                <p className="text-xs font-semibold tracking-widest text-[#38BDF8] uppercase">
                  Zyntra Game Store
                </p>
                <h1 className="mt-3 font-display text-3xl font-extrabold tracking-tight text-[#F4F4F8] sm:text-5xl">
                  Play &amp; Download Original Indie Games
                </h1>
                <p className="mt-4 max-w-xl text-sm leading-relaxed text-[#A5ABBE] sm:text-base">
                  Built for independent game creators and players. Upload HTML5, WebGL, Android, or desktop builds—and launch browser games instantly or download verified packages.
                </p>

                <HeroSearchBar />

                <div className="mt-6 flex flex-wrap items-center gap-3">
                  <Link
                    href="/games"
                    className="inline-flex items-center gap-2 rounded-lg border border-[#2A2D3E] bg-[#151722] px-4 py-2.5 text-sm font-semibold text-[#F4F4F8] transition-all duration-200 hover:-translate-y-0.5 hover:border-[#38BDF8]/60 hover:text-[#38BDF8] whitespace-nowrap"
                  >
                    <Compass className="h-4 w-4" aria-hidden="true" />
                    <span>Explore Games</span>
                  </Link>
                  <Link
                    href="/import"
                    className="zyntra-btn-shine inline-flex items-center gap-2 rounded-lg border border-[#8B5CF6]/50 bg-[#8B5CF6]/15 px-4 py-2.5 text-sm font-semibold text-[#C4B5FD] transition-all duration-200 hover:-translate-y-0.5 hover:bg-[#8B5CF6]/25 hover:text-white hover:shadow-[0_0_20px_rgba(139,92,246,0.3)] whitespace-nowrap"
                  >
                    <Upload className="h-4 w-4" aria-hidden="true" />
                    <span>Import Game</span>
                  </Link>
                  <ShareButton variant="hero" label="Share Store" />
                </div>
              </div>

              <div className="relative min-h-[260px] lg:col-span-5">
                <Image
                  src="/images/zyntra-hero.jpg"
                  alt="Zyntra Game Store digital gaming showcase"
                  fill
                  priority
                  sizes="(max-width: 1024px) 100vw, 42vw"
                  referrerPolicy="no-referrer"
                  className="object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-r from-[#0D0E14] via-[#0D0E14]/35 to-transparent hidden lg:block" />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0D0E14] via-transparent to-transparent lg:hidden" />

                {heroSpotlight && (
                  <Link
                    href={`/games/${heroSpotlight.slug}`}
                    className="absolute bottom-5 left-5 right-5 rounded-xl border border-[#2A2D3E] bg-[#0B0C11]/90 p-4 backdrop-blur-md transition-colors hover:border-[#38BDF8]/60"
                  >
                    <div className="text-xs font-medium text-[#38BDF8]">
                      Featured Spotlight · {heroSpotlight.category}
                    </div>
                    <div className="mt-1 flex items-center justify-between gap-3">
                      <span className="font-display text-base font-bold text-white truncate">
                        {heroSpotlight.title}
                      </span>
                      <ArrowRight className="h-4 w-4 shrink-0 text-[#A855F7]" aria-hidden="true" />
                    </div>
                  </Link>
                )}
              </div>
            </div>

            <div className="grid grid-cols-1 gap-px border-t border-[#1F2232] bg-[#1F2232] sm:grid-cols-2 lg:grid-cols-4">
              <div className="flex items-center gap-3 bg-[#0B0C12]/90 px-5 py-3.5">
                <Gamepad2 className="h-4 w-4 shrink-0 text-[#A855F7]" aria-hidden="true" />
                <div>
                  <div className="text-xs font-semibold text-[#F4F4F8]">Instant Browser Play</div>
                  <div className="text-xs text-[#8E94A8]">HTML5 &amp; WebGL in fullscreen</div>
                </div>
              </div>
              <div className="flex items-center gap-3 bg-[#0B0C12]/90 px-5 py-3.5">
                <Cpu className="h-4 w-4 shrink-0 text-[#38BDF8]" aria-hidden="true" />
                <div>
                  <div className="text-xs font-semibold text-[#F4F4F8]">AI File Analysis</div>
                  <div className="text-xs text-[#8E94A8]">Auto metadata &amp; cover art</div>
                </div>
              </div>
              <div className="flex items-center gap-3 bg-[#0B0C12]/90 px-5 py-3.5">
                <Download className="h-4 w-4 shrink-0 text-[#38BDF8]" aria-hidden="true" />
                <div>
                  <div className="text-xs font-semibold text-[#F4F4F8]">Verified Direct Downloads</div>
                  <div className="text-xs text-[#8E94A8]">APK, PC builds &amp; archives</div>
                </div>
              </div>
              <div className="flex items-center gap-3 bg-[#0B0C12]/90 px-5 py-3.5">
                <ShieldCheck className="h-4 w-4 shrink-0 text-[#A855F7]" aria-hidden="true" />
                <div>
                  <div className="text-xs font-semibold text-[#F4F4F8]">Creator Import Studio</div>
                  <div className="text-xs text-[#8E94A8]">8-stage publish workflow</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Main Storefront Content */}
      <div className="mx-auto max-w-7xl space-y-16 px-4 py-12 sm:px-6 lg:px-8">
        {publishedGames.length === 0 ? (
          <EmptyStoreState />
        ) : (
          <>
            {/* Featured Games */}
            {featuredGames.length > 0 && (
              <section aria-labelledby="featured-heading">
                <div className="flex items-end justify-between gap-4">
                  <div>
                    <h2 id="featured-heading" className="font-display text-2xl font-bold text-[#F4F4F8]">
                      Featured Games
                    </h2>
                    <p className="mt-1 text-sm text-[#9CA3B4]">Highlighted releases selected for the storefront.</p>
                  </div>
                  <Link
                    href="/games"
                    className="inline-flex items-center gap-1.5 text-sm font-medium text-[#38BDF8] hover:underline whitespace-nowrap"
                  >
                    <span>View all</span>
                    <ArrowRight className="h-4 w-4" aria-hidden="true" />
                  </Link>
                </div>
                <div className="mt-6 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
                  {featuredGames.slice(0, 3).map((game) => (
                    <GameCard key={game.id} game={game} />
                  ))}
                </div>
              </section>
            )}

            {/* Trending Games */}
            {trendingGames.length > 0 && (
              <section aria-labelledby="trending-heading">
                <div className="flex items-end justify-between gap-4">
                  <div className="flex items-center gap-2.5">
                    <Flame className="h-5 w-5 text-[#38BDF8]" aria-hidden="true" />
                    <div>
                      <h2 id="trending-heading" className="font-display text-2xl font-bold text-[#F4F4F8]">
                        Trending Games
                      </h2>
                      <p className="mt-0.5 text-sm text-[#9CA3B4]">Hot indie releases gaining momentum.</p>
                    </div>
                  </div>
                </div>
                <div className="mt-6 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
                  {trendingGames.slice(0, 3).map((game) => (
                    <GameCard key={`trend-${game.id}`} game={game} />
                  ))}
                </div>
              </section>
            )}

            {/* Recently Added & New Releases */}
            <section aria-labelledby="recent-heading">
              <div className="flex items-end justify-between gap-4">
                <div>
                  <h2 id="recent-heading" className="font-display text-2xl font-bold text-[#F4F4F8]">
                    Recently Added &amp; New Releases
                  </h2>
                  <p className="mt-1 text-sm text-[#9CA3B4]">Latest builds published to Zyntra Game Store.</p>
                </div>
                <Link
                  href="/games"
                  className="inline-flex items-center gap-1.5 text-sm font-medium text-[#38BDF8] hover:underline whitespace-nowrap"
                >
                  <span>All Games</span>
                  <ArrowRight className="h-4 w-4" aria-hidden="true" />
                </Link>
              </div>
              <div className="mt-6 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
                {recentlyAdded.map((game) => (
                  <GameCard key={game.id} game={game} />
                ))}
              </div>
            </section>

            {/* Popular Games */}
            {popularGames.length > 0 && (
              <section aria-labelledby="popular-heading">
                <div className="flex items-end justify-between gap-4">
                  <div>
                    <h2 id="popular-heading" className="font-display text-2xl font-bold text-[#F4F4F8]">
                      Popular Games
                    </h2>
                    <p className="mt-1 text-sm text-[#9CA3B4]">Most played and downloaded titles on Zyntra.</p>
                  </div>
                </div>
                <div className="mt-6 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
                  {popularGames.map((game) => (
                    <GameCard key={game.id} game={game} />
                  ))}
                </div>
              </section>
            )}

            {/* Collections */}
            {collectionsMap.size > 0 && (
              <section aria-labelledby="collections-heading">
                <h2 id="collections-heading" className="font-display text-2xl font-bold text-[#F4F4F8]">
                  Game Collections
                </h2>
                <div className="mt-6 grid grid-cols-1 gap-5 md:grid-cols-2">
                  {Array.from(collectionsMap.entries())
                    .slice(0, 4)
                    .map(([colName, colGames]) => (
                      <div
                        key={colName}
                        className="flex flex-col justify-between rounded-xl border border-[#242738] bg-[#111218]/86 p-6 backdrop-blur-md"
                      >
                        <div>
                          <div className="text-xs font-medium text-[#38BDF8]">
                            Collection · <span className="font-mono tabular-nums">{colGames.length}</span>{' '}
                            {colGames.length === 1 ? 'game' : 'games'}
                          </div>
                          <h3 className="mt-1.5 font-display text-xl font-bold text-[#F4F4F8]">{colName}</h3>
                          <p className="mt-2 text-sm text-[#9CA3B4]">
                            Featuring {colGames.slice(0, 3).map((g) => g.title).join(', ')}
                          </p>
                        </div>
                        <div className="mt-4 flex flex-wrap gap-3 pt-3 border-t border-[#1C1E2B]">
                          {colGames.slice(0, 3).map((g) => (
                            <Link
                              key={g.id}
                              href={`/games/${g.slug}`}
                              className="text-xs font-medium text-[#D1D5E2] hover:text-[#38BDF8] underline underline-offset-4"
                            >
                              {g.shortTitle}
                            </Link>
                          ))}
                        </div>
                      </div>
                    ))}
                </div>
              </section>
            )}

            {/* New Releases Strip when > 3 */}
            {newReleases.length > 0 && publishedGames.length > 3 && (
              <section aria-labelledby="new-releases-heading">
                <h2 id="new-releases-heading" className="font-display text-2xl font-bold text-[#F4F4F8]">
                  New Releases
                </h2>
                <div className="mt-6 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
                  {newReleases.map((game) => (
                    <GameCard key={`nr-${game.id}`} game={game} />
                  ))}
                </div>
              </section>
            )}
          </>
        )}

        {/* Categories Directory Strip */}
        <section aria-labelledby="categories-heading" className="border-t border-[#1C1E2A] pt-12">
          <div className="flex items-end justify-between gap-4">
            <div>
              <h2 id="categories-heading" className="font-display text-2xl font-bold text-[#F4F4F8]">
                Browse Categories
              </h2>
              <p className="mt-1 text-sm text-[#9CA3B4]">Explore games organized by genre, perspective, and style.</p>
            </div>
            <Link
              href="/categories"
              className="inline-flex items-center gap-1.5 text-sm font-medium text-[#38BDF8] hover:underline whitespace-nowrap"
            >
              <span>All Categories</span>
              <ArrowRight className="h-4 w-4" aria-hidden="true" />
            </Link>
          </div>

          <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-7">
            {categories.map((cat) => (
              <Link
                key={cat.id}
                href={`/categories/${encodeURIComponent(cat.slug)}`}
                className="group flex flex-col justify-between rounded-xl border border-[#242738] bg-[#111218]/86 p-4 backdrop-blur-md transition-all duration-200 hover:-translate-y-0.5 hover:border-[#8B5CF6]/70 hover:bg-[#161824]/92 hover:shadow-[0_10px_28px_rgba(139,92,246,0.18)]"
              >
                <span className="font-display text-sm font-semibold text-[#F4F4F8] group-hover:text-[#38BDF8]">
                  {cat.name}
                </span>
                <span className="mt-2 font-mono text-xs text-[#7E849A] tabular-nums">
                  {cat.gameCount || 0} {cat.gameCount === 1 ? 'game' : 'games'}
                </span>
              </Link>
            ))}
          </div>
        </section>
      </div>
    </MotionWrapper>
  );
}
