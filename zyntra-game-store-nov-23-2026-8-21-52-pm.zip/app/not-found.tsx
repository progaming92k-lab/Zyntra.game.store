import Link from 'next/link';
import { Gamepad2 } from 'lucide-react';

export default function NotFound() {
  return (
    <div className="mx-auto flex max-w-xl flex-col items-center justify-center px-4 py-24 text-center">
      <div className="flex h-14 w-14 items-center justify-center rounded-2xl border border-[#8B5CF6]/40 bg-[#8B5CF6]/10 text-[#A855F7]">
        <Gamepad2 className="h-7 w-7" aria-hidden="true" />
      </div>
      <h1 className="mt-6 font-display text-3xl font-bold text-[#F4F4F8]">Page Not Found</h1>
      <p className="mt-2 text-sm text-[#9CA3B4]">
        The game or page you requested could not be found in Zyntra Game Store.
      </p>
      <div className="mt-7 flex items-center gap-3">
        <Link
          href="/"
          className="rounded-lg bg-[#8B5CF6] px-5 py-2.5 text-sm font-semibold text-white hover:bg-[#7C3AED]"
        >
          Back to Home
        </Link>
        <Link
          href="/games"
          className="rounded-lg border border-[#282B3B] bg-[#111218] px-5 py-2.5 text-sm font-medium text-[#D1D5E2] hover:text-white"
        >
          Browse Games
        </Link>
      </div>
    </div>
  );
}
