import type { Metadata } from 'next';
import MotionWrapper from '@/components/MotionWrapper';

export const metadata: Metadata = {
  title: 'Terms and Conditions',
  description: 'Terms and Conditions governing game downloads, browser playback, and creator publishing on Zyntra Game Store.',
};

export default function TermsPage() {
  return (
    <MotionWrapper>
      <article className="mx-auto max-w-4xl px-4 py-12 sm:px-6 lg:px-8">
        <header className="border-b border-[#1D1F2B] pb-6">
          <h1 className="font-display text-3xl font-bold text-[#F4F4F8] sm:text-4xl">Terms &amp; Conditions</h1>
          <p className="mt-2 text-sm text-[#8E94A8]">Last updated: November 2026</p>
        </header>

        <div className="mt-8 space-y-8 text-sm leading-relaxed text-[#B6BCCF] sm:text-base">
          <section>
            <h2 className="font-display text-xl font-bold text-[#F4F4F8]">1. Acceptance of Terms</h2>
            <p className="mt-2">
              By accessing, browsing, playing browser games on, or downloading software packages from Zyntra Game Store, you agree to comply with these Terms and Conditions.
            </p>
          </section>

          <section>
            <h2 className="font-display text-xl font-bold text-[#F4F4F8]">2. Game Licenses &amp; Intellectual Property</h2>
            <p className="mt-2">
              All games, artwork, audio assets, and source builds published on Zyntra Game Store remain the intellectual property of their respective creators and developers. Visitors are granted a personal, non-exclusive, non-transferable license to play browser-hosted titles and download provided packages for personal entertainment unless otherwise noted on a game&apos;s listing page.
            </p>
          </section>

          <section>
            <h2 className="font-display text-xl font-bold text-[#F4F4F8]">3. Software Downloads &amp; Compatibility</h2>
            <p className="mt-2">
              Each game page indicates whether a build is browser-playable or distributed as a downloadable package (such as Android APK or desktop builds), along with its exact file size and version. You are responsible for ensuring your device meets the stated platform and minimum system requirements prior to installation.
            </p>
          </section>

          <section>
            <h2 className="font-display text-xl font-bold text-[#F4F4F8]">4. Creator Uploads &amp; Acceptable Use</h2>
            <p className="mt-2">
              Access to the Import Game studio and Admin Dashboard is restricted to the authorized store owner. Automated scraping, unauthorized access attempts, tampering with hosted archives, or abusing download endpoints is strictly prohibited.
            </p>
          </section>

          <section>
            <h2 className="font-display text-xl font-bold text-[#F4F4F8]">5. Disclaimer</h2>
            <p className="mt-2">
              Games and downloadable files are provided &ldquo;as is&rdquo; without warranties of uninterrupted availability. The store owner reserves the right to update versions, unpublish drafts, or remove listings at any time.
            </p>
          </section>
        </div>
      </article>
    </MotionWrapper>
  );
}
