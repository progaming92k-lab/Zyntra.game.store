import type { Metadata } from 'next';
import Link from 'next/link';
import { ArrowLeft, Download, Eye, Gamepad2, Heart, Play, User } from 'lucide-react';
import GameCard from '@/components/GameCard';
import MotionWrapper from '@/components/MotionWrapper';
import { getCreatorByUsername, listGamesByCreator } from '@/lib/db';

export const dynamic = 'force-dynamic';

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const decoded = decodeURIComponent(slug);
  const creator = getCreatorByUsername(decoded);
  const name = creator?.displayName || decoded;
  return {
    title: `${name} – Creator Profile`,
    description: `Explore indie games published by ${name} on Zyntra Game Store.`,
  };
}

export default async function CreatorProfilePage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const decoded = decodeURIComponent(slug);
  const creator = getCreatorByUsername(decoded);
  const games = listGamesByCreator(decoded, false);

  const displayName = creator?.displayName || games[0]?.developer || decoded;
  const totalDownloads = games.reduce((acc, g) => acc + g.downloadCount, 0);
  const totalPlays = games.reduce((acc, g) => acc + g.playCount, 0);
  const totalViews = games.reduce((acc, g) => acc + g.viewCount, 0);
  const totalLikes = games.reduce((acc, g) => acc + g.likeCount, 0);

  return (
    <MotionWrapper>
      <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
        <Link
          href="/games"
          className="inline-flex items-center gap-2 text-sm font-medium text-[#9CA3B4] hover:text-[#38BDF8]"
        >
          <ArrowLeft className="h-4 w-4" aria-hidden="true" />
          <span>Back to All Games</span>
        </Link>

        {/* Creator Profile Header */}
        <section className="mt-6 rounded-2xl border border-[#242738] bg-[#111218]/90 p-6 sm:p-8 backdrop-blur-md">
          <div className="flex flex-col gap-6 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex items-center gap-4">
              <div className="flex h-16 w-16 shrink-0 items-center justify-center rounded-2xl border border-[#8B5CF6]/50 bg-gradient-to-br from-[#7C3AED]/25 to-[#0EA5E9]/25 text-[#38BDF8]">
                <User className="h-7 w-7" aria-hidden="true" />
              </div>
              <div>
                <span className="text-xs font-semibold tracking-wider text-[#38BDF8] uppercase">
                  Developer Profile
                </span>
                <h1 className="mt-1 font-display text-2xl font-bold text-[#F4F4F8] sm:text-3xl">
                  {displayName}
                </h1>
                <p className="mt-1 text-sm text-[#9CA3B4]">
                  {creator?.bio || `Independent game creator publishing releases on Zyntra Game Store.`}
                </p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
              <div className="rounded-xl border border-[#202333] bg-[#0B0C11] px-4 py-3 text-center">
                <div className="flex items-center justify-center gap-1 text-xs text-[#8E94A8]">
                  <Gamepad2 className="h-3.5 w-3.5 text-[#A855F7]" />
                  <span>Games</span>
                </div>
                <div className="mt-1 font-mono text-lg font-bold text-white tabular-nums">{games.length}</div>
              </div>
              <div className="rounded-xl border border-[#202333] bg-[#0B0C11] px-4 py-3 text-center">
                <div className="flex items-center justify-center gap-1 text-xs text-[#8E94A8]">
                  <Play className="h-3.5 w-3.5 text-[#38BDF8]" />
                  <span>Plays</span>
                </div>
                <div className="mt-1 font-mono text-lg font-bold text-white tabular-nums">{totalPlays}</div>
              </div>
              <div className="rounded-xl border border-[#202333] bg-[#0B0C11] px-4 py-3 text-center">
                <div className="flex items-center justify-center gap-1 text-xs text-[#8E94A8]">
                  <Download className="h-3.5 w-3.5 text-[#38BDF8]" />
                  <span>Downloads</span>
                </div>
                <div className="mt-1 font-mono text-lg font-bold text-white tabular-nums">{totalDownloads}</div>
              </div>
              <div className="rounded-xl border border-[#202333] bg-[#0B0C11] px-4 py-3 text-center">
                <div className="flex items-center justify-center gap-1 text-xs text-[#8E94A8]">
                  <Heart className="h-3.5 w-3.5 text-rose-400" />
                  <span>Likes</span>
                </div>
                <div className="mt-1 font-mono text-lg font-bold text-white tabular-nums">
                  {totalLikes}
                  <span className="sr-only"> and {totalViews} views</span>
                </div>
              </div>
            </div>
          </div>
          <div className="mt-4 flex items-center gap-2 text-xs text-[#7E849A]">
            <Eye className="h-3.5 w-3.5" aria-hidden="true" />
            <span>{totalViews} total game page views</span>
          </div>
        </section>

        {/* Creator Games Grid */}
        <section className="mt-10">
          <h2 className="font-display text-xl font-bold text-[#F4F4F8]">
            Published Releases by {displayName}
          </h2>
          {games.length === 0 ? (
            <div className="mt-4 rounded-xl border border-[#222432] bg-[#111218] p-10 text-center text-sm text-[#9CA3B4]">
              No public games published under this creator profile yet.
            </div>
          ) : (
            <div className="mt-6 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {games.map((game) => (
                <GameCard key={game.id} game={game} />
              ))}
            </div>
          )}
        </section>
      </div>
    </MotionWrapper>
  );
}
