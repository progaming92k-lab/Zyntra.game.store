import React from 'react';
import ZyntraLoader from '@/components/ZyntraLoader';

export default function Loading() {
  return (
    <div className="flex min-h-[60vh] items-center justify-center px-4">
      <ZyntraLoader title="Loading Zyntra Game Store..." subtitle="Syncing games & assets" />
    </div>
  );
}
